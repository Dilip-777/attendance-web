export const uploadprsetname = "attendance-web";

export const plantname = "Plant One";
