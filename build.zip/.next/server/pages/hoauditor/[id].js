"use strict";
(() => {
var exports = {};
exports.id = 5954;
exports.ids = [5954];
exports.modules = {

/***/ 3401:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ HoAuditorForm),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9876);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6850);
/* harmony import */ var _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3522);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9648);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6395);
/* harmony import */ var _components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9711);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__, axios__WEBPACK_IMPORTED_MODULE_9__]);
([_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__, axios__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












// import { Contractor } from "@prisma/client"
const fileType = yup__WEBPACK_IMPORTED_MODULE_5__.object().required("Required").optional();
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_5__.object().shape({
    contractorname: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    workDescription: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    invoiceNo: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    uploadDoc1: fileType,
    uploadDoc2: fileType,
    date: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    monthOfInvoice: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    fromDate: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    toDate: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    basicbillamount: yup__WEBPACK_IMPORTED_MODULE_5__.number().required("Required"),
    firstbillormonthly: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    serviceCharges: yup__WEBPACK_IMPORTED_MODULE_5__.number().required("Required"),
    // Organsiation Details
    totalbillAmount: yup__WEBPACK_IMPORTED_MODULE_5__.number().required("Required"),
    gst: yup__WEBPACK_IMPORTED_MODULE_5__.number().required("Required"),
    netbillAmount: yup__WEBPACK_IMPORTED_MODULE_5__.number().required("Required"),
    uploadDoc4: fileType,
    uploadDoc3: fileType,
    uploadDoc5: fileType,
    bankDetails: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    onetimeInvoice: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    verifiedComplainces: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    workOrderAvailable: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    licensesInPlace: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    previousMonthPayReceived: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    previousPayVerified: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    detailsSentToAuditAndHo: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    gstChallanAttached: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    //Service / Product Details
    deductions: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    variationsInManpower: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    manchineOrRegisterMode: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    uploadDoc6: fileType
});
function HoAuditorForm({ contractor  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    // const [contractor, setContractor] = useState<Contractor || null>()
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [value1, setValue1] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { id  } = router.query;
    const initialValues = {
        contractorname: contractor.contractorname || "",
        workDescription: "",
        invoiceNo: "",
        uploadDoc1: undefined,
        uploadDoc2: undefined,
        date: undefined,
        monthOfInvoice: "",
        fromDate: undefined,
        toDate: undefined,
        basicbillamount: 0,
        firstbillormonthly: "",
        serviceCharges: 0,
        totalbillAmount: 0,
        gst: 0,
        netbillAmount: 0,
        uploadDoc4: undefined,
        uploadDoc3: undefined,
        uploadDoc5: undefined,
        bankDetails: "",
        onetimeInvoice: false,
        verifiedComplainces: false,
        workOrderAvailable: false,
        licensesInPlace: false,
        previousPayVerified: false,
        previousMonthPayReceived: false,
        detailsSentToAuditAndHo: false,
        gstChallanAttached: false,
        deductions: "",
        variationsInManpower: "",
        manchineOrRegisterMode: "",
        uploadDoc6: undefined
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper, {
            sx: {
                height: "83.7vh",
                pt: "1rem",
                pb: "8rem",
                overflow: "hidden auto",
                scrollBehavior: "smooth",
                "&::-webkit-scrollbar": {
                    width: 7
                },
                "&::-webkit-scrollbar-thumb": {
                    backgroundColor: "#bdbdbd",
                    borderRadius: 2
                }
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    sx: {
                        height: "3rem",
                        display: "flex",
                        alignItems: "center"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        variant: "h4",
                        ml: 5,
                        my: "auto",
                        children: "HO Commercial Form"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_6__.Formik, {
                    initialValues: initialValues,
                    validationSchema: validationSchema,
                    onSubmit: async (values)=>{
                        await axios__WEBPACK_IMPORTED_MODULE_9__["default"].post("/api/hoauditor", {
                            ...values,
                            contractorId: contractor?.id
                        }).then((res)=>{
                            router.push("/hoauditor");
                        }).catch((err)=>{
                            console.log(err);
                        });
                    },
                    children: ({ handleSubmit , errors , values  })=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            noValidate: true,
                            onSubmit: handleSubmit,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                    spacing: 0,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            variant: "h4",
                                            ml: 4,
                                            my: 3,
                                            children: "Kindly Provide the details required below."
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            ml: {
                                                xs: 0,
                                                sm: 2,
                                                md: 6
                                            },
                                            container: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "contractorname",
                                                        label: "Contractor Name*",
                                                        placeHolder: "Enter the Contractor Name",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "workDescription",
                                                        label: "Work Description*",
                                                        placeHolder: "Enter Work Description",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "invoiceNo",
                                                        label: "Invoice No*",
                                                        placeHolder: "Enter Invoice No",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                        name: "date",
                                                        label: "Date of Invoice",
                                                        placeHolder: "Enter the date"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                        name: "monthOfInvoice",
                                                        label: "Month Of Invoice*",
                                                        placeHolder: "Month Of Invoice",
                                                        disabled: false,
                                                        // views={["month", "year"]}
                                                        views: [
                                                            "year",
                                                            "month"
                                                        ],
                                                        format: "MM/YYYY"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                        name: "fromDate",
                                                        label: "From Date*",
                                                        placeHolder: "Enter the From Date"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                        name: "toDate",
                                                        label: "To Date",
                                                        placeHolder: "Enter the To Date"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "basicbillamount",
                                                        label: "Basic Bill Amount*",
                                                        placeHolder: "Enter Basic Bill Amount",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "firstbillormonthly",
                                                        label: "Whether First Bill Or Regular Monthly*",
                                                        placeHolder: "Select First Bill Or Regular Monthly",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "serviceCharges",
                                                        label: "Service Charges*",
                                                        placeHolder: "Enter Service Charges",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "totalbillAmount",
                                                        label: "Total Bill Amount*",
                                                        placeHolder: "Enter the Total Bill Amount",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "gst",
                                                        label: "GST*",
                                                        placeHolder: "GST",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "netbillAmount",
                                                        label: "Net Bill Amount*",
                                                        placeHolder: "Enter the Net Bill Amount",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "bankDetails",
                                                        label: "Bank Details Available On Bill*",
                                                        placeHolder: "Enter the Bank Details Available On Bill",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        name: "uploadDoc1",
                                                        label: "Upload Document 1"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        name: "uploadDoc2",
                                                        label: "Upload Document 2"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        name: "uploadDoc3",
                                                        label: "Upload Document 3"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        name: "uploadDoc4",
                                                        label: "Upload Document 4"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        name: "uploadDoc5",
                                                        label: "Upload Document 5"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                    spacing: 0,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            variant: "h4",
                                            ml: 4,
                                            my: 4,
                                            children: "Kindly Select Yes or No for the following fields"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            ml: {
                                                xs: 0,
                                                sm: 2,
                                                md: 6
                                            },
                                            mt: 2,
                                            container: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "onetimeInvoice",
                                                        label: "Whether One Time Invoice*",
                                                        placeHolder: "Select One Time Invoice or Not",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "verifiedComplainces",
                                                        label: "Verified for Compliances or not*",
                                                        placeHolder: "Turnover Last Year",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "workOrderAvailable",
                                                        label: "Word Order Available or Not*",
                                                        placeHolder: "Word Order Available or Not",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "licensesInPlace",
                                                        label: "Labour Licenses & Other Licenses in Place or Not*",
                                                        placeHolder: "Labour Licenses & Other Licenses in Place or Not",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "previousMonthPayReceived",
                                                        label: "Previous Month Pay received or Not*",
                                                        placeHolder: "Previous Month Pay received or Not",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "previousPayVerified",
                                                        label: "Previous Month Pay Register Checked Or Verified With Previous Month*",
                                                        placeHolder: "Select a option",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "detailsSentToAuditAndHo",
                                                        label: "Details of variations sent to audit and HO*",
                                                        placeHolder: "Details of variations sent to audit and HO",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        name: "gstChallanAttached",
                                                        label: "Whether GST Challa of Previous Month Attached?*",
                                                        placeHolder: "Select a option",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: true,
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: false,
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                    spacing: 0,
                                    mt: 4,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            variant: "h4",
                                            ml: 4,
                                            my: "auto",
                                            children: "Kindly Provide the information required and suitable reasons for the same if any."
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            ml: {
                                                xs: 0,
                                                sm: 2,
                                                md: 6
                                            },
                                            mt: 0,
                                            container: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "deductions",
                                                        label: "Deductions",
                                                        placeHolder: "Enter the Deductions",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "variationsInManpower",
                                                        label: "Variations in Manpower",
                                                        placeHolder: "Enter the Variations in Manpower",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        name: "manchineOrRegisterMode",
                                                        label: "Whether Machine or Register Attendance Mode Adopted?*",
                                                        placeHolder: "Enter whether Machine or Register Mode",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    md: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                        name: "uploadDoc6",
                                                        label: "Upload Document 6"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    type: "submit",
                                    variant: "contained",
                                    sx: {
                                        float: "right",
                                        mr: 10
                                    },
                                    children: "Submit"
                                })
                            ]
                        });
                    }
                })
            ]
        })
    });
}
const getServerSideProps = async (context)=>{
    const { id  } = context.query;
    const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_10__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
        where: {
            id: id
        }
    });
    return {
        props: {
            contractor
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 3274:
/***/ ((module) => {

module.exports = require("@mui/icons-material/InsertDriveFile");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 8167:
/***/ ((module) => {

module.exports = require("@mui/material/Card");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 8891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 6354:
/***/ ((module) => {

module.exports = require("@mui/material/FormHelperText");

/***/ }),

/***/ 6096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 1856:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/DatePicker");

/***/ }),

/***/ 5753:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/LocalizationProvider");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5684,6850,4503], () => (__webpack_exec__(3401)));
module.exports = __webpack_exports__;

})();