"use strict";
(() => {
var exports = {};
exports.id = 6904;
exports.ids = [6904];
exports.modules = {

/***/ 875:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Edit),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6146);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9876);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6850);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6395);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9648);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5031);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(shortid__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _components_FormikComponents_FormMonth__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(3666);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_18__]);
axios__WEBPACK_IMPORTED_MODULE_18__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












// import {  useState } from "react";










const numberType = yup__WEBPACK_IMPORTED_MODULE_13__.number().required("Required");
const SafetyItem = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
    division: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("Required"),
    chargeableItemIssued: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("Required"),
    penalty: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("Required"),
    netchargeableamount: numberType
});
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
    contractorid: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("Required"),
    month: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("Required"),
    safetyItems: yup__WEBPACK_IMPORTED_MODULE_13__.array().of(SafetyItem),
    totalAmount: numberType.test("sumOfChargeableAmounts", "Total amount should be equal to sum of chargeable amounts", function(value) {
        const { safetyItems  } = this.parent;
        const sumOfChargeableAmounts = safetyItems.reduce((acc, item)=>acc + Number(item.netchargeableamount || 0), 0);
        return Number(value) === sumOfChargeableAmounts;
    })
});
function Edit({ contractors , safety , safetyItems  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { id  } = router.query;
    console.log("safetyItems", safetyItems);
    const initialValues = {
        contractorid: safety?.contractorid || "",
        month: safety?.month ? dayjs__WEBPACK_IMPORTED_MODULE_20___default()(safety?.month, "MM/YYYY") : dayjs__WEBPACK_IMPORTED_MODULE_20___default()().format("MM/YYYY"),
        // division: safety?.division || "",
        // chargeableItemIssued: safety?.chargeableItemIssued || "",
        // penalty: safety?.penalty || "",
        // netchargeableamount: safety?.netchargeableamount || 0,
        safetyItems: safetyItems.length > 0 ? safetyItems.map((safetyItem)=>({
                division: safetyItem.division,
                chargeableItemIssued: safetyItem.chargeableItemIssued,
                penalty: safetyItem.penalty,
                netchargeableamount: safetyItem.netchargeableamount
            })) : [
            {
                division: "",
                chargeableItemIssued: "",
                penalty: 0,
                netchargeableamount: 0
            }
        ],
        totalAmount: safety?.totalAmount || 0
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_5___default()), {
            sx: {
                height: "83.7vh",
                pt: "1rem",
                pb: "8rem",
                overflow: "hidden auto",
                scrollBehavior: "smooth",
                "&::-webkit-scrollbar": {
                    width: 9
                },
                "&::-webkit-scrollbar-thumb": {
                    backgroundColor: "#bdbdbd",
                    borderRadius: 2
                }
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                    sx: {
                        height: "3rem",
                        display: "flex",
                        alignItems: "center"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default()), {
                        variant: "h4",
                        ml: 5,
                        my: "auto",
                        children: "Add Safety"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_14__.Formik, {
                    initialValues: initialValues,
                    validationSchema: validationSchema,
                    onSubmit: (values)=>{
                        const id = safety ? safety.id : shortid__WEBPACK_IMPORTED_MODULE_19___default().generate();
                        axios__WEBPACK_IMPORTED_MODULE_18__["default"].post("/api/safety", {
                            id: id,
                            contractorid: values.contractorid,
                            contractorName: contractors.find((c)=>c.contractorId === values.contractorid)?.contractorname,
                            month: values.month,
                            totalAmount: values.totalAmount,
                            safetyItems: values.safetyItems.map((safetyItem)=>({
                                    id: shortid__WEBPACK_IMPORTED_MODULE_19___default().generate(),
                                    safetyId: id,
                                    division: safetyItem.division,
                                    chargeableItemIssued: safetyItem.chargeableItemIssued,
                                    penalty: safetyItem.penalty,
                                    netchargeableamount: safetyItem.netchargeableamount
                                }))
                        }).then((res)=>{
                            router.push("/safety");
                        }).catch((err)=>{
                            console.log(err);
                        });
                    },
                    children: ({ handleSubmit , values , errors , setFieldValue  })=>{
                        // if (!errors.division) {
                        //   const options1 = options.filter((option) =>
                        //     option.chargeableItemIssued.includes(values.division)
                        //   );
                        //   setOptions(options1);
                        // }
                        const totalAmount = values.safetyItems.reduce((acc, item)=>acc + Number(item.netchargeableamount || 0), 0);
                        if (totalAmount !== values.totalAmount) {
                            setFieldValue("totalAmount", totalAmount);
                        }
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            noValidate: true,
                            onSubmit: handleSubmit,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    ml: 3,
                                    mt: 2,
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            lg: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                name: "contractorid",
                                                label: "Contractor Name*",
                                                placeHolder: "Contractor Name",
                                                disabled: false,
                                                options: contractors?.map((contractor)=>({
                                                        value: contractor.contractorId,
                                                        label: contractor.contractorname
                                                    })) || []
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            lg: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormMonth__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                name: "month",
                                                label: "Month*",
                                                placeHolder: "Select a month",
                                                disabled: false,
                                                format: "MM/YYYY"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            lg: 3,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                name: "totalAmount",
                                                label: "Total Amount*",
                                                placeHolder: "Enter the Total Amount",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FieldArray1, {
                                            setFieldValue: setFieldValue,
                                            values: values
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    type: "submit",
                                    variant: "contained",
                                    sx: {
                                        float: "right",
                                        mr: 10
                                    },
                                    children: "Submit"
                                })
                            ]
                        });
                    }
                })
            ]
        })
    });
}
function FieldArray1({ values , setFieldValue  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_14__.FieldArray, {
        name: "safetyItems",
        render: ({ form , push , remove  })=>{
            const { safetyItems  } = form.values;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default()), {
                    mb: 2,
                    spacing: 0,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default()), {
                            justifyContent: "space-between",
                            direction: "row",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default()), {
                                variant: "h4",
                                children: [
                                    "Chargeable Items : ",
                                    safetyItems?.length || 0
                                ]
                            })
                        }),
                        safetyItems?.map((value, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                p: 2,
                                borderRadius: 8,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        container: true,
                                        columns: 12,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                lg: 4,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    name: `safetyItems.${index}.chargeableItemIssued`,
                                                    label: "Chargeable Item Issued*",
                                                    placeHolder: "Chargeable Item Issued"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                lg: 4,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    name: `safetyItems.${index}.division`,
                                                    label: "Division*",
                                                    placeHolder: "Enter the Division"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                lg: 3,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    name: `safetyItems.${index}.penalty`,
                                                    label: "Penalty*",
                                                    placeHolder: "Enter the Penalty",
                                                    type: "number"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                lg: 4,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    name: `safetyItems.${index}.netchargeableamount`,
                                                    label: "Chargeable Amount*",
                                                    placeHolder: "Enter the Chargeable Amount",
                                                    type: "number"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                item: true,
                                                xs: 12,
                                                lg: 8,
                                                px: 10,
                                                mt: "auto",
                                                pb: 2,
                                                children: safetyItems.length > 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    onClick: ()=>{
                                                        values.safetyItems[index].chargeableItemIssued = "";
                                                        values.safetyItems[index].penalty = 0;
                                                        values.safetyItems[index].division = "";
                                                        values.safetyItems[index].netchargeableamount = 0;
                                                        remove(index);
                                                    },
                                                    variant: "contained",
                                                    color: "error",
                                                    sx: {
                                                        float: "right"
                                                    },
                                                    children: [
                                                        "Remove ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_9___default()), {})
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        justifyContent: "flex-start",
                                        alignItems: "flex-start",
                                        spacing: 3,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            display: "flex",
                                            sx: {
                                                alignSelf: "center"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {})
                                ]
                            }, index);
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default()), {
                            onClick: ()=>push({
                                    chargeableItemIssued: "",
                                    penalty: 0,
                                    division: "",
                                    units: "",
                                    rate: 0,
                                    netchargeableamount: 0
                                }),
                            size: "small",
                            sx: {
                                bgcolor: "#2065D1",
                                alignSelf: "flex-start",
                                color: "white",
                                ":hover": {
                                    bgcolor: "#103996"
                                }
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10___default()), {
                                sx: {
                                    color: "white"
                                }
                            })
                        })
                    ]
                })
            });
        }
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_16__.getSession)({
        req: context.req
    });
    const { id  } = context.query;
    const contractors = await _lib_prisma__WEBPACK_IMPORTED_MODULE_17__/* ["default"].contractor.findMany */ .Z.contractor.findMany();
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_17__/* ["default"].user.findUnique */ .Z.user.findUnique({
        where: {
            email: session?.user?.email
        }
    });
    if (user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    const safety = await _lib_prisma__WEBPACK_IMPORTED_MODULE_17__/* ["default"].safety.findUnique */ .Z.safety.findUnique({
        where: {
            id: id
        }
    });
    const safetyItems = await _lib_prisma__WEBPACK_IMPORTED_MODULE_17__/* ["default"].safetyItem.findMany */ .Z.safetyItem.findMany({
        where: {
            safetyId: id
        }
    });
    return {
        props: {
            contractors,
            safety,
            safetyItems
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 3646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 5753:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/LocalizationProvider");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5684,6850,3666], () => (__webpack_exec__(875)));
module.exports = __webpack_exports__;

})();