"use strict";
(() => {
var exports = {};
exports.id = 3459;
exports.ids = [3459];
exports.modules = {

/***/ 6461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ login),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./src/components/Authentication/AuthWrapper1.tsx
var AuthWrapper1 = __webpack_require__(4718);
// EXTERNAL MODULE: ./src/components/Authentication/AuthCardWrapper.tsx
var AuthCardWrapper = __webpack_require__(9463);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "@mui/material/Checkbox"
var Checkbox_ = __webpack_require__(8330);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox_);
// EXTERNAL MODULE: external "@mui/material/CircularProgress"
var CircularProgress_ = __webpack_require__(9048);
var CircularProgress_default = /*#__PURE__*/__webpack_require__.n(CircularProgress_);
// EXTERNAL MODULE: external "@mui/material/FormControl"
var FormControl_ = __webpack_require__(8891);
var FormControl_default = /*#__PURE__*/__webpack_require__.n(FormControl_);
;// CONCATENATED MODULE: external "@mui/material/FormControlLabel"
const FormControlLabel_namespaceObject = require("@mui/material/FormControlLabel");
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/FormHelperText"
var FormHelperText_ = __webpack_require__(6354);
var FormHelperText_default = /*#__PURE__*/__webpack_require__.n(FormHelperText_);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "@mui/material/IconButton"
var IconButton_ = __webpack_require__(7934);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
// EXTERNAL MODULE: external "@mui/material/InputAdornment"
var InputAdornment_ = __webpack_require__(3103);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment_);
// EXTERNAL MODULE: external "@mui/material/InputLabel"
var InputLabel_ = __webpack_require__(911);
var InputLabel_default = /*#__PURE__*/__webpack_require__.n(InputLabel_);
// EXTERNAL MODULE: external "@mui/material/OutlinedInput"
var OutlinedInput_ = __webpack_require__(7730);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput_);
// EXTERNAL MODULE: external "@mui/material/Stack"
var Stack_ = __webpack_require__(8742);
var Stack_default = /*#__PURE__*/__webpack_require__.n(Stack_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: external "@mui/icons-material/Visibility"
var Visibility_ = __webpack_require__(773);
var Visibility_default = /*#__PURE__*/__webpack_require__.n(Visibility_);
// EXTERNAL MODULE: external "@mui/icons-material/VisibilityOff"
var VisibilityOff_ = __webpack_require__(7749);
var VisibilityOff_default = /*#__PURE__*/__webpack_require__.n(VisibilityOff_);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/Authentication/auth-forms/AuthLogin.tsx


// material-ui















// third party


// assets




// ============================|| FIREBASE - LOGIN ||============================ //
const FirebaseLogin = ({ ...others })=>{
    const theme = (0,styles_.useTheme)();
    const [loading, setLoading] = (0,external_react_.useState)(false);
    const [checked, setChecked] = (0,external_react_.useState)(true);
    const router = (0,router_.useRouter)();
    const { data: session , status  } = (0,react_.useSession)();
    const [showPassword, setShowPassword] = (0,external_react_.useState)(false);
    const handleClickShowPassword = ()=>{
        setShowPassword(!showPassword);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                container: true,
                direction: "column",
                justifyContent: "center",
                spacing: 2,
                children: /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                    item: true,
                    xs: 12,
                    container: true,
                    alignItems: "center",
                    justifyContent: "center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                        sx: {
                            mb: 2
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "subtitle1",
                            children: "Sign in with Email address"
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Formik, {
                initialValues: {
                    email: "",
                    password: "",
                    submit: null
                },
                validationSchema: external_yup_.object().shape({
                    email: external_yup_.string().email("Must be a valid email").max(255).required("Email is required"),
                    password: external_yup_.string().max(255).required("Password is required")
                }),
                onSubmit: async (values, { setErrors , setSubmitting  })=>{
                    setSubmitting(true);
                    setLoading(true);
                    await (0,react_.signIn)("credentials", {
                        email: values.email,
                        password: values.password,
                        callbackUrl: "/admin",
                        redirect: false
                    }).then((res)=>{
                        if (res?.error) {
                            if (res.error.includes("Email")) {
                                setErrors({
                                    email: res.error
                                });
                            } else {
                                setErrors({
                                    submit: res.error
                                });
                            }
                            setSubmitting(false);
                        } else {
                            if (session?.user?.role === "admin") {
                                router.push("/admin");
                            } else {
                                router.push("/");
                            }
                        }
                    });
                    setLoading(false);
                    setSubmitting(false);
                },
                children: ({ errors , handleBlur , handleChange , handleSubmit , isSubmitting , touched , values  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        noValidate: true,
                        onSubmit: handleSubmit,
                        ...others,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((FormControl_default()), {
                                fullWidth: true,
                                error: Boolean(touched.email && errors.email),
                                sx: {
                                    ...theme.typography.customInput
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                                        htmlFor: "outlined-adornment-email-login",
                                        children: "Email Address / Username"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                        id: "outlined-adornment-email-login",
                                        type: "email",
                                        value: values.email,
                                        name: "email",
                                        onBlur: handleBlur,
                                        onChange: handleChange,
                                        label: "Email Address / Username",
                                        inputProps: {}
                                    }),
                                    touched.email && errors.email && /*#__PURE__*/ jsx_runtime_.jsx((FormHelperText_default()), {
                                        error: true,
                                        id: "standard-weight-helper-text-email-login",
                                        children: errors.email
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((FormControl_default()), {
                                fullWidth: true,
                                error: Boolean(touched.password && errors.password),
                                sx: {
                                    ...theme.typography.customInput
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                                        htmlFor: "outlined-adornment-password-login",
                                        children: "Password"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                        id: "outlined-adornment-password-login",
                                        type: showPassword ? "text" : "password",
                                        value: values.password,
                                        name: "password",
                                        onBlur: handleBlur,
                                        onChange: handleChange,
                                        endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                            position: "end",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                "aria-label": "toggle password visibility",
                                                onClick: handleClickShowPassword,
                                                onMouseDown: (e)=>e.preventDefault(),
                                                edge: "end",
                                                size: "large",
                                                children: showPassword ? /*#__PURE__*/ jsx_runtime_.jsx((Visibility_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((VisibilityOff_default()), {})
                                            })
                                        }),
                                        label: "Password",
                                        inputProps: {}
                                    }),
                                    touched.password && errors.password && /*#__PURE__*/ jsx_runtime_.jsx((FormHelperText_default()), {
                                        error: true,
                                        id: "standard-weight-helper-text-password-login",
                                        children: errors.password
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                                direction: "row",
                                alignItems: "center",
                                justifyContent: "space-between",
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                            checked: checked,
                                            onChange: (event)=>setChecked(event.target.checked),
                                            name: "checked",
                                            color: "primary"
                                        }),
                                        label: "Remember me"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle1",
                                        color: "secondary",
                                        sx: {
                                            textDecoration: "none",
                                            cursor: "pointer"
                                        },
                                        children: "Forgot Password?"
                                    })
                                ]
                            }),
                            errors.submit && /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    mt: 3
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((FormHelperText_default()), {
                                    error: true,
                                    children: errors.submit
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    mt: 2
                                },
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Button_default()), {
                                    disableElevation: true,
                                    disabled: isSubmitting || loading,
                                    fullWidth: true,
                                    size: "large",
                                    type: "submit",
                                    variant: "contained",
                                    color: "secondary",
                                    children: [
                                        "Sign in",
                                        " ",
                                        loading && /*#__PURE__*/ jsx_runtime_.jsx((CircularProgress_default()), {
                                            size: 15,
                                            sx: {
                                                ml: 1,
                                                color: "#364152"
                                            }
                                        })
                                    ]
                                })
                            })
                        ]
                    })
            })
        ]
    });
};
/* harmony default export */ const AuthLogin = (FirebaseLogin);

;// CONCATENATED MODULE: ./src/pages/login.tsx

// material-ui


// project imports





// assets
// ================================|| AUTH3 - LOGIN ||================================ //
const Login = ()=>{
    const theme = (0,styles_.useTheme)();
    const matchDownSM = (0,material_.useMediaQuery)(theme.breakpoints.down("md"));
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx(AuthWrapper1/* default */.Z, {
        sx: {
            // backgroundImage: `url(/Capture.png)`,
            backgroundColor: "#7010af",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
            width: "100%",
            height: "100%"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
            container: true,
            direction: "column",
            justifyContent: "flex-end",
            sx: {
                minHeight: "100vh"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        justifyContent: "center",
                        alignItems: "center",
                        sx: {
                            minHeight: "calc(100vh - 68px)"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                            item: true,
                            sx: {
                                m: {
                                    xs: 1,
                                    sm: 3
                                },
                                mb: 0
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                direction: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        sx: {
                                            minWidth: {
                                                xs: 400,
                                                lg: 475
                                            },
                                            backgroundImage: `url(/images/auth/loginside.jpg)`,
                                            backgroundRepeat: "no-repeat",
                                            backgroundSize: "cover"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(AuthCardWrapper/* default */.Z, {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                                            container: true,
                                            spacing: 2,
                                            alignItems: "center",
                                            justifyContent: "center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                    item: true,
                                                    sx: {
                                                        mb: 3
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                        container: true,
                                                        direction: matchDownSM ? "column-reverse" : "row",
                                                        alignItems: "center",
                                                        justifyContent: "center",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                            item: true,
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                                                                alignItems: "center",
                                                                justifyContent: "center",
                                                                spacing: 1,
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                                        color: theme.palette.secondary.main,
                                                                        gutterBottom: true,
                                                                        variant: matchDownSM ? "h3" : "h2",
                                                                        children: "Hi, Welcome Back"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                                        variant: "caption",
                                                                        fontSize: "16px",
                                                                        textAlign: matchDownSM ? "center" : "inherit",
                                                                        children: "Enter your credentials to continue"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(AuthLogin, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                                        item: true,
                                                        container: true,
                                                        direction: "column",
                                                        alignItems: "center",
                                                        xs: 12,
                                                        onClick: ()=>router.push("/register"),
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                            variant: "subtitle1",
                                                            sx: {
                                                                textDecoration: "none"
                                                            },
                                                            children: "Don't have an account?"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 12,
                    sx: {
                        m: 3,
                        mt: 1
                    }
                })
            ]
        })
    });
};
/* harmony default export */ const login = (Login);
async function getServerSideProps(context) {
    const session = await (0,react_.getSession)(context);
    if (session) {
        return {
            redirect: {
                destination: session.user?.role === "Admin" ? "/admin" : "/",
                permanent: false
            }
        };
    }
    return {
        props: {}
    };
}


/***/ }),

/***/ 773:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Visibility");

/***/ }),

/***/ 7749:
/***/ ((module) => {

module.exports = require("@mui/icons-material/VisibilityOff");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8330:
/***/ ((module) => {

module.exports = require("@mui/material/Checkbox");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 8891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 6354:
/***/ ((module) => {

module.exports = require("@mui/material/FormHelperText");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 3103:
/***/ ((module) => {

module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 911:
/***/ ((module) => {

module.exports = require("@mui/material/InputLabel");

/***/ }),

/***/ 7730:
/***/ ((module) => {

module.exports = require("@mui/material/OutlinedInput");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1825,9172], () => (__webpack_exec__(6461)));
module.exports = __webpack_exports__;

})();