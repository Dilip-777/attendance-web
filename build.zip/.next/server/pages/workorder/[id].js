"use strict";
(() => {
var exports = {};
exports.id = 2790;
exports.ids = [2790];
exports.modules = {

/***/ 6619:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AddWordOrder),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9876);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6850);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6395);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9648);
/* harmony import */ var _components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9711);
/* harmony import */ var _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3522);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_10__, _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_12__]);
([axios__WEBPACK_IMPORTED_MODULE_10__, _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const fileType = yup__WEBPACK_IMPORTED_MODULE_5__.object().required("Required").optional();
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_5__.object().shape({
    contractorId: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    nature: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    startDate: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    endDate: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    location: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    workDescription: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    repeatOrOneTime: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    alert1Month: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    alert15days: yup__WEBPACK_IMPORTED_MODULE_5__.boolean().required("Required"),
    amendmentDocument: fileType,
    addendumDocument: fileType,
    uploadDocument: fileType
});
function AddWordOrder({ contractors , workorder  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const initialValues = {
        contractorId: workorder?.contractorId || "",
        nature: workorder?.nature || "",
        startDate: workorder?.startDate || "",
        endDate: workorder?.endDate || "",
        location: workorder?.location || "",
        workDescription: workorder?.workDescription || "",
        repeatOrOneTime: workorder?.repeatOrOneTime || "",
        alert1Month: workorder?.alert1Month || false,
        alert15days: workorder?.alert15days || false,
        amendmentDocument: workorder?.amendmentDocument ? {
            newFilename: workorder.amendmentDocument
        } : undefined,
        addendumDocument: workorder?.addendumDocument ? {
            newFilename: workorder.addendumDocument
        } : undefined,
        uploadDocument: workorder?.uploadDocument ? {
            newFilename: workorder.uploadDocument
        } : undefined
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper, {
            sx: {
                height: "83.7vh",
                pt: "1rem",
                pb: "8rem",
                overflow: "hidden auto",
                scrollBehavior: "smooth",
                "&::-webkit-scrollbar": {
                    width: 9
                },
                "&::-webkit-scrollbar-thumb": {
                    backgroundColor: "#bdbdbd",
                    borderRadius: 2
                }
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    sx: {
                        height: "3rem",
                        display: "flex",
                        alignItems: "center"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        variant: "h4",
                        ml: 5,
                        my: "auto",
                        children: workorder ? "Edit Work Order" : "Add Work Order"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_6__.Formik, {
                    initialValues: initialValues,
                    validationSchema: validationSchema,
                    onSubmit: async (values)=>{
                        setLoading(true);
                        if (workorder) {
                            await axios__WEBPACK_IMPORTED_MODULE_10__["default"].put(`/api/workorder`, {
                                id: workorder.id,
                                ...values
                            }).then((res)=>{
                                router.push("/workorder");
                            }).catch((err)=>{
                                console.log(err);
                            });
                        } else {
                            await axios__WEBPACK_IMPORTED_MODULE_10__["default"].post("/api/workorder", values).then((res)=>{
                                console.log(res);
                                router.push("/workorder");
                            }).catch((err)=>{
                                console.log(err);
                            });
                        }
                        setLoading(false);
                    },
                    children: ({ handleSubmit , values , errors  })=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            noValidate: true,
                            onSubmit: handleSubmit,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                    ml: 6,
                                    mt: 2,
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                name: "contractorId",
                                                label: "Contractor Name*",
                                                placeHolder: "Contractor Name",
                                                disabled: false,
                                                options: contractors?.map((contractor)=>({
                                                        value: contractor.id,
                                                        label: contractor.contractorname
                                                    })) || []
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "nature",
                                                label: "Nature*",
                                                placeHolder: "Enter the Nature",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                name: "startDate",
                                                label: "Start Date",
                                                placeHolder: "Enter the Start Date",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                name: "endDate",
                                                label: "End Date",
                                                placeHolder: "Enter the End Date",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "location",
                                                label: "Location*",
                                                placeHolder: "Enter the Location",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "workDescription",
                                                label: "Work Description*",
                                                placeHolder: "Enter the Work Description",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                name: "repeatOrOneTime",
                                                label: "Repeat Or One Time*",
                                                placeHolder: "Repeat Or One Time",
                                                disabled: false,
                                                options: [
                                                    {
                                                        value: "Repeat",
                                                        label: "Repeat"
                                                    },
                                                    {
                                                        value: "One Time",
                                                        label: "One Time"
                                                    }
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                name: "alert1Month",
                                                label: "Alert Before 1 Month before it expires*",
                                                placeHolder: "Alert Before 1 Month before it expires",
                                                disabled: false,
                                                options: [
                                                    {
                                                        value: true,
                                                        label: "Yes"
                                                    },
                                                    {
                                                        value: false,
                                                        label: "No"
                                                    }
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                name: "alert15days",
                                                label: "Alert Before 15 Days before it expires*",
                                                placeHolder: "Alert Before 15 Days before it expires",
                                                disabled: false,
                                                options: [
                                                    {
                                                        value: true,
                                                        label: "Yes"
                                                    },
                                                    {
                                                        value: false,
                                                        label: "No"
                                                    }
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                name: "amendmentDocument",
                                                label: "Amendment Document",
                                                placeholder: "Amendment Document"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                name: "addendumDocument",
                                                label: "Addendum Document",
                                                placeholder: "Addendum Document"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                name: "uploadDocument",
                                                label: "Upload Document",
                                                placeholder: "Upload Document"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    type: "submit",
                                    variant: "contained",
                                    sx: {
                                        float: "right",
                                        mr: 10
                                    },
                                    disabled: loading,
                                    children: [
                                        "Submit",
                                        loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {
                                            size: 15,
                                            sx: {
                                                ml: 1,
                                                color: "#364152"
                                            }
                                        })
                                    ]
                                })
                            ]
                        });
                    }
                })
            ]
        })
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_8__.getSession)({
        req: context.req
    });
    const { id  } = context.query;
    const contractors = await _lib_prisma__WEBPACK_IMPORTED_MODULE_9__/* ["default"].contractor.findMany */ .Z.contractor.findMany();
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_9__/* ["default"].user.findUnique */ .Z.user.findUnique({
        where: {
            email: session?.user?.email
        }
    });
    if (user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    const workorder = await _lib_prisma__WEBPACK_IMPORTED_MODULE_9__/* ["default"].workorder.findUnique */ .Z.workorder.findUnique({
        where: {
            id: id
        }
    });
    return {
        props: {
            contractors,
            workorder
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 3274:
/***/ ((module) => {

module.exports = require("@mui/icons-material/InsertDriveFile");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 8167:
/***/ ((module) => {

module.exports = require("@mui/material/Card");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 8891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 6354:
/***/ ((module) => {

module.exports = require("@mui/material/FormHelperText");

/***/ }),

/***/ 6096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 1856:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/DatePicker");

/***/ }),

/***/ 5753:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/LocalizationProvider");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5684,6850,4503], () => (__webpack_exec__(6619)));
module.exports = __webpack_exports__;

})();