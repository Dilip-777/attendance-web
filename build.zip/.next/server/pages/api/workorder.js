"use strict";
(() => {
var exports = {};
exports.id = 3681;
exports.ids = [3681];
exports.modules = {

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 4365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ workorder)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5031);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(shortid__WEBPACK_IMPORTED_MODULE_1__);


async function workorder(req, res) {
    if (req.method === "POST") {
        const { contractorId , ...rest } = req.body;
        const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
            where: {
                id: contractorId
            }
        });
        if (!contractor) {
            res.status(404).json({
                message: "Contractor not found"
            });
        }
        const body = {
            id: shortid__WEBPACK_IMPORTED_MODULE_1___default().generate(),
            contractorId: contractor?.contractorId.toString(),
            contractorName: contractor?.contractorname,
            ...rest,
            amendmentDocument: rest.amendmentDocument?.newFilename || null,
            addendumDocument: rest.addendumDocument?.newFilename || null,
            uploadDocument: rest.uploadDocument?.newFilename || null
        };
        const workorder = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].workorder.create */ .Z.workorder.create({
            data: body
        });
        res.status(200).json(workorder);
    } else if (req.method === "PUT") {
        const { id , contractorId , ...rest } = req.body;
        const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
            where: {
                id: contractorId
            }
        });
        if (!contractor) {
            res.status(404).json({
                message: "Contractor not found"
            });
        }
        const body = {
            id: id,
            contractorId: contractor?.contractorId.toString(),
            contractorName: contractor?.contractorname,
            ...rest,
            amendmentDocument: rest.amendmentDocument?.newFilename || null,
            addendumDocument: rest.addendumDocument?.newFilename || null,
            uploadDocument: rest.uploadDocument?.newFilename || null
        };
        const workorder = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].workorder.update */ .Z.workorder.update({
            where: {
                id: id
            },
            data: body
        });
        res.status(200).json(workorder);
    } else if (req.method === "DELETE") {
        const { id  } = req.body;
        const workorder = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].workorder["delete"] */ .Z.workorder["delete"]({
            where: {
                id: id
            }
        });
        res.status(200).json(workorder);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4365));
module.exports = __webpack_exports__;

})();