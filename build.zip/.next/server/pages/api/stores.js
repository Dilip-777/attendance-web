"use strict";
(() => {
var exports = {};
exports.id = 9698;
exports.ids = [9698];
exports.modules = {

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 6345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Stores)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);

async function Stores(req, res) {
    if (req.method === "GET") {
        const { contractorid , month  } = req.query;
        if (contractorid && month) {
            const store = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].stores.findFirst */ .Z.stores.findFirst({
                where: {
                    contractorid: parseInt(contractorid),
                    month: month
                }
            });
            res.status(200).json(store);
            return;
        }
        const stores = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].stores.findMany */ .Z.stores.findMany();
        res.status(200).json(stores);
    }
    if (req.method === "POST") {
        const { storeItems , ...rest } = req.body;
        const store = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].stores.create */ .Z.stores.create({
            data: {
                ...rest
            }
        });
        const storeItemsData = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].storeItem.createMany */ .Z.storeItem.createMany({
            data: storeItems,
            skipDuplicates: true
        });
        res.status(200).json({
            success: true
        });
    } else if (req.method === "DELETE") {
        const { id  } = req.body;
        const store = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].stores["delete"] */ .Z.stores["delete"]({
            where: {
                id: id
            }
        });
        res.status(200).json(store);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6345));
module.exports = __webpack_exports__;

})();