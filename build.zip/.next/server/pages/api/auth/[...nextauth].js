"use strict";
(() => {
var exports = {};
exports.id = 3748;
exports.ids = [3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 5328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "authOptions": () => (/* binding */ authOptions),
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/credentials"
const credentials_namespaceObject = require("next-auth/providers/credentials");
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_namespaceObject);
;// CONCATENATED MODULE: external "@next-auth/prisma-adapter"
const prisma_adapter_namespaceObject = require("@next-auth/prisma-adapter");
// EXTERNAL MODULE: ./src/lib/prisma.ts + 1 modules
var prisma = __webpack_require__(9132);
// EXTERNAL MODULE: external "bcryptjs"
var external_bcryptjs_ = __webpack_require__(8432);
var external_bcryptjs_default = /*#__PURE__*/__webpack_require__.n(external_bcryptjs_);
;// CONCATENATED MODULE: ./src/pages/api/auth/[...nextauth].ts




// import { env } from '../../../env/server.mjs';

const authOptions = {
    callbacks: {
        session ({ session , token  }) {
            if (token.id && session.user) {
                session.user.id = token.id;
                session.user.role = token.role;
                session.user.specialRole = token.specialRole;
            }
            return session;
        },
        jwt ({ token , user  }) {
            if (user) {
                token.id = user.id;
                token.role = user.role;
                token.specialRole = user.specialRole;
            }
            return token;
        }
    },
    session: {
        strategy: "jwt"
    },
    adapter: (0,prisma_adapter_namespaceObject.PrismaAdapter)(prisma/* prisma */._),
    providers: [
        credentials_default()({
            name: "Credentials",
            credentials: {
                email: {
                    label: "Email",
                    type: "text"
                },
                password: {
                    label: "Password",
                    type: "password"
                },
                specialRole: {
                    label: "Special Role",
                    type: "text"
                }
            },
            async authorize (credentials, req) {
                const email = credentials?.email;
                const password = credentials?.password;
                const specialRole = credentials?.specialRole;
                if (specialRole) {
                    const user1 = await prisma/* prisma.user.findUnique */._.user.findUnique({
                        where: {
                            email: email
                        }
                    });
                    if (user1) return {
                        ...user1,
                        password: undefined
                    };
                }
                if (!password) {
                    throw new Error(`Please Enter Password`);
                }
                const user = await prisma/* prisma.user.findUnique */._.user.findUnique({
                    where: {
                        email
                    }
                });
                if (user && user.password) {
                    const isPasswordMatched = await external_bcryptjs_default().compare(password, user?.password);
                    if (isPasswordMatched) {
                        return {
                            ...user,
                            password: undefined
                        };
                    } else {
                        throw new Error(`Wrong Password`);
                    }
                } else {
                    throw new Error(`Email Doesn't Exist`);
                }
            }
        })
    ],
    pages: {
        signIn: "/login"
    },
    secret: process.env.NEXTAUTH_SECRET
};
/* harmony default export */ const _nextauth_ = (external_next_auth_default()(authOptions));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5328));
module.exports = __webpack_exports__;

})();