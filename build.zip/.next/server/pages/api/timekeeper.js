"use strict";
(() => {
var exports = {};
exports.id = 1662;
exports.ids = [1662];
exports.modules = {

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);

async function handler(req, res) {
    if (req.method !== "PUT") {
        res.status(405).json({
            name: "Method Not Allowed"
        });
    } else {
        const { comment , uploadDocument , id , userId , userName , role , ...body } = req.body;
        //   const timekeeper = await prisma.timeKeeper.update({
        //     where: {
        //       id: id,
        //     },
        //     data: {
        //       ...body,
        //     }
        // })
        if (role !== "TimeKeeper") {
            const timekeeper = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.update */ .Z.timeKeeper.update({
                where: {
                    id: id
                },
                data: body
            });
        } else {
            const timekeeper = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.update */ .Z.timeKeeper.update({
                where: {
                    id: id
                },
                data: {
                    status: "Pending"
                }
            });
            const savedTimekeeper = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].saveTimekeeper.create */ .Z.saveTimekeeper.create({
                data: {
                    id: id,
                    contractorid: timekeeper.contractorid,
                    contractorname: timekeeper.contractorname,
                    employeeid: timekeeper.employeeid,
                    employeename: timekeeper.employeename,
                    ...body
                }
            });
        }
        const iscommented = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].comment.findMany */ .Z.comment.findMany({
            where: {
                timekeeperId: id,
                userId: userId
            }
        });
        iscommented.length > 0 ? await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].comment.update */ .Z.comment.update({
            where: {
                id: iscommented[0].id
            },
            data: {
                comment: comment
            }
        }) : await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].comment.create */ .Z.comment.create({
            data: {
                comment: comment,
                userId: userId,
                userName: userName,
                role: role,
                timekeeperId: id
            }
        });
        if (uploadDocument) {
            const isDocumentUploaded = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].upload.findMany */ .Z.upload.findMany({
                where: {
                    timekeeperId: id,
                    userId: userId
                }
            });
            isDocumentUploaded.length > 0 ? await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].upload.update */ .Z.upload.update({
                where: {
                    id: isDocumentUploaded[0].id
                },
                data: {
                    document: uploadDocument.newFilename
                }
            }) : await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].upload.create */ .Z.upload.create({
                data: {
                    document: uploadDocument.newFilename,
                    userId: userId,
                    userName: userName,
                    role: role,
                    timekeeperId: id
                }
            });
        }
        res.status(200).json({
            success: true
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(227));
module.exports = __webpack_exports__;

})();