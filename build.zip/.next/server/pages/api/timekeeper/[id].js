"use strict";
(() => {
var exports = {};
exports.id = 6547;
exports.ids = [6547];
exports.modules = {

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 3641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ gettimekeeper)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);

async function gettimekeeper(req, res) {
    const { id , role  } = req.query;
    if (req.method === "GET") {
        try {
            const timekeeper = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.findUnique */ .Z.timeKeeper.findUnique({
                where: {
                    id: id
                }
            });
            res.status(200).json(timekeeper);
        } catch (error) {
            res.status(500).json({
                success: "false",
                message: "Something went wrong"
            });
        }
    } else if (req.method === "PUT") {
        const savedTimekeeper = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].saveTimekeeper.findUnique */ .Z.saveTimekeeper.findUnique({
            where: {
                id: id
            }
        });
        if (savedTimekeeper) {
            await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.update */ .Z.timeKeeper.update({
                where: {
                    id: id
                },
                data: {
                    ...savedTimekeeper,
                    status: "Approved"
                }
            });
            await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].saveTimekeeper["delete"] */ .Z.saveTimekeeper["delete"]({
                where: {
                    id: id
                }
            });
        }
        res.status(200).json({
            success: "true",
            message: "Timekeeper Approved"
        });
    } else if (req.method === "DELETE") {
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].saveTimekeeper["delete"] */ .Z.saveTimekeeper["delete"]({
            where: {
                id: id
            }
        });
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.update */ .Z.timeKeeper.update({
            where: {
                id: id
            },
            data: {
                status: "Rejected"
            }
        });
        res.status(200).json({
            success: "true",
            message: "Timekeeper Rejected"
        });
    } else {
        res.status(405).json({
            name: "Method Not Allowed"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3641));
module.exports = __webpack_exports__;

})();