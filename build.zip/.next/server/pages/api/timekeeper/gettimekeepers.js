"use strict";
(() => {
var exports = {};
exports.id = 7044;
exports.ids = [7044];
exports.modules = {

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 3333:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getTimeKeeper)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);

async function getTimeKeeper(req, res) {
    if (req.method !== "GET") {
        res.status(405).json({
            name: "Method Not Allowed"
        });
    } else {
        const { month , role  } = req.query;
        const timekeepers = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.findMany */ .Z.timeKeeper.findMany({
            where: {
                attendancedate: {
                    contains: month
                }
            }
        });
        //        const data: TimeKeeper[] = await prisma.$queryRaw`
        //   SELECT * FROM "public"."TimeKeeper" WHERE DATE_PART('month', TO_DATE(attendancedate, 'DD/MM/YYYY')) = ${parseInt(month as string)}
        // `;
        // const timekeepers = data?.filter((t) => t.status !== "Pending")
        //   const savedTimekeeper: SaveTimekeeper[] = await prisma.$queryRaw`
        //   SELECT * FROM "public"."SaveTimekeeper" WHERE DATE_PART('month', TO_DATE(attendancedate, 'DD/MM/YYYY')) = ${parseInt(month as string)}
        // `;
        const savedTimekeeper = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].saveTimekeeper.findMany */ .Z.saveTimekeeper.findMany({
            where: {
                attendancedate: {
                    contains: month
                }
            }
        });
        if (role === "HR") {
            res.status(200).json([
                ...savedTimekeeper,
                ...timekeepers
            ]);
        } else if (role === "TimeKeeper") {
            res.status(200).json(timekeepers);
        } else {
            const approved = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.findMany */ .Z.timeKeeper.findMany({
                where: {
                    approvedByTimekeeper: true,
                    attendancedate: {
                        contains: month
                    }
                }
            });
            res.status(200).json(approved);
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3333));
module.exports = __webpack_exports__;

})();