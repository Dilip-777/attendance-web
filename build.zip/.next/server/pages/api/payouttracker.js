"use strict";
(() => {
var exports = {};
exports.id = 1760;
exports.ids = [1760];
exports.modules = {

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 8096:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ payouttracker)
});

// EXTERNAL MODULE: ./src/lib/prisma.ts + 1 modules
var prisma = __webpack_require__(9132);
;// CONCATENATED MODULE: external "dayjs"
const external_dayjs_namespaceObject = require("dayjs");
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_namespaceObject);
// EXTERNAL MODULE: external "shortid"
var external_shortid_ = __webpack_require__(5031);
var external_shortid_default = /*#__PURE__*/__webpack_require__.n(external_shortid_);
;// CONCATENATED MODULE: ./src/pages/api/payouttracker.ts



async function payouttracker(req, res) {
    if (req.method === "POST") {
        const data = req.body;
        const store = await prisma/* default.stores.findFirst */.Z.stores.findFirst({
            where: {
                contractorid: data.contractorId,
                month: data.month
            }
        });
        const safety = await prisma/* default.safety.findFirst */.Z.safety.findFirst({
            where: {
                contractorid: data.contractorId,
                month: data.month
            }
        });
        const { finalpayableamount , ...rest } = data;
        const isexist = await prisma/* default.payoutTracker.findFirst */.Z.payoutTracker.findFirst({
            where: {
                contractorId: data.contractorId,
                month: data.month
            }
        });
        if (isexist) {
            const payouttracker = await prisma/* default.payoutTracker.update */.Z.payoutTracker.update({
                where: {
                    id: isexist.id
                },
                data: {
                    ...rest,
                    finalpayableamount: finalpayableamount - (store?.totalAmount || 0) - (safety?.totalAmount || 0)
                }
            });
            res.status(200).json(payouttracker);
            return;
        }
        const payouttracker = await prisma/* default.payoutTracker.create */.Z.payoutTracker.create({
            data: {
                id: external_shortid_default().generate(),
                ...rest,
                finalpayableamount: finalpayableamount - (store?.totalAmount || 0) - (safety?.totalAmount || 0)
            }
        });
        res.status(200).json(payouttracker);
    }
    if (req.method === "PUT") {
        const { id , ...data } = req.body;
        const payouttracker = await prisma/* default.payoutTracker.update */.Z.payoutTracker.update({
            where: {
                id: id
            },
            data: data
        });
        res.status(200).json(payouttracker);
    }
    if (req.method === "GET") {
        const { month , contractorid  } = req.query;
        if (!month) {
            const payoutrackers = await prisma/* default.payoutTracker.findMany */.Z.payoutTracker.findMany();
            res.status(200).json(payoutrackers);
            return;
        }
        if (!contractorid) {
            const payoutrackers = await prisma/* default.payoutTracker.findMany */.Z.payoutTracker.findMany({
                where: {
                    month: month
                }
            });
            res.status(200).json(payoutrackers);
            return;
        }
        const date = external_dayjs_default()(month, "MM/YYYY");
        const prevMonth = date.subtract(1, "month");
        const prevprevMonth = prevMonth.subtract(1, "month");
        const prevMonthString = prevMonth.format("MM/YYYY");
        const prevprevMonthString = prevprevMonth.format("MM/YYYY");
        const prevYear = date.subtract(1, "year").format("YYYY");
        const prevYearAmount = await prisma/* default.payoutTracker.aggregate */.Z.payoutTracker.aggregate({
            where: {
                month: {
                    contains: prevYear
                },
                contractorId: parseInt(contractorid)
            },
            _sum: {
                finalpayableamount: true
            }
        });
        const prevPayout = await prisma/* default.payoutTracker.findFirst */.Z.payoutTracker.findFirst({
            where: {
                month: prevMonthString,
                contractorId: parseInt(contractorid)
            }
        });
        const prevprevPayout = await prisma/* default.payoutTracker.findFirst */.Z.payoutTracker.findFirst({
            where: {
                month: prevprevMonthString,
                contractorId: parseInt(contractorid)
            }
        });
        const currentpayout = await prisma/* default.payoutTracker.findFirst */.Z.payoutTracker.findFirst({
            where: {
                month: month,
                contractorId: parseInt(contractorid)
            }
        });
        const payoutracker = await prisma/* default.payoutTracker.findFirst */.Z.payoutTracker.findFirst({
            where: {
                month: prevMonthString,
                contractorId: parseInt(contractorid)
            }
        });
        res.status(200).json({
            currentpayout,
            payoutracker,
            prevMonthAmount: prevPayout?.finalpayableamount,
            prevprevMonthAmount: prevprevPayout?.finalpayableamount,
            prevYearAmount: prevYearAmount._sum.finalpayableamount
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8096));
module.exports = __webpack_exports__;

})();