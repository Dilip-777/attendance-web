"use strict";
(() => {
var exports = {};
exports.id = 1406;
exports.ids = [1406];
exports.modules = {

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 5966:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ department)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5031);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(shortid__WEBPACK_IMPORTED_MODULE_1__);


async function department(req, res) {
    const { method  } = req;
    switch(method){
        case "GET":
            try {
                const departments = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].department.findMany */ .Z.department.findMany();
                res.status(200).json(departments);
            } catch (error) {
                res.status(400).json({
                    success: false
                });
            }
            break;
        case "POST":
            // try {
            const isExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].department.findUnique */ .Z.department.findUnique({
                where: {
                    id: req.body.id || ""
                }
            });
            if (isExist) {
                await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].department.update */ .Z.department.update({
                    where: {
                        id: isExist.id
                    },
                    data: {
                        department: req.body.department
                    }
                });
                res.status(200).json({
                    success: true
                });
                return;
            }
            const department1 = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].department.create */ .Z.department.create({
                data: {
                    id: shortid__WEBPACK_IMPORTED_MODULE_1___default().generate(),
                    department: req.body.department
                }
            });
            res.status(201).json(department1);
            break;
        case "PUT":
            try {
                const { id , designations  } = req.body;
                const department = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].department.update */ .Z.department.update({
                    where: {
                        id: id
                    },
                    data: {
                        designations: designations
                    }
                });
                res.status(200).json({
                    success: true
                });
            } catch (error) {
                res.status(400).json({
                    success: false
                });
            }
            break;
        case "DELETE":
            try {
                const { id  } = req.body;
                const department = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].department["delete"] */ .Z.department["delete"]({
                    where: {
                        id: id
                    }
                });
                res.status(200).json(department);
            } catch (error) {
                res.status(400).json({
                    success: false
                });
            }
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5966));
module.exports = __webpack_exports__;

})();