"use strict";
(() => {
var exports = {};
exports.id = 9240;
exports.ids = [9240];
exports.modules = {

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 6857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ designations)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5031);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(shortid__WEBPACK_IMPORTED_MODULE_1__);


async function designations(req, res) {
    if (req.method === "GET") {
        const designations = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].designations.findMany */ .Z.designations.findMany();
        res.status(200).json(designations);
    } else if (req.method === "POST") {
        const data = req.body;
        let id = data.designation;
        id = id.replace(/\s+/g, "").toLowerCase();
        if (data?.gender === "Male") {
            id = "m" + id;
        } else if (data?.gender === "Female") id = "f" + id;
        const isExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].designations.findFirst */ .Z.designations.findFirst({
            where: {
                designationid: id,
                departmentname: data?.departmentname
            }
        });
        if (isExist) return res.status(400).json({
            error: "Designation already exist"
        });
        const designation = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].designations.create */ .Z.designations.create({
            data: {
                id: shortid__WEBPACK_IMPORTED_MODULE_1___default().generate(),
                designationid: id,
                ...data
            }
        });
        res.status(200).json(designation);
    } else if (req.method === "PUT") {
        const data = req.body;
        let id = data.designation;
        id = id.replace(/\s+/g, "").toLowerCase();
        if (data?.gender === "Male") {
            id = "m" + id;
        } else if (data?.gender === "Female") id = "f" + id;
        const designation = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].designations.update */ .Z.designations.update({
            where: {
                id: data?.id
            },
            data: {
                designationid: id,
                ...data
            }
        });
        res.status(200).json(designation);
    } else if (req.method === "DELETE") {
        const data = req.body;
        const designation = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].designations["delete"] */ .Z.designations["delete"]({
            where: {
                id: data?.id
            }
        });
        res.status(200).json(designation);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6857));
module.exports = __webpack_exports__;

})();