"use strict";
(() => {
var exports = {};
exports.id = 6438;
exports.ids = [6438];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 1602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getUser)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_1__);


async function getUser(req, res) {
    const { id  } = req.query;
    if (req.method === "GET") {
        const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.findUnique */ .Z.user.findUnique({
            where: {
                id: id
            }
        });
        res.status(200).json(user);
    }
    if (req.method === "PUT") {
        const data = req.body;
        const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.update */ .Z.user.update({
            where: {
                id: id
            },
            data: data
        });
        res.status(200).json(user);
    }
    if (req.method === "POST") {
        const data = req.body;
        const currentUser = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.findUnique */ .Z.user.findUnique({
            where: {
                id: id
            }
        });
        if (currentUser) {
            const passwordMatched = await bcryptjs__WEBPACK_IMPORTED_MODULE_1___default().compare(data.currentPassword, currentUser.password);
            if (passwordMatched) {
                const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.update */ .Z.user.update({
                    where: {
                        id: id
                    },
                    data: {
                        password: await bcryptjs__WEBPACK_IMPORTED_MODULE_1___default().hash(data.password, 12)
                    }
                });
                res.status(200).json(user);
            } else {
                res.status(400).json({
                    message: "Current Password is wrong"
                });
            }
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1602));
module.exports = __webpack_exports__;

})();