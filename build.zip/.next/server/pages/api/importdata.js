"use strict";
(() => {
var exports = {};
exports.id = 4749;
exports.ids = [4749];
exports.modules = {

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 7114:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ test)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);

async function test(req, res) {
    if (req.method === "GET") {
        res.status(200).json(process.env.DATABASE_URL);
    }
    const data = req.body;
    const { type  } = req.query;
    if (type === "employee") {
        try {
            const employees = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].employee.createMany */ .Z.employee.createMany({
                data: data,
                skipDuplicates: true
            });
            // const employee = await prisma.employee.create({
            //     data: data[0]
            // })
            res.status(200).json({
                success: true
            });
        } catch (error) {
            res.status(400).json({
                success: false,
                error: error
            });
        }
    } else if (type === "contractor") {
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].employee.deleteMany */ .Z.employee.deleteMany();
        const contractors = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.createMany */ .Z.contractor.createMany({
            data: data,
            skipDuplicates: true
        });
        res.status(200).json({
            success: true
        });
    } else {
        const timekeepers = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].timeKeeper.createMany */ .Z.timeKeeper.createMany({
            data: data,
            skipDuplicates: true
        });
        // const timeKeeper = await prisma.timeKeeper.create({
        //    data: data[0]
        // })
        res.status(200).json({
            success: true
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7114));
module.exports = __webpack_exports__;

})();