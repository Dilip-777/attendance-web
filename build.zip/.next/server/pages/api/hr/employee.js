"use strict";
(() => {
var exports = {};
exports.id = 4825;
exports.ids = [4825];
exports.modules = {

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 3871:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ employee)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5031);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(shortid__WEBPACK_IMPORTED_MODULE_1__);


async function employee(req, res) {
    if (req.method === "POST") {
        const { id , contractorId , ...data } = req.body;
        const isExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].employee.findFirst */ .Z.employee.findFirst({
            where: {
                employeeId: data.employeeId
            }
        });
        if (isExist) {
            res.status(409).json({
                message: "Employee Id already exists",
                error: "employeeId"
            });
            return;
        }
        if (id) {
            const employee = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].employee.update */ .Z.employee.update({
                where: {
                    id: id
                },
                data: data
            });
            res.status(200).json(employee);
        } else {
            const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
                where: {
                    contractorId: contractorId
                }
            });
            if (!contractor) {
                res.status(404).json({
                    message: "Contractor not found",
                    error: "contractorId"
                });
                return;
            }
            const employee = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].employee.create */ .Z.employee.create({
                data: {
                    id: shortid__WEBPACK_IMPORTED_MODULE_1___default().generate(),
                    contractorname: contractor.contractorname,
                    contractorId: contractor.contractorId,
                    ...data
                }
            });
            res.status(200).json(employee);
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3871));
module.exports = __webpack_exports__;

})();