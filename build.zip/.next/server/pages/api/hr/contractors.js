"use strict";
(() => {
var exports = {};
exports.id = 7831;
exports.ids = [7831];
exports.modules = {

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 37:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ contractors)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5031);
/* harmony import */ var shortid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(shortid__WEBPACK_IMPORTED_MODULE_1__);


async function contractors(req, res) {
    if (req.method === "GET") {
        const contractors = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.findMany */ .Z.contractor.findMany();
        res.status(200).json(contractors);
    }
    if (req.method === "POST") {
        const data = req.body;
        const isExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
            where: {
                contractorId: data.contractorId
            }
        });
        if (isExist) {
            res.status(409).json({
                message: "Contractor already exists",
                error: "contractorId"
            });
            return;
        }
        const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.create */ .Z.contractor.create({
            data: {
                id: shortid__WEBPACK_IMPORTED_MODULE_1___default().generate(),
                ...data,
                businessdetaildocument: data.businessdetaildocument?.newFilename || null,
                uploadutilitybill: data.uploadutilitybill?.newFilename || null,
                memorandam_of_associate: data.memorandam_of_associate?.newFilename || null,
                listofdirector: data.listofdirector?.newFilename || null,
                profileofkeyperson: data.profileofkeyperson?.newFilename || null,
                uploadbranchdetail: data.uploadbranchdetail?.newFilename || null,
                uploadreturndetail: data.uploadreturndetail?.newFilename || null,
                upload_registration_cert: data.upload_registration_cert?.newFilename || null,
                upload_licence1: data.upload_licence1?.newFilename || null,
                upload_licence2: data.upload_licence2?.newFilename || null,
                upload_list_ofclientele: data.upload_list_ofclientele?.newFilename || null,
                upload_certificate_services: data.upload_certificate_services?.newFilename || null,
                upload_doc1: data.upload_doc1?.newFilename || null,
                upload_doc2: data.upload_doc2?.newFilename || null
            }
        });
        res.status(200).json(contractor);
    }
    if (req.method === "PUT") {
        const { id , ...data } = req.body;
        const contractorexists = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
            where: {
                id: id
            }
        });
        if (!contractorexists) {
            res.status(404).json({
                message: "Contractor not found"
            });
        }
        const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.update */ .Z.contractor.update({
            where: {
                id: id
            },
            data: data
        });
        res.status(200).json(contractor);
    }
    if (req.method === "DELETE") {
        const { id  } = req.body;
        const contractorexists = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
            where: {
                id: id
            }
        });
        if (!contractorexists) {
            res.status(404).json({
                message: "Contractor not found"
            });
        }
        const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].contractor["delete"] */ .Z.contractor["delete"]({
            where: {
                id: id
            }
        });
        res.status(200).json(contractor);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(37));
module.exports = __webpack_exports__;

})();