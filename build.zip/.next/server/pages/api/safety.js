"use strict";
(() => {
var exports = {};
exports.id = 2723;
exports.ids = [2723];
exports.modules = {

/***/ 9132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma),
  "_": () => (/* binding */ prisma)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 2274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Stores)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9132);

async function Stores(req, res) {
    if (req.method === "GET") {
        const { contractorid , month  } = req.query;
        if (contractorid && month) {
            const safety = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].safety.findFirst */ .Z.safety.findFirst({
                where: {
                    contractorid: parseInt(contractorid),
                    month: month
                }
            });
            res.status(200).json(safety);
            return;
        }
        const safety = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].safety.findMany */ .Z.safety.findMany();
        res.status(200).json(safety);
    }
    if (req.method === "POST") {
        const { id , safetyItems , ...data } = req.body;
        const isExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].safety.findUnique */ .Z.safety.findUnique({
            where: {
                id: id
            }
        });
        if (isExist) {
            const safety = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].safety.update */ .Z.safety.update({
                where: {
                    id: id
                },
                data: {
                    id: id,
                    ...data
                }
            });
            res.status(200).json(safety);
        } else {
            const safety = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].safety.create */ .Z.safety.create({
                data: {
                    id: id,
                    ...data
                }
            });
            const safetyItemsData = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].safetyItem.createMany */ .Z.safetyItem.createMany({
                data: safetyItems,
                skipDuplicates: true
            });
            res.status(200).json(safety);
        }
    } else if (req.method === "DELETE") {
        const { id  } = req.body;
        const safety = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].safety["delete"] */ .Z.safety["delete"]({
            where: {
                id: id
            }
        });
        res.status(200).json(safety);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2274));
module.exports = __webpack_exports__;

})();