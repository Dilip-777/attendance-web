"use strict";
(() => {
var exports = {};
exports.id = 686;
exports.ids = [686];
exports.modules = {

/***/ 1248:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DepartmentReport)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(681);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__]);
axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function DepartmentReport({ departments  }) {
    const [department, setDepartment] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("8HR");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const handleSubmit = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`/api/report?type=department&department=${department}`);
        console.log(res);
        const tableRows = [
            [
                "contractorid",
                "Contractor Name",
                "Service Detail",
                "Supplier Detail",
                "Mobile Number",
                "Office Address",
                "Email"
            ]
        ];
        res.data.forEach((item)=>{
            tableRows.push([
                item.contractorId.toString(),
                item.contractorname,
                item.servicedetail,
                item.supplierdetail,
                item.mobilenumber,
                item.officeaddress || "-",
                (item?.emailid) || "-"
            ]);
        });
        const csvContent = `${tableRows.map((row)=>row.join(",")).join("\n")}`;
        // Download CSV file
        const blob = new Blob([
            csvContent
        ], {
            type: "text/csv;charset=utf-8;"
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "DepartmentReport.csv");
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        spacing: 3,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h4",
                children: "Department Wise Report"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                sx: {
                    maxWidth: "7rem"
                },
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        value: department,
                        handleChange: (value)=>setDepartment(value),
                        options: departments.map((item)=>({
                                value: item.department,
                                label: item.department
                            })),
                        label: "Select the Department"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleSubmit,
                        variant: "contained",
                        disabled: loading,
                        children: [
                            "Print",
                            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                                size: 15,
                                sx: {
                                    ml: 1,
                                    color: "#364152"
                                }
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6826:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DesignationReport)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(681);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__]);
axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function DesignationReport({ designations  }) {
    const [designation, setDesignation] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("8MW");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    // const departments = [
    //   "8MW",
    //   "20MW",
    //   "DM Plant",
    //   "QC",
    //   "STORE",
    //   "K7",
    //   "RMHS",
    //   "PS",
    //   "HK GARDEN",
    //   "SVR",
    //   "ELE",
    //   "LCO",
    //   "TMAN",
    //   "FILTER",
    //   "PO",
    //   "BCO",
    //   "SRFILTER",
    //   "INCHARGE",
    //   "MO",
    //   "SHIFTINCH",
    //   "GC",
    //   "SBO",
    //   "LMAN",
    //   "TMES",
    //   "JRELE",
    //   "HELPER",
    //   "Colony",
    // ];
    const handleSubmit = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`/api/report?type=designation&designation=${designation}`);
        console.log(res);
        const tableRows = [
            [
                "employeeid",
                "Employee",
                "Contractor Name",
                "Department",
                "Designation",
                "Gender",
                "Basic Salary",
                "Email"
            ]
        ];
        res.data.forEach((item)=>{
            tableRows.push([
                item.employeeId.toString(),
                item.employeename,
                item.contractorname,
                item.department,
                item.designation,
                item.gender,
                item.basicsalary.toString(),
                item?.emailid
            ]);
        });
        const csvContent = `${tableRows.map((row)=>row.join(",")).join("\n")}`;
        // Download CSV file
        const blob = new Blob([
            csvContent
        ], {
            type: "text/csv;charset=utf-8;"
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "DesignationReport.csv");
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        spacing: 3,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h4",
                children: "Man Power Report"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                sx: {
                    maxWidth: "7rem"
                },
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        value: designation,
                        handleChange: (v)=>setDesignation(v),
                        options: designations.map((d)=>({
                                value: d,
                                label: d
                            })),
                        label: "Select  the Designation"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleSubmit,
                        variant: "contained",
                        disabled: loading,
                        children: [
                            "Print",
                            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                                size: 15,
                                sx: {
                                    ml: 1,
                                    color: "#364152"
                                }
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5744:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ManPowerReport)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(681);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__]);
axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function ManPowerReport() {
    const [department, setDepartment] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("8HR");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const handleSubmit = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`/api/report?type=manpower&department=${department}`);
        console.log(res);
        const tableRows = [
            [
                "employeeid",
                "Employee",
                "Contractor Name",
                "Designation",
                "Department",
                "Gender",
                "Basic Salary",
                "Email"
            ]
        ];
        res.data.forEach((item)=>{
            tableRows.push([
                item.employeeId.toString(),
                item.employeename,
                item.contractorname,
                item.designation,
                item.department,
                item.gender,
                item.basicsalary.toString(),
                item?.emailid
            ]);
        });
        const csvContent = `${tableRows.map((row)=>row.join(",")).join("\n")}`;
        // Download CSV file
        const blob = new Blob([
            csvContent
        ], {
            type: "text/csv;charset=utf-8;"
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "ManPowerReport.csv");
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        spacing: 3,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h4",
                children: "Man Power Report"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                sx: {
                    maxWidth: "7rem"
                },
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        value: department,
                        handleChange: (v)=>setDepartment(v),
                        options: [
                            {
                                value: "8HR",
                                label: "8HR"
                            },
                            {
                                value: "12HR",
                                label: "12HR"
                            },
                            {
                                value: "CCM",
                                label: "CCM"
                            },
                            {
                                value: "LRF",
                                label: "LRF"
                            },
                            {
                                value: "Colony",
                                label: "Colony"
                            }
                        ],
                        label: "Select  the Department"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleSubmit,
                        variant: "contained",
                        disabled: loading,
                        children: [
                            "Print",
                            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                                size: 15,
                                sx: {
                                    ml: 1,
                                    color: "#364152"
                                }
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5969:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SalaryReport)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(681);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__]);
axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function SalaryReport({ contractors  }) {
    const [contractor, setContractor] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(contractors[0].contractorname || "");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const handleSubmit = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`/api/report?type=salary&contractor=${contractor}`);
        console.log(res);
        const tableRows = [
            [
                "Contractor Id",
                "Contractor Name",
                "Month",
                "Final Amount",
                "Net Payable",
                "Deduction",
                "Actual Paid Out Money",
                "Balance"
            ]
        ];
        res.data.forEach((item)=>{
            tableRows.push([
                item.contractorId.toString(),
                item.contractorName,
                item.month,
                item.amount.toString(),
                item.finalpayableamount.toString(),
                item.deduction.toString(),
                item.actualpaidoutmoney.toString(),
                item.balance.toString()
            ]);
        });
        const csvContent = `${tableRows.map((row)=>row.join(",")).join("\n")}`;
        // Download CSV file
        const blob = new Blob([
            csvContent
        ], {
            type: "text/csv;charset=utf-8;"
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "Contractor_Payout.csv");
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        spacing: 3,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h4",
                children: "Salary Report"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                sx: {
                    maxWidth: "7rem"
                },
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        value: contractor,
                        handleChange: (v)=>setContractor(v),
                        options: contractors.map((contractor)=>({
                                value: contractor.contractorname,
                                label: contractor.contractorname
                            })),
                        label: "Contractor"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        sx: {
                            maxWidth: "7rem"
                        },
                        onClick: handleSubmit,
                        variant: "contained",
                        disabled: loading,
                        children: [
                            "Print",
                            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                                size: 15,
                                sx: {
                                    ml: 1,
                                    color: "#364152"
                                }
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1966:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WorkerReport)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(681);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__]);
axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function WorkerReport({ contractors  }) {
    const [contractor, setContractor] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(contractors[0].contractorId || 0);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const handleSubmit = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`/api/report?type=worker&contractor=${contractor}`);
        console.log(res);
        const tableRows = [
            [
                "employeeid",
                "Employee",
                "Contractor Name",
                "Designation",
                "Department",
                "Gender",
                "Basic Salary",
                "Email"
            ]
        ];
        res.data.forEach((item)=>{
            tableRows.push([
                item.employeeId.toString(),
                item.employeename,
                item.contractorname,
                item.designation,
                item.department,
                item.gender,
                item.basicsalary.toString(),
                item?.emailid
            ]);
        });
        const csvContent = `${tableRows.map((row)=>row.join(",")).join("\n")}`;
        // Download CSV file
        const blob = new Blob([
            csvContent
        ], {
            type: "text/csv;charset=utf-8;"
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "WorkorderReport.csv");
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        spacing: 3,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h4",
                children: "Worker Report"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                sx: {
                    maxWidth: "7rem"
                },
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        value: contractor,
                        handleChange: (v)=>setContractor(v),
                        options: contractors.map((contractor)=>({
                                value: contractor.contractorId,
                                label: contractor.contractorname
                            })),
                        label: "Contractor"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleSubmit,
                        variant: "contained",
                        disabled: loading,
                        children: [
                            "Print",
                            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                                size: 15,
                                sx: {
                                    ml: 1,
                                    color: "#364152"
                                }
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export prisma */
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();
if (false) {}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (prisma);


/***/ }),

/***/ 7444:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Reports),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Report_departmentreport__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1248);
/* harmony import */ var _components_Report_designationreport__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6826);
/* harmony import */ var _components_Report_manpowerreport__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5744);
/* harmony import */ var _components_Report_salaryreport__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5969);
/* harmony import */ var _components_Report_workerreport__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1966);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6395);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Report_departmentreport__WEBPACK_IMPORTED_MODULE_1__, _components_Report_designationreport__WEBPACK_IMPORTED_MODULE_2__, _components_Report_manpowerreport__WEBPACK_IMPORTED_MODULE_3__, _components_Report_salaryreport__WEBPACK_IMPORTED_MODULE_4__, _components_Report_workerreport__WEBPACK_IMPORTED_MODULE_5__]);
([_components_Report_departmentreport__WEBPACK_IMPORTED_MODULE_1__, _components_Report_designationreport__WEBPACK_IMPORTED_MODULE_2__, _components_Report_manpowerreport__WEBPACK_IMPORTED_MODULE_3__, _components_Report_salaryreport__WEBPACK_IMPORTED_MODULE_4__, _components_Report_workerreport__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function TabPanel(props) {
    const { children , value , index , ...other } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        role: "tabpanel",
        hidden: value !== index,
        id: `simple-tabpanel-${index}`,
        "aria-labelledby": `simple-tab-${index}`,
        ...other,
        children: value === index && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Box, {
            sx: {
                p: 3
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                children: children
            })
        })
    });
}
function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        "aria-controls": `simple-tabpanel-${index}`
    };
}
function Reports({ contractors , workorders , departments , designations  }) {
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const handleChange = (event, newValue)=>{
        setValue(newValue);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Paper, {
        sx: {
            width: "100%",
            mb: 2,
            p: 2
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                variant: "h3",
                sx: {
                    p: 2,
                    m: 0,
                    fontWeight: "500"
                },
                children: "Reports"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Divider, {
                sx: {
                    my: 1,
                    width: "100%"
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Box, {
                sx: {
                    width: "100%"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Box, {
                        sx: {
                            borderBottom: 1,
                            borderColor: "divider"
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Tabs, {
                            value: value,
                            onChange: handleChange,
                            "aria-label": "basic tabs example",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Tab, {
                                    label: "contractor Worker Report",
                                    ...a11yProps(0)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Tab, {
                                    label: "contractor Salary Report",
                                    ...a11yProps(1)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Tab, {
                                    label: "Department wise Contractors",
                                    ...a11yProps(2)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Tab, {
                                    label: "Total Man Power Report",
                                    ...a11yProps(3)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Tab, {
                                    label: "Designation wise Report",
                                    ...a11yProps(4)
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabPanel, {
                        value: value,
                        index: 0,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Report_workerreport__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            contractors: contractors
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabPanel, {
                        value: value,
                        index: 1,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Report_salaryreport__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            contractors: contractors
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabPanel, {
                        value: value,
                        index: 2,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Report_departmentreport__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            departments: departments
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabPanel, {
                        value: value,
                        index: 3,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Report_manpowerreport__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabPanel, {
                        value: value,
                        index: 4,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Report_designationreport__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            designations: designations.map((d)=>d.designation)
                        })
                    })
                ]
            })
        ]
    });
}
const getServerSideProps = async ({ req  })=>{
    const contractors = await _lib_prisma__WEBPACK_IMPORTED_MODULE_6__/* ["default"].contractor.findMany */ .Z.contractor.findMany();
    const workorders = await _lib_prisma__WEBPACK_IMPORTED_MODULE_6__/* ["default"].workorder.findMany */ .Z.workorder.findMany();
    const departments = await _lib_prisma__WEBPACK_IMPORTED_MODULE_6__/* ["default"].department.findMany */ .Z.department.findMany();
    const designations = await _lib_prisma__WEBPACK_IMPORTED_MODULE_6__/* ["default"].designations.findMany */ .Z.designations.findMany();
    return {
        props: {
            contractors,
            workorders,
            departments,
            designations
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [681], () => (__webpack_exec__(7444)));
module.exports = __webpack_exports__;

})();