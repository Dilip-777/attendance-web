"use strict";
(() => {
var exports = {};
exports.id = 1471;
exports.ids = [1471];
exports.modules = {

/***/ 1489:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3765);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Alert__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9048);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9174);
/* harmony import */ var _mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6302);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_8__]);
axios__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











function ImportData() {
    // on change states
    const [excelFile, setExcelFile] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(null);
    const [excelFileError, setExcelFileError] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const [key, setKey] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(0);
    // submit
    const [excelData, setExcelData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(null);
    // it will contain array of objects
    // handle File
    const fileType = [
        "application/vnd.xlsx",
        "application/vnd.ms-excel"
    ];
    const handleFile = (e)=>{
        let selectedFile = e.target.files[0];
        if (selectedFile) {
            let reader = new FileReader();
            reader.readAsArrayBuffer(selectedFile);
            reader.onload = (e)=>{
                console.log(e.target?.result);
                const workbook = xlsx__WEBPACK_IMPORTED_MODULE_10__.read(e.target?.result, {
                    type: "buffer"
                });
                const worksheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[worksheetName];
                const data = xlsx__WEBPACK_IMPORTED_MODULE_10__.utils.sheet_to_json(worksheet);
                console.log(data);
                importing(data);
            };
            setKey(key + 1);
        }
    };
    const handleClick = ()=>{
        setOpen(true);
    };
    const handleClose = (event, reason)=>{
        if (reason === "clickaway") {
            return;
        }
        setOpen(false);
    };
    const action = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_9___default().Fragment), {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default()), {
            size: "small",
            "aria-label": "close",
            color: "inherit",
            onClick: handleClose,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default()), {
                fontSize: "small"
            })
        })
    });
    const getDate = (excelDate)=>{
        // const excelDate = 44986;
        const date = new Date((excelDate - (25567 + 2)) * 86400 * 1000);
        const formattedDate = `${date.getDate().toString().padStart(2, "0")}/${(date.getMonth() + 1).toString().padStart(2, "0")}/${date.getFullYear()}`;
        return formattedDate;
    };
    const importing = async (data)=>{
        console.log(data);
        const keys = [];
        const indices = [];
        data.forEach((d, index)=>{
            [
                "contractorname",
                "contractorId",
                "employeeName",
                "employeeId",
                "designation",
                "department"
            ].forEach((key)=>{
                if (!d[key]) {
                    if (keys.indexOf(key) === -1) {
                        keys.push(key);
                    }
                    if (!indices.includes(index + 1)) {
                        indices.push(index + 1);
                    }
                }
            });
        });
        if (keys.length > 0) {
            setMessage(`Please check the following keys: ${keys.join(", ")} at rows: ${indices.join(", ")}`);
            setError(true);
            handleClick();
            return;
        }
        const body = data// .filter((d: any, i: number) => )
        .map((data)=>({
                employeeId: data.employeeId,
                employeename: data.employeeName,
                contractorname: data.contractorname,
                contractorId: data.contractorId,
                designation: data.designation,
                department: data.department,
                gender: data.gender || "Male",
                phone: data.phone?.toString() || "",
                emailid: data.emailid || "",
                basicsalary_in_duration: data.basicsalary_in_duration || "",
                basicsalary: data.basicsalary || 0,
                allowed_wrking_hr_per_day: data.allowed_wrking_hr_per_day || 0,
                servicecharge: data.servicecharge || 0,
                gst: data.gst || 0,
                tds: data.tds || 0
            }));
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_8__["default"].post("/api/importdata?type=employee", body).then((res)=>{
            setError(false);
            handleClick();
        }).catch((err)=>{
            setMessage("Please Provide Valid Data");
            setError(true);
            handleClick();
        });
        setLoading(false);
    };
    // new Date(timeValue * 24 * 60 * 60 * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default()), {
        direction: "row",
        alignItems: "center",
        spacing: 2,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                disabled: loading,
                variant: "contained",
                component: "label",
                children: [
                    "Upload",
                    loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default()), {
                        size: 15,
                        sx: {
                            ml: 1,
                            color: "#364152"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        hidden: true,
                        type: "file",
                        className: "form-control",
                        onChange: handleFile,
                        required: true
                    }, key)
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6___default()), {
                open: open,
                autoHideDuration: 6000,
                onClose: handleClose,
                action: action,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Alert__WEBPACK_IMPORTED_MODULE_2___default()), {
                    onClose: handleClose,
                    severity: error ? "error" : "success",
                    sx: {
                        width: "100%"
                    },
                    children: error ? message : "Data Uploaded Successfully"
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImportData);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5239:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Employees),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6395);
/* harmony import */ var _components_Table_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8525);
/* harmony import */ var _components_employeeImport__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1489);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_employeeImport__WEBPACK_IMPORTED_MODULE_5__]);
_components_employeeImport__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const createHeadCells = (id, label, numeric, included)=>{
    return {
        id: id,
        label: label,
        numeric: numeric,
        included: included
    };
};
const headCells1 = [
    createHeadCells("contractorname", "Contractor Name", false, false),
    createHeadCells("contractorId", "Contractor ID", false, false),
    createHeadCells("employeeId", "Employee ID", false, false),
    createHeadCells("employeename", "Employee Name", false, false),
    createHeadCells("designation", "Designation", false, false),
    createHeadCells("department", "Department", false, false),
    createHeadCells("gender", "Gender", false, false),
    createHeadCells("phone", "Phone Number", true, false),
    createHeadCells("emailid", "Email", false, false),
    createHeadCells("basicsalary_in_duration", "Basic Salary In Duration", false, false),
    createHeadCells("basicsalary", "Basic Salary", false, false),
    createHeadCells("allowed_wrking_hr_per_day", "Allowed Working Hours Per Day", false, false),
    createHeadCells("servicecharge", "Service Charge", false, false),
    createHeadCells("gst", "GST", true, false),
    createHeadCells("tds", "TDS", true, false)
];
function Employees({ employees  }) {
    const [filterName, setFilterName] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        headcells: headCells1,
        rows: employees.filter((employee)=>employee.employeename.toLowerCase().includes(filterName.toLowerCase())),
        filterName: filterName,
        setFilterName: setFilterName,
        editLink: "/employees",
        upload: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_employeeImport__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_2__.getSession)({
        req: context.req
    });
    const employees = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* ["default"].employee.findMany */ .Z.employee.findMany();
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* ["default"].user.findUnique */ .Z.user.findUnique({
        where: {
            email: session?.user?.email
        }
    });
    if (user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    return {
        props: {
            employees
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 1664:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 3866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FilterList");

/***/ }),

/***/ 4752:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Launch");

/***/ }),

/***/ 8911:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocalPrintshop");

/***/ }),

/***/ 8017:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 773:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Visibility");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3765:
/***/ ((module) => {

module.exports = require("@mui/material/Alert");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8330:
/***/ ((module) => {

module.exports = require("@mui/material/Checkbox");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 3103:
/***/ ((module) => {

module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 7730:
/***/ ((module) => {

module.exports = require("@mui/material/OutlinedInput");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 9174:
/***/ ((module) => {

module.exports = require("@mui/material/Snackbar");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 8099:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 7308:
/***/ ((module) => {

module.exports = require("@mui/material/TablePagination");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6302:
/***/ ((module) => {

module.exports = require("xlsx");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7972,8745,8525], () => (__webpack_exec__(5239)));
module.exports = __webpack_exports__;

})();