"use strict";
(() => {
var exports = {};
exports.id = 9616;
exports.ids = [9616];
exports.modules = {

/***/ 9940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "S": () => (/* binding */ print)
});

;// CONCATENATED MODULE: external "docx"
const external_docx_namespaceObject = require("docx");
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
var external_lodash_default = /*#__PURE__*/__webpack_require__.n(external_lodash_);
;// CONCATENATED MODULE: ./src/components/PrintFinalSheet/tableHead.tsx

function TableHead({ department  }) {
    const headers = [
        "Designation",
        "Type",
        "Total Man days",
        "Rate",
        "Total Amount",
        "Total Overtime",
        "OT Amount",
        "Total Amount",
        "Service Charge",
        "Service Charge Amount",
        "Taxable",
        "GST",
        "Bill Amount",
        "TDS",
        "Net Payable"
    ];
    const ccmheader = [
        "Designation",
        "Total Man days",
        "Rate",
        "Total Amount",
        "Total Overtime",
        "OT Amount",
        "Taxable",
        "GST",
        "Bill Amount",
        "TDS",
        "Net Payable"
    ];
    const headcells = department === "8HR" || department === "12HR" || department === "Colony" ? headers : ccmheader;
    return headcells.map((headcell)=>new external_docx_namespaceObject.TableCell({
            children: [
                new external_docx_namespaceObject.Paragraph({
                    children: [
                        new external_docx_namespaceObject.TextRun({
                            text: `${headcell}`,
                            bold: true,
                            size: 13
                        })
                    ],
                    alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                    spacing: {
                        after: 10,
                        before: 10
                    }
                })
            ],
            width: {
                size: 10,
                type: external_docx_namespaceObject.WidthType.PERCENTAGE
            },
            margins: {
                top: 100,
                bottom: 100,
                left: 30,
                right: 30
            },
            columnSpan: 1,
            verticalAlign: external_docx_namespaceObject.VerticalAlign.CENTER
        }));
}

;// CONCATENATED MODULE: ./src/components/PrintFinalSheet/table.tsx



const tableCell = (text)=>{
    return new external_docx_namespaceObject.TableCell({
        children: [
            new external_docx_namespaceObject.Paragraph({
                children: [
                    new external_docx_namespaceObject.TextRun({
                        text: `${text}`,
                        size: 11
                    })
                ],
                alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                spacing: {
                    after: 50,
                    before: 50
                }
            })
        ],
        width: {
            size: 10,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
};
const tableRow = (text, colspan, length, value)=>{
    return new external_docx_namespaceObject.TableRow({
        children: [
            new external_docx_namespaceObject.TableCell({
                children: [
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: "  ",
                                size: 11
                            })
                        ],
                        alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                        spacing: {
                            after: 50,
                            before: 50
                        }
                    })
                ],
                width: {
                    size: 10,
                    type: external_docx_namespaceObject.WidthType.PERCENTAGE
                },
                columnSpan: length
            }),
            new external_docx_namespaceObject.TableCell({
                children: [
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: `${text}`,
                                size: 13,
                                bold: true
                            })
                        ],
                        alignment: external_docx_namespaceObject.AlignmentType.LEFT,
                        spacing: {
                            after: 50,
                            before: 50
                        }
                    })
                ],
                width: {
                    size: 10,
                    type: external_docx_namespaceObject.WidthType.PERCENTAGE
                },
                columnSpan: colspan
            }),
            new external_docx_namespaceObject.TableCell({
                children: [
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: `${value}`,
                                size: 11
                            })
                        ],
                        alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                        spacing: {
                            after: 50,
                            before: 50
                        }
                    })
                ],
                width: {
                    size: 10,
                    type: external_docx_namespaceObject.WidthType.PERCENTAGE
                }
            })
        ]
    });
};
function DocTable({ rows , total , department , safetypenality , deduction , designations  }) {
    const side8hr = [
        {
            main: "8MW",
            sub: "M",
            id: "m8"
        },
        {
            main: "8MW",
            sub: "F",
            id: "f8"
        },
        {
            main: "20MW",
            sub: "M",
            id: "m20"
        },
        {
            main: "20MW",
            sub: "F",
            id: "f20"
        },
        {
            main: "DM",
            sub: "M",
            id: "dm"
        },
        {
            main: "QC",
            sub: "M",
            id: "qc"
        },
        {
            main: "Store",
            sub: "M",
            id: "store"
        },
        {
            main: "K-7",
            sub: "M",
            id: "k7m"
        },
        {
            main: "K-7",
            sub: "F",
            id: "k7f"
        },
        {
            main: "RMHS",
            sub: "M",
            id: "rmhs"
        },
        {
            main: "PS",
            sub: "F",
            id: "ps"
        },
        {
            main: "HK",
            sub: "M",
            id: "hk"
        },
        {
            main: "SVR",
            sub: "M",
            id: "svr"
        },
        {
            main: "TOTAL",
            sub: " ",
            id: "total"
        }
    ];
    const sideccm = [
        {
            main: "ELE",
            id: "ele"
        },
        {
            main: "LCO",
            id: "lco"
        },
        {
            main: "TMAN",
            id: "tman"
        },
        {
            main: "FILTER",
            id: "filter"
        },
        {
            main: "PO",
            id: "po"
        },
        {
            main: "BCO",
            id: "bco"
        },
        {
            main: "SRFILTER",
            id: "srfilter"
        },
        {
            main: "INCHARGE",
            id: "incharge"
        },
        {
            main: "MO",
            id: "mo"
        },
        {
            main: "SHIFT INCH",
            id: "shiftinch"
        },
        {
            main: "GC",
            id: "gc"
        },
        {
            main: "SVR",
            id: "svr"
        },
        {
            main: "SBO",
            id: "sbo"
        },
        {
            main: "LMAN",
            id: "lman"
        },
        {
            main: "FORMAN",
            id: "forman"
        },
        {
            main: "TMES SON",
            id: "tmesson"
        },
        {
            main: "LMES",
            id: "lmes"
        },
        {
            main: "JRELE",
            id: "jrele"
        },
        {
            main: "HELPER",
            id: "helper"
        },
        {
            main: "Total",
            id: "total"
        }
    ];
    const sidelrf = [
        {
            main: "ELE",
            id: "ele"
        },
        {
            main: "FILTER",
            id: "filter"
        },
        {
            main: "SRFILTER",
            id: "srfilter"
        },
        {
            main: "SVR",
            id: "svr"
        },
        {
            main: "LMES",
            id: "lmes"
        },
        {
            main: "HELPER",
            id: "helper"
        },
        {
            main: "Total",
            id: "total"
        }
    ];
    const sidecolony = [
        {
            main: "Colony",
            sub: "Male",
            id: "m"
        },
        {
            main: "Colony",
            sub: "Female",
            id: "f"
        }
    ];
    const sidebar = designations.filter((d)=>d.departmentname === department).map((d)=>{
        if (d.gender === "Male") return {
            main: d.designation,
            sub: "M",
            id: d.designationid
        };
        else if (d.gender === "Female") return {
            main: d.designation,
            sub: "F",
            id: d.designationid
        };
        else return {
            main: d.designation,
            id: d.designationid
        };
    });
    if (department === "Colony") {
        sidebar.push(...sidecolony);
    }
    switch(department){
        case "8HR":
        case "12HR":
        case "Colony":
            sidebar.push({
                main: "Total",
                sub: " ",
                id: "total"
            });
            break;
        case "CCM":
        case "LRF":
            sidebar.push({
                main: "Total",
                id: "total"
            });
            break;
        default:
            break;
    }
    const colspan = department === "CCM" || department === "LRF" ? 5 : 9;
    const rowspan = 6;
    const table = new external_docx_namespaceObject.Table({
        rows: [
            new external_docx_namespaceObject.TableRow({
                children: TableHead({
                    department: department
                })
            }),
            ...sidebar.map((header)=>new external_docx_namespaceObject.TableRow({
                    children: header.sub ? [
                        tableCell(`${header.main}`),
                        tableCell(`${header.sub}`),
                        ...rows.map((row)=>tableCell(`${Math.floor(external_lodash_default().get(row, header.id))}`))
                    ] : [
                        tableCell(`${header.main}`),
                        ...rows.map((row)=>tableCell(`${Math.floor(external_lodash_default().get(row, header.id))}`))
                    ]
                })),
            tableRow("Net Amount Payable", 5, colspan, total),
            tableRow("GST Hold", 5, colspan, 0),
            tableRow("Safety Violation Penality", 5, colspan, safetypenality),
            tableRow("Adjustment of Advance Amount", 5, colspan, 0),
            tableRow("Any Other Deductions", 5, colspan, deduction),
            tableRow("Final Payable", 5, colspan, total - safetypenality - deduction)
        ],
        width: {
            size: 100,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
    return table;
}

;// CONCATENATED MODULE: ./src/components/PrintFinalSheet/contractordetails.tsx


const contractordetails_tableCell = (text, bold)=>{
    return new external_docx_namespaceObject.TableCell({
        children: [
            new external_docx_namespaceObject.Paragraph({
                children: [
                    new external_docx_namespaceObject.TextRun({
                        text: `${text || "-"}`,
                        bold: bold,
                        size: 17
                    })
                ],
                alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                spacing: {
                    after: 50,
                    before: 50
                }
            })
        ],
        width: {
            size: 20,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
};
function ContractorDetails({ contractor  }) {
    const contractorheaders = [
        {
            id: "contractorId",
            label: "Contractor ID"
        },
        {
            id: "contractorname",
            label: "Contractor Name"
        },
        {
            id: "mobilenumber",
            label: "Mobile Number"
        },
        {
            id: "officeaddress",
            label: "Office Address"
        },
        {
            id: "pancardnumber",
            label: "Pan No"
        },
        {
            id: "areaofwork",
            label: "Area of Work"
        },
        {
            id: "type",
            label: "Type of Contractor"
        }
    ];
    const table = new external_docx_namespaceObject.Table({
        rows: [
            new external_docx_namespaceObject.TableRow({
                children: contractorheaders.map((header)=>contractordetails_tableCell(`${header.label}`, true))
            }),
            new external_docx_namespaceObject.TableRow({
                children: contractorheaders.map((header)=>contractordetails_tableCell(`${external_lodash_default().get(contractor, header.id, "-")}`, false))
            })
        ],
        width: {
            size: 100,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
    return table;
}
function ServiceDetails({ workorder , date  }) {
    const serviceheaders = [
        {
            id: "id",
            label: "Work Order Id"
        },
        {
            id: "nature",
            label: "Nature of Work"
        },
        {
            id: "location",
            label: "Location"
        },
        {
            id: "startDate",
            label: "Start Date"
        },
        {
            id: "endDate",
            label: "End Date"
        }
    ];
    const table = new external_docx_namespaceObject.Table({
        rows: [
            new external_docx_namespaceObject.TableRow({
                children: [
                    ...serviceheaders.map((header)=>contractordetails_tableCell(`${header.label}`, true)),
                    contractordetails_tableCell("Invoice Date", true)
                ]
            }),
            new external_docx_namespaceObject.TableRow({
                children: [
                    ...serviceheaders.map((header)=>contractordetails_tableCell(`${external_lodash_default().get(workorder, header.id) || "-"}`, false)),
                    contractordetails_tableCell(date, false)
                ]
            })
        ],
        width: {
            size: 100,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
    return table;
}

;// CONCATENATED MODULE: ./src/components/PrintFinalSheet/otherDetails.tsx

const otherDetails_tableCell = (text, bold)=>{
    return new external_docx_namespaceObject.TableCell({
        children: [
            new external_docx_namespaceObject.Paragraph({
                children: [
                    new external_docx_namespaceObject.TextRun({
                        text: `${text || "-"}`,
                        bold: bold,
                        size: 17
                    })
                ],
                alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                spacing: {
                    after: 50,
                    before: 50
                }
            })
        ],
        width: {
            size: 20,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
};
function CostDetails({ month , previousMonth , beforemonth , monthvalue , previousMonthValue , beforeMonthValue , previousyearvalue  }) {
    const contractorheaders = [
        {
            id: "costprevious",
            label: `Cost of Previous Month - ${previousMonth}`
        },
        {
            id: "costofmonth",
            label: `Cost of the Month - ${beforemonth}`
        },
        {
            id: "thismonth",
            label: `Cost Upto This Month - ${month}`
        },
        {
            id: "previousyear",
            label: "Cost Of the Previous Year"
        }
    ];
    const table = new external_docx_namespaceObject.Table({
        rows: [
            new external_docx_namespaceObject.TableRow({
                children: contractorheaders.map((header)=>otherDetails_tableCell(`${header.label}`, true))
            }),
            new external_docx_namespaceObject.TableRow({
                children: [
                    previousMonthValue,
                    beforeMonthValue,
                    monthvalue,
                    previousyearvalue
                ].map((value)=>otherDetails_tableCell(`${value}`, false))
            })
        ],
        width: {
            size: 100,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
    return table;
}
function BankDetails({ date , contractor , payouttracker  }) {
    console.log("payouttracker", payouttracker);
    const bankheaders = [
        {
            id: "contractorname",
            label: "Beneficial Name"
        },
        {
            id: "bankaccountnumber",
            label: "Account Number"
        },
        {
            id: "ifscno",
            label: "IFSC Code"
        },
        {
            id: "paymentdate",
            label: "Date of Payment"
        },
        {
            id: "referenceno",
            label: "Payment Refrence No:"
        },
        {
            id: "paid",
            label: "Paid Amount"
        }
    ];
    const table = new external_docx_namespaceObject.Table({
        rows: [
            new external_docx_namespaceObject.TableRow({
                children: [
                    ...bankheaders.map((header)=>otherDetails_tableCell(`${header.label}`, true))
                ]
            }),
            new external_docx_namespaceObject.TableRow({
                children: [
                    ...[
                        contractor.contractorname,
                        contractor.bankaccountnumber,
                        contractor.ifscno,
                        payouttracker?.month || "-",
                        payouttracker?.id || "-",
                        payouttracker?.actualpaidoutmoney || 0
                    ].map((header)=>otherDetails_tableCell(`${header}`, false))
                ]
            })
        ],
        width: {
            size: 100,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
    return table;
}

// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(1635);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
;// CONCATENATED MODULE: ./src/components/PrintFinalSheet/approvalInfo.tsx

const approvalInfo_tableCell = (text, bold)=>{
    return new external_docx_namespaceObject.TableCell({
        children: [
            new external_docx_namespaceObject.Paragraph({
                children: [
                    new external_docx_namespaceObject.TextRun({
                        text: `${text || "-"}`,
                        bold: bold,
                        size: 17
                    })
                ],
                alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                spacing: {
                    after: 50,
                    before: 50
                }
            })
        ],
        width: {
            size: 20,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
};
function ApprovalInformation() {
    const approvalheader = [
        {
            id: "id",
            label: "Prepared & Checked By"
        },
        {
            id: "nature",
            label: "C-DARC V/s Biomax Checked By:"
        },
        {
            id: "location",
            label: "Statutory Complaince"
        },
        {
            id: "startDate",
            label: "Department Leader's Approval"
        },
        {
            id: "endDate",
            label: "Top Management Approval"
        }
    ];
    const table = new external_docx_namespaceObject.Table({
        rows: [
            new external_docx_namespaceObject.TableRow({
                children: [
                    ...approvalheader.map((header)=>approvalInfo_tableCell(`${header.label}`, true))
                ]
            }),
            new external_docx_namespaceObject.TableRow({
                children: [
                    ...[
                        " ",
                        " ",
                        " ",
                        " ",
                        " "
                    ].map((header)=>approvalInfo_tableCell(`${header}`, false))
                ]
            })
        ],
        width: {
            size: 100,
            type: external_docx_namespaceObject.WidthType.PERCENTAGE
        }
    });
    return table;
}

;// CONCATENATED MODULE: ./src/components/PrintFinalSheet/index.ts






const createHeadcell = (id, label, colspan)=>{
    return {
        id,
        label,
        colspan
    };
};
const getPreviousMonth = (month)=>{
    const date = external_dayjs_default()(month, "MM/YYYY");
    const prevMonth = date.subtract(1, "month");
    const prevMonthString = prevMonth.format("MM/YYYY");
    return prevMonthString;
};
const headers = [
    createHeadcell("date", "Date", 1),
    createHeadcell("8MW", "8MW", 2),
    createHeadcell("20MW", "20MW", 2),
    createHeadcell("DM", "DM Plant", 1),
    createHeadcell("QC", "QC", 1),
    createHeadcell("Store", "Store", 1),
    createHeadcell("K7", "K7 & 1-6PROC", 2),
    createHeadcell("RMHS", "RMHS", 1),
    createHeadcell("PS", "PS", 1),
    createHeadcell("HK", "HK", 1),
    createHeadcell("SVR", "SVR", 1),
    createHeadcell("total", "Total", 1)
];
const headcells = [
    createHeadcell("date", "", 1),
    createHeadcell("m8", "M", 1),
    createHeadcell("f8", "F", 1),
    createHeadcell("m20", "M", 1),
    createHeadcell("f20", "F", 1),
    createHeadcell("dm", "M", 1),
    createHeadcell("qc", "M", 1),
    createHeadcell("store", "M", 1),
    createHeadcell("k7m", "M", 1),
    createHeadcell("k7f", "F", 1),
    createHeadcell("rmhs", "M", 1),
    createHeadcell("ps", "F", 1),
    createHeadcell("hk", "M", 1),
    createHeadcell("svr", "M", 1),
    createHeadcell("total", "Total", 1)
];
function print(rows, total, department, contractor, workorder, date, store, safety, payouttracker, prevMonthAmount, prevprevMonthAmount, prevYearAmount, designations) {
    const previousMonth = getPreviousMonth(date);
    const beforemonth = getPreviousMonth(previousMonth);
    console.log("payoutracker", payouttracker);
    let doc = new external_docx_namespaceObject.Document({
        sections: [
            {
                children: [
                    new external_docx_namespaceObject.Paragraph({
                        text: "Plant 1",
                        heading: external_docx_namespaceObject.HeadingLevel.HEADING_2,
                        alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                        spacing: {
                            before: 0
                        }
                    }),
                    new external_docx_namespaceObject.Paragraph({
                        text: "Contractor's Payment Approval Sheet",
                        heading: external_docx_namespaceObject.HeadingLevel.HEADING_3,
                        alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                        spacing: {
                            after: 250
                        }
                    }),
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: "Contractor Details",
                                size: 15,
                                bold: true
                            })
                        ],
                        spacing: {
                            after: 100,
                            before: 250
                        }
                    }),
                    ContractorDetails({
                        contractor
                    }),
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: "Service Details",
                                size: 15,
                                bold: true
                            })
                        ],
                        spacing: {
                            after: 100,
                            before: 250
                        }
                    }),
                    ServiceDetails({
                        workorder,
                        date
                    }),
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: `Department - ${department}`,
                                size: 15,
                                bold: true
                            })
                        ],
                        spacing: {
                            after: 100,
                            before: 250
                        }
                    }),
                    DocTable({
                        department: department,
                        rows: rows,
                        total: total,
                        safetypenality: safety?.totalAmount || 0,
                        deduction: store?.totalAmount || 0,
                        designations
                    }),
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: "CONTRACTOR MONTHLY COST CHARGED IN PROFIT & LOSS A/C FOR CURRENT FINANCIAL YEAR",
                                size: 15,
                                bold: true
                            })
                        ],
                        alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                        spacing: {
                            after: 100,
                            before: 300
                        }
                    }),
                    CostDetails({
                        month: date,
                        previousMonth: previousMonth,
                        beforemonth: beforemonth,
                        monthvalue: total,
                        previousMonthValue: prevMonthAmount || 0,
                        beforeMonthValue: prevprevMonthAmount || 0,
                        previousyearvalue: prevYearAmount || 0
                    }),
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: "BANK ACCOUNT A/C INFORMATION",
                                bold: true,
                                size: 15
                            })
                        ],
                        alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                        spacing: {
                            after: 100,
                            before: 300
                        }
                    }),
                    BankDetails({
                        date: date,
                        contractor,
                        payouttracker
                    }),
                    new external_docx_namespaceObject.Paragraph({
                        children: [
                            new external_docx_namespaceObject.TextRun({
                                text: "APPROVAL'S INFORMATION",
                                bold: true,
                                size: 15
                            })
                        ],
                        alignment: external_docx_namespaceObject.AlignmentType.CENTER,
                        spacing: {
                            after: 100,
                            before: 300
                        }
                    }),
                    ApprovalInformation()
                ]
            }
        ]
    });
    external_docx_namespaceObject.Packer.toBlob(doc).then((blob)=>{
        const url = URL.createObjectURL(new Blob([
            blob
        ]));
        const link = document.createElement("a");
        link.href = url;
        link.download = "finalsheet.docx";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    });
}


/***/ }),

/***/ 1518:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Details)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


function Details({ rows  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        display: "flex",
        flexWrap: "wrap",
        children: rows.map((row, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "h4",
                sx: {
                    mx: 6,
                    my: 2
                },
                children: [
                    row.label,
                    " : ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        style: {
                            fontWeight: "500"
                        },
                        children: row.value
                    })
                ]
            }, index))
    });
}


/***/ }),

/***/ 346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ FinalSheetta)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Paper"
var Paper_ = __webpack_require__(1598);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);
// EXTERNAL MODULE: external "@mui/material/Table"
var Table_ = __webpack_require__(9181);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table_);
// EXTERNAL MODULE: external "@mui/material/TableBody"
var TableBody_ = __webpack_require__(8823);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody_);
// EXTERNAL MODULE: external "@mui/material/TableCell"
var TableCell_ = __webpack_require__(8099);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell_);
// EXTERNAL MODULE: external "@mui/material/TableContainer"
var TableContainer_ = __webpack_require__(443);
var TableContainer_default = /*#__PURE__*/__webpack_require__.n(TableContainer_);
// EXTERNAL MODULE: external "@mui/material/TableHead"
var TableHead_ = __webpack_require__(5953);
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead_);
// EXTERNAL MODULE: external "@mui/material/TableRow"
var TableRow_ = __webpack_require__(4848);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow_);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
var external_lodash_default = /*#__PURE__*/__webpack_require__.n(external_lodash_);
;// CONCATENATED MODULE: ./src/components/Table/finalsheettable.tsx










function FinalSheetTable({ rows , total , sides , department , storededuction , safetydeduction  }) {
    const headers = [
        "Total Man days",
        "Rate",
        "Total Amount",
        "Total Overtime",
        "OT Amount",
        "Total Amount",
        "Service Charge",
        "Service Charge Amount",
        "Taxable",
        "GST",
        "Bill Amount",
        "TDS",
        "Net Payable"
    ];
    const ccmheader = [
        "Total Man days",
        "Rate",
        "Total Amount",
        "Total Overtime",
        "OT Amount",
        "Taxable",
        "GST",
        "Bill Amount",
        "TDS",
        "Net Payable"
    ];
    const colspan = department === "8HR" || department === "12HR" || department === "Colony" ? 8 : 4;
    return /*#__PURE__*/ jsx_runtime_.jsx((Paper_default()), {
        sx: {
            width: "100%",
            scrollBehavior: "smooth",
            "&::-webkit-scrollbar": {
                width: 9,
                height: 10
            },
            "&::-webkit-scrollbar-thumb": {
                backgroundColor: "#bdbdbd",
                borderRadius: 2
            }
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((TableContainer_default()), {
            sx: {
                maxWidth: "100%",
                scrollBehavior: "smooth",
                "&::-webkit-scrollbar": {
                    width: 9,
                    height: 10
                },
                "&::-webkit-scrollbar-thumb": {
                    backgroundColor: "#bdbdbd",
                    borderRadius: 2
                }
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                "aria-label": "sticky table",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                            sx: {
                                bgcolor: "#eeeeee"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                    align: "center",
                                    sx: {
                                        fontWeight: "700"
                                    },
                                    colSpan: 1,
                                    children: "Designation"
                                }),
                                (department === "8HR" || department === "12HR" || department === "Colony") && /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                    align: "center",
                                    sx: {
                                        fontWeight: "700"
                                    },
                                    colSpan: 1,
                                    children: "Type"
                                }),
                                (department === "8HR" || department === "12HR" || department === "Colony" ? headers : ccmheader).map((header, index)=>/*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        sx: {
                                            fontWeight: "700"
                                        },
                                        colSpan: 1,
                                        children: header
                                    }, index))
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableBody_default()), {
                        children: [
                            sides.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                    hover: true,
                                    role: "checkbox",
                                    tabIndex: -1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            align: "center",
                                            sx: {
                                                fontWeight: "600"
                                            },
                                            children: item.main
                                        }),
                                        item.sub && /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            align: "center",
                                            children: item.sub
                                        }),
                                        rows.map((row, index)=>/*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "center",
                                                children: Math.floor(external_lodash_default().get(row, item.id)) || 0
                                            }, index))
                                    ]
                                }, item.id)),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: colspan + 1
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: 5,
                                        sx: {
                                            fontWeight: "600"
                                        },
                                        children: "Net Amount Payable"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: total
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: colspan
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: 5,
                                        sx: {
                                            fontWeight: "600"
                                        },
                                        children: "GST Hold"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: 0
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: colspan
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: 5,
                                        sx: {
                                            fontWeight: "600"
                                        },
                                        children: "Safety Voilation's Penality"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: safetydeduction
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: colspan
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: 5,
                                        sx: {
                                            fontWeight: "600"
                                        },
                                        children: "Consumables / Rechargeable Items"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: storededuction
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: colspan
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: 5,
                                        sx: {
                                            fontWeight: "600"
                                        },
                                        children: "Adjustment Of Advance Amount"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: "0"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: colspan
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: 5,
                                        sx: {
                                            fontWeight: "600"
                                        },
                                        children: "Any Other Deductions"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: 0
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: colspan
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        colSpan: 5,
                                        sx: {
                                            fontWeight: "600"
                                        },
                                        children: "Final Payable"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: total > 0 ? total - storededuction - safetydeduction : 0
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/components/Table/finalsheet.tsx



function FinalSheetta({ rows , total , department , storededuction , safetydeduction , designations  }) {
    const s8hr = designations.map((d)=>{
        if (d.gender === "Male") return {
            main: d.designation,
            sub: "M",
            id: d.designationid
        };
        else if (d.gender === "Female") return {
            main: d.designation,
            sub: "F",
            id: d.designationid
        };
        else return {
            main: d.designation,
            id: d.designationid
        };
    });
    const sidebar = designations.filter((d)=>d.departmentname === department).map((d)=>{
        if (d.gender === "Male") return {
            main: d.designation,
            sub: "M",
            id: d.designationid
        };
        else if (d.gender === "Female") return {
            main: d.designation,
            sub: "F",
            id: d.designationid
        };
        else return {
            main: d.designation,
            id: d.designationid
        };
    });
    const side8hr = [
        {
            main: "8MW",
            sub: "M",
            id: "m8"
        },
        {
            main: "8MW",
            sub: "F",
            id: "f8"
        },
        {
            main: "20MW",
            sub: "M",
            id: "m20"
        },
        {
            main: "20MW",
            sub: "F",
            id: "f20"
        },
        {
            main: "DM",
            sub: "M",
            id: "dm"
        },
        {
            main: "QC",
            sub: "M",
            id: "qc"
        },
        {
            main: "Store",
            sub: "M",
            id: "store"
        },
        {
            main: "K-7",
            sub: "M",
            id: "k7m"
        },
        {
            main: "K-7",
            sub: "F",
            id: "k7f"
        },
        {
            main: "RMHS",
            sub: "M",
            id: "rmhs"
        },
        {
            main: "PS",
            sub: "F",
            id: "ps"
        },
        {
            main: "HK",
            sub: "M",
            id: "hk"
        },
        {
            main: "SVR",
            sub: "M",
            id: "svr"
        },
        {
            main: "TOTAL",
            sub: " ",
            id: "total"
        }
    ];
    const sideccm = [
        {
            main: "ELE",
            id: "ele"
        },
        {
            main: "LCO",
            id: "lco"
        },
        {
            main: "TMAN",
            id: "tman"
        },
        {
            main: "FILTER",
            id: "filter"
        },
        {
            main: "PO",
            id: "po"
        },
        {
            main: "BCO",
            id: "bco"
        },
        {
            main: "SRFILTER",
            id: "srfilter"
        },
        {
            main: "INCHARGE",
            id: "incharge"
        },
        {
            main: "MO",
            id: "mo"
        },
        {
            main: "SHIFT INCH",
            id: "shiftinch"
        },
        {
            main: "GC",
            id: "gc"
        },
        {
            main: "SVR",
            id: "svr"
        },
        {
            main: "SBO",
            id: "sbo"
        },
        {
            main: "LMAN",
            id: "lman"
        },
        {
            main: "FORMAN",
            id: "forman"
        },
        {
            main: "TMES SON",
            id: "tmesson"
        },
        {
            main: "LMES",
            id: "lmes"
        },
        {
            main: "JRELE",
            id: "jrele"
        },
        {
            main: "HELPER",
            id: "helper"
        },
        {
            main: "Total",
            id: "total"
        }
    ];
    const sidelrf = [
        {
            main: "ELE",
            id: "ele"
        },
        {
            main: "FILTER",
            id: "filter"
        },
        {
            main: "SRFILTER",
            id: "srfilter"
        },
        {
            main: "SVR",
            id: "svr"
        },
        {
            main: "LMES",
            id: "lmes"
        },
        {
            main: "HELPER",
            id: "helper"
        },
        {
            main: "Total",
            id: "total"
        }
    ];
    const sidecolony = [
        {
            main: "Colony",
            sub: "Male",
            id: "m"
        },
        {
            main: "Colony",
            sub: "Female",
            id: "f"
        }
    ];
    if (department === "Colony") {
        sidebar.push(...sidecolony);
    }
    switch(department){
        case "8HR":
        case "12HR":
        case "Colony":
            sidebar.push({
                main: "Total",
                sub: " ",
                id: "total"
            });
            break;
        case "CCM":
        case "LRF":
            sidebar.push({
                main: "Total",
                id: "total"
            });
            break;
        default:
            break;
    }
    // switch (department) {
    //   case "CCM":
    //     return (
    //       <FinalSheetTable
    //         rows={rows}
    //         total={Math.floor(total || 0)}
    //         department={department}
    //         sides={sideccm}
    //         storededuction={storededuction}
    //         safetydeduction={safetydeduction}
    //       />
    //     );
    //     break;
    //   case "LRF":
    //     return (
    //       <FinalSheetTable
    //         rows={rows}
    //         total={Math.floor(total || 0)}
    //         department={department}
    //         sides={sidelrf}
    //         storededuction={storededuction}
    //         safetydeduction={safetydeduction}
    //       />
    //     );
    //     break;
    //   case "Colony":
    //     return (
    //       <FinalSheetTable
    //         rows={rows}
    //         total={Math.floor(total || 0)}
    //         department={department}
    //         sides={sidecolony}
    //         storededuction={storededuction}
    //         safetydeduction={safetydeduction}
    //       />
    //     );
    //     break;
    //   case "8HR":
    //   case "12HR":
    //     return (
    //       <FinalSheetTable
    //         rows={rows}
    //         total={Math.floor(total || 0)}
    //         department={department}
    //         sides={s8hr}
    //         storededuction={storededuction}
    //         safetydeduction={safetydeduction}
    //       />
    //     );
    //   default:
    //     return <></>;
    // }
    return /*#__PURE__*/ jsx_runtime_.jsx(FinalSheetTable, {
        rows: rows,
        total: Math.floor(total || 0),
        department: department,
        sides: sidebar,
        storededuction: storededuction,
        safetydeduction: safetydeduction
    });
}


/***/ }),

/***/ 9415:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FinalSheet),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6395);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(681);
/* harmony import */ var _ui_component_MonthSelect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8877);
/* harmony import */ var _utils_get8hr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(606);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9048);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9648);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_Table_finalsheet__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(346);
/* harmony import */ var _components_PrintFinalSheet__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9940);
/* harmony import */ var _components_Table_details__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1518);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_12__]);
axios__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



















function FinalSheet({ contractors , workorders , departments , designations  }) {
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(dayjs__WEBPACK_IMPORTED_MODULE_13___default()().format("MM/YYYY"));
    const [selectedContractor, setSelectedContractor] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(contractors.length > 0 && contractors[0].contractorId ? contractors[0]?.contractorId : 0);
    const [rows, setRows] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)([]);
    const [timekeepers, setTimekeepers] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)([]);
    const [totalPayable, setTotalPayable] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(0);
    const [department, setDepartment] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)("8HR");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(false);
    const [store, setStore] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(null);
    const [safety, setSafety] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(null);
    const [details, setDetails] = (0,react__WEBPACK_IMPORTED_MODULE_15__.useState)(null);
    const f = contractors.find((c)=>c.contractorId === selectedContractor);
    const fetchStoreAndSafety = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_12__["default"].get(`/api/stores?contractorid=${selectedContractor}&month=${value}`);
        setStore(res.data);
        const res1 = await axios__WEBPACK_IMPORTED_MODULE_12__["default"].get(`/api/safety?contractorid=${selectedContractor}&month=${value}`);
        setSafety(res1.data);
        setLoading(false);
    };
    const fetchTimekeepers = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_12__["default"].get(`/api/gettimekeeper?contractor=${selectedContractor}&month=${value}&department=${department}`);
        console.log(designations.filter((d)=>d.departmentname === department));
        console.log(department, res.data);
        const { rows1 , totalnetPayable  } = (0,_utils_get8hr__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(res.data, dayjs__WEBPACK_IMPORTED_MODULE_13___default()(value, "MM/YYYY").month() + 1, dayjs__WEBPACK_IMPORTED_MODULE_13___default()(value, "MM/YYYY").year(), designations.filter((d)=>d.departmentname === department), department);
        setRows(rows1);
        console.log(rows1);
        setTotalPayable(totalnetPayable);
        // if (department === "8HR" || department === "12HR") {
        //   const { rows1, totalnetPayable } = getTotalAmountAndRows(
        //     res.data,
        //     dayjs(value, "MM/YYYY").month() + 1,
        //     dayjs(value, "MM/YYYY").year(),
        //     designations
        //   );
        //   setRows(rows1);
        //   setTotalPayable(totalnetPayable);
        // } else if (department === "CCM") {
        //   const { rows1, totalnetPayable } = getCCM(
        //     res.data,
        //     dayjs(value, "MM/YYYY").month() + 1,
        //     dayjs(value, "MM/YYYY").year()
        //   );
        //   setRows(rows1);
        //   setTotalPayable(totalnetPayable);
        // } else if (department === "LRF") {
        //   const { rows1, totalnetPayable } = getLRF(
        //     res.data,
        //     dayjs(value, "MM/YYYY").month() + 1,
        //     dayjs(value, "MM/YYYY").year()
        //   );
        //   setRows(rows1);
        //   setTotalPayable(totalnetPayable);
        // } else {
        //   const { rows1, totalnetPayable } = getColony(
        //     res.data,
        //     dayjs(value, "MM/YYYY").month() + 1,
        //     dayjs(value, "MM/YYYY").year()
        //   );
        //   setRows(rows1);
        //   setTotalPayable(totalnetPayable);
        // }
        setTimekeepers(res.data);
        setLoading(false);
    };
    const fetchPayouts = async ()=>{
        const res = await axios__WEBPACK_IMPORTED_MODULE_12__["default"].get(`/api/payouttracker?contractorid=${selectedContractor}&month=${value}`);
        setDetails(res.data);
    };
    const fetchAll = async ()=>{
        setLoading(true);
        await fetchTimekeepers();
        await fetchStoreAndSafety();
        await fetchPayouts();
        setLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_15__.useEffect)(()=>{
        fetchAll();
    }, [
        selectedContractor,
        value,
        department
    ]);
    console.log(store);
    // console.log(timekeepers, rows, totalPayable, loading);
    const handlePrint = async ()=>{
        (0,_components_PrintFinalSheet__WEBPACK_IMPORTED_MODULE_17__/* .print */ .S)(rows, totalPayable, department, f, workorders.find((w)=>w.contractorId === f?.id && w.startDate.includes(value)), value, store, safety, details.payoutracker, details.prevMonthAmount, details.prevprevMonthAmount, details.prevYearAmount, designations);
    // const c = contractors.find((c) => c.contractorId === selectedContractor);
    // const w = workorders.find(
    //   (w) => w.contractorId === f?.id && w.startDate.includes(value)
    // );
    // if (department === "8HR" || department === "12HR") {
    //   print8HR(rows, c, w, department, totalPayable);
    // } else {
    //   printOther(rows, c, w, department, totalPayable);
    // }
    };
    const onChange = (value)=>setValue(value?.format("MM/YYYY") || "");
    const w = workorders.find((c)=>c.contractorId === f?.id && c.startDate.includes(value));
    return loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: "90vh",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_7___default()), {
            sx: {
                color: "#673ab7"
            }
        })
    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_9___default()), {
        sx: {
            overflow: "auto",
            p: 3,
            maxHeight: "calc(100vh - 6rem)",
            scrollBehavior: "smooth",
            "&::-webkit-scrollbar": {
                height: 10,
                width: 9
            },
            "&::-webkit-scrollbar-thumb": {
                backgroundColor: "#bdbdbd",
                borderRadius: 2
            }
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
                        sx: {
                            display: "flex",
                            justifyContent: "space-between"
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_10___default()), {
                                direction: "row",
                                flexWrap: "wrap",
                                alignItems: "center",
                                spacing: 2,
                                sx: {
                                    width: "100%"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        value: selectedContractor,
                                        handleChange: (value)=>setSelectedContractor(value),
                                        options: contractors.map((c)=>({
                                                value: c.contractorId || "",
                                                label: c.contractorname
                                            })),
                                        label: "Contractor"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_MonthSelect__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        label: "Select Date",
                                        value: dayjs__WEBPACK_IMPORTED_MODULE_13___default()(value, "MM/YYYY"),
                                        onChange: onChange
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        value: department,
                                        handleChange: (value)=>setDepartment(value),
                                        options: departments.map((d)=>({
                                                value: d.department,
                                                label: d.department
                                            })),
                                        label: "Department"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default()), {
                                variant: "contained",
                                sx: {
                                    ml: "auto",
                                    width: "7rem",
                                    alignSelf: "flex-end",
                                    justifySelf: "space-between",
                                    mb: 2
                                },
                                onClick: ()=>handlePrint(),
                                children: "Print"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default()), {
                        sx: {
                            my: 2
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default()), {
                        variant: "h4",
                        sx: {
                            mb: 4,
                            my: 2
                        },
                        children: "Contractor Details :"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_details__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                        rows: [
                            {
                                label: "Contractor Id",
                                value: selectedContractor.toString()
                            },
                            {
                                label: "Contractor Name",
                                value: f?.contractorname
                            },
                            {
                                label: "Mobile Number",
                                value: f?.mobilenumber
                            },
                            {
                                label: "Office Address",
                                value: f?.officeaddress
                            },
                            {
                                label: "Pan Number",
                                value: f?.pancardno
                            },
                            {
                                label: "Area of Work",
                                value: f?.areaofwork
                            },
                            {
                                label: "Type of Contractor",
                                value: "-"
                            }
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default()), {
                        sx: {
                            my: 2
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default()), {
                        variant: "h4",
                        sx: {
                            mt: 2,
                            mb: 4
                        },
                        children: "Service Details :"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_details__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                        rows: [
                            {
                                label: "Work Order Id",
                                value: w?.id
                            },
                            {
                                label: "Nature of Work",
                                value: w?.nature
                            },
                            {
                                label: "Location",
                                value: w?.location
                            },
                            {
                                label: "Start Date",
                                value: w?.startDate
                            },
                            {
                                label: "End Date",
                                value: w?.endDate
                            }
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default()), {
                sx: {
                    my: 2
                }
            }),
            loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                width: "100%",
                height: "90vh",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_7___default()), {
                    sx: {
                        color: "#673ab7"
                    }
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_finalsheet__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                rows: rows,
                total: totalPayable,
                department: department,
                storededuction: store?.totalAmount || 0,
                safetydeduction: safety?.totalAmount || 0,
                designations: designations
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default()), {
                sx: {
                    my: 2
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default()), {
                variant: "h4",
                sx: {
                    mt: 2,
                    mb: 4
                },
                children: "Contractors Monthly Cost Charged in Profit & Loss for a Financial Year :"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_details__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                rows: [
                    {
                        label: "Cost of Previous Month",
                        value: (details?.prevMonthAmount || 0)?.toString()
                    },
                    {
                        label: "Cost of the Month",
                        value: (details?.prevprevMonthAmount || 0)?.toString()
                    },
                    {
                        label: "Cost Upto This Month",
                        value: totalPayable?.toString()
                    },
                    {
                        label: "Cost Of the Previous Year",
                        value: (details?.prevYearAmount || 0)?.toString()
                    }
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default()), {
                sx: {
                    my: 2
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default()), {
                variant: "h4",
                sx: {
                    mt: 2,
                    mb: 4
                },
                children: "Bank Account Information :"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_details__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                rows: [
                    {
                        label: "Beneficial Name",
                        value: f?.contractorname
                    },
                    {
                        label: "Account Number",
                        value: f?.bankaccountnumber
                    },
                    {
                        label: "IFSC Code",
                        value: f?.ifscno
                    },
                    {
                        label: "Payment Date",
                        value: details?.payoutracker?.month || "-"
                    },
                    {
                        label: "Payment Reference Number",
                        value: details?.payoutracker?.id || "-"
                    },
                    {
                        label: "Paid Amount",
                        value: details?.payoutracker?.actualpaidoutmoney || "-"
                    }
                ]
            })
        ]
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_14__.getSession)({
        req: context.req
    });
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    const contractors = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* ["default"].contractor.findMany */ .Z.contractor.findMany();
    const workorders = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* ["default"].workorder.findMany */ .Z.workorder.findMany();
    const departments = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* ["default"].department.findMany */ .Z.department.findMany();
    const designations = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* ["default"].designations.findMany */ .Z.designations.findMany();
    return {
        props: {
            contractors,
            workorders,
            departments,
            designations
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 3646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 8099:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 5953:
/***/ ((module) => {

module.exports = require("@mui/material/TableHead");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [681,5809], () => (__webpack_exec__(9415)));
module.exports = __webpack_exports__;

})();