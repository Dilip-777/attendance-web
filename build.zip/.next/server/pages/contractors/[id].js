"use strict";
(() => {
var exports = {};
exports.id = 4185;
exports.ids = [4185];
exports.modules = {

/***/ 9919:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ EditContractor),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9876);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6850);
/* harmony import */ var _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3522);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6395);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9711);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_19__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__, axios__WEBPACK_IMPORTED_MODULE_14__]);
([_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__, axios__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// import {
//   Box,
//   Button,
//   Divider,
//   Grid,
//   Paper,
//   Stack,
//   Typography,
// } from "@mui/material";




















// import { Contractor } from "@prisma/client"
const fileType = yup__WEBPACK_IMPORTED_MODULE_10__.object().required("Required").optional();
const stringtype = yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Required").optional();
const numberType = yup__WEBPACK_IMPORTED_MODULE_10__.number().transform((value, originalValue)=>{
    return originalValue !== "" ? null : value;
});
const mobilenumbertype = yup__WEBPACK_IMPORTED_MODULE_10__.string().matches(/^(?:\+91[1-9]\d{9}|0[1-9]\d{9}|[1-9]\d{9})$/, "Please enter a valid mobile number");
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_10__.object().shape({
    contractorname: yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Required").matches(/^[A-Za-z ]+$/, "Please enter only letters and spaces"),
    contractorId: yup__WEBPACK_IMPORTED_MODULE_10__.number().required("Required"),
    servicedetail: yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Required"),
    supplierdetail: yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Required"),
    businessdetaildocument: fileType,
    uploadutilitybill: fileType,
    officeaddress: yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Required"),
    contactperson: yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Required"),
    designation: yup__WEBPACK_IMPORTED_MODULE_10__.string().required("Required"),
    telephonenumber: mobilenumbertype,
    mobilenumber: mobilenumbertype.required("Mobile number is required"),
    emailid: stringtype.email("Please enter a valid email address"),
    website: stringtype.url("Please enter a valid website URL"),
    expirationDate: stringtype,
    servicecharge: yup__WEBPACK_IMPORTED_MODULE_10__.number().required("Rquired"),
    bankaccountnumber: stringtype.required("Required"),
    ifscno: stringtype.required("Required"),
    pancardno: stringtype,
    areaofwork: stringtype,
    // Organsiation Details
    organisationtype: stringtype,
    dateofincorporation: stringtype,
    associationwithcompetitor: stringtype,
    memorandam_of_associate: fileType,
    listofdirector: fileType,
    profileofkeyperson: fileType,
    competitorname: stringtype.matches(/^[A-Za-z ]+$/, "Please enter only letters and spaces"),
    isocertified: stringtype,
    turnoverlastyear: stringtype,
    turnover2yearback: stringtype,
    uploadbranchdetail: fileType,
    uploadreturndetail: fileType,
    uniquenumber: numberType.nullable().optional(),
    registration_number: numberType.nullable().optional(),
    first_registration_number: numberType.nullable().optional(),
    latest_mnth_gst1_filed: stringtype,
    latest_mnth_gst2b_filed: stringtype,
    comply_regulatory: stringtype,
    upload_registration_cert: fileType,
    upload_licence1: fileType,
    upload_licence2: fileType,
    code_of_proprietor: stringtype,
    //Service / Product Details
    list_major_product: stringtype,
    qualty_control_procedure: stringtype,
    valueadd_product: stringtype,
    five_strength_points: stringtype,
    weakness: stringtype,
    selection_training_method: stringtype,
    delivery_procedure: stringtype,
    clientele: stringtype,
    // Reference Details
    reference_organistaion_1: stringtype,
    reference_contact_person_1: stringtype,
    reference_designation_1: stringtype,
    reference_contact_1: stringtype,
    period_of_service_1: stringtype,
    reference_organistaion_2: stringtype,
    reference_contact_person_2: stringtype,
    reference_designation_2: stringtype,
    reference_contact_2: stringtype,
    period_of_service_2: stringtype,
    reference_organistaion_3: stringtype,
    reference_contact_person_3: stringtype,
    reference_designation_3: stringtype,
    reference_contact_3: stringtype,
    period_of_service_3: stringtype,
    upload_list_ofclientele: fileType,
    upload_certificate_services: fileType,
    upload_doc1: fileType,
    upload_doc2: fileType
});
function EditContractor({ contractor  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    // const [contractor, setContractor] = useState<Contractor || null>()
    // const [value, setValue] = useState("");
    const { id  } = router.query;
    const initialValues = {
        contractorname: contractor?.contractorname || "",
        contractorId: contractor?.contractorId || null,
        servicedetail: contractor?.servicedetail || "",
        supplierdetail: contractor?.supplierdetail || "",
        businessdetaildocument: undefined,
        uploadutilitybill: undefined,
        officeaddress: contractor?.officeaddress || "",
        contactperson: contractor?.contactperson || "",
        designation: contractor?.designation || "",
        telephonenumber: contractor?.telephonenumber || "",
        mobilenumber: contractor?.mobilenumber || 0,
        emailid: contractor?.emailid || "",
        website: contractor?.website || "",
        pancardno: contractor?.pancardno || "",
        areaofwork: contractor?.areaofwork || "",
        expirationDate: contractor?.expirationDate || "",
        servicecharge: contractor?.servicecharge || 0,
        bankaccountnumber: contractor?.bankaccountnumber || "",
        ifscno: contractor?.ifscno || "",
        organisationtype: contractor?.organisationtype || "",
        dateofincorporation: contractor?.dateofincorporation || "",
        associationwithcompetitor: contractor?.associationwithcompetitor || "",
        memorandam_of_associate: undefined,
        listofdirector: undefined,
        profileofkeyperson: undefined,
        competitorname: contractor?.competitorname || "",
        isocertified: contractor?.isocertified || "",
        turnoverlastyear: contractor?.turnoverlastyear || "",
        turnover2yearback: contractor?.turnover2yearback || "",
        uploadbranchdetail: undefined,
        uploadreturndetail: undefined,
        uniquenumber: contractor?.uniquenumber || "",
        registration_number: contractor?.registration_number || "",
        first_registration_number: contractor?.first_registration_number || "",
        latest_mnth_gst1_filed: contractor?.latest_mnth_gst1_filed || "",
        latest_mnth_gst2b_filed: contractor?.latest_mnth_gst2b_filed || "",
        comply_regulatory: contractor?.comply_regulatory || "",
        upload_registration_cert: undefined,
        upload_licence1: undefined,
        upload_licence2: undefined,
        code_of_proprietor: contractor?.code_of_proprietor || "",
        list_major_product: contractor?.list_major_product || "",
        qualty_control_procedure: contractor?.qualty_control_procedure || "",
        valueadd_product: contractor?.valueadd_product || "",
        five_strength_points: contractor?.five_strength_points || "",
        weakness: contractor?.weakness || "",
        selection_training_method: contractor?.selection_training_method || "",
        delivery_procedure: contractor?.delivery_procedure || "",
        clientele: contractor?.clientele || "",
        reference_organistaion_1: contractor?.reference_organistaion_1 || "",
        reference_contact_person_1: contractor?.reference_contact_person_1 || "",
        reference_designation_1: contractor?.reference_designation_1 || "",
        reference_contact_1: contractor?.reference_contact_1 || "",
        period_of_service_1: contractor?.period_of_service_1 || "",
        reference_organistaion_2: contractor?.reference_organistaion_2 || "",
        reference_contact_person_2: contractor?.reference_contact_person_2 || "",
        reference_designation_2: contractor?.reference_designation_2 || "",
        reference_contact_2: contractor?.reference_contact_2 || "",
        period_of_service_2: contractor?.period_of_service_2 || "",
        reference_organistaion_3: contractor?.reference_organistaion_3 || "",
        reference_contact_person_3: contractor?.reference_contact_person_3 || "",
        reference_designation_3: contractor?.reference_designation_3 || "",
        reference_contact_3: contractor?.reference_contact_3 || "",
        period_of_service_3: contractor?.period_of_service_3 || "",
        upload_list_ofclientele: undefined,
        upload_certificate_services: undefined,
        upload_doc1: undefined,
        upload_doc2: undefined
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_5___default()), {
            sx: {
                height: {
                    sm: "80vh",
                    md: "82.2vh",
                    xl: "83.7vh"
                },
                pt: "1rem",
                pb: "8rem",
                overflow: "hidden auto",
                scrollBehavior: "smooth",
                "&::-webkit-scrollbar": {
                    width: 9
                },
                "&::-webkit-scrollbar-thumb": {
                    backgroundColor: "#bdbdbd",
                    borderRadius: 2
                }
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                    sx: {
                        height: "3rem",
                        display: "flex",
                        alignItems: "center"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                        variant: "h4",
                        ml: 5,
                        my: "auto",
                        children: "Add Contractor"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_11__.Formik, {
                    initialValues: initialValues,
                    validationSchema: validationSchema,
                    onSubmit: async (values, { setErrors , setSubmitting  })=>{
                        const { associationwithcompetitor , isocertified , comply_regulatory , telephonenumber , mobilenumber , uniquenumber , registration_number , first_registration_number , ...otherValues } = values;
                        if (contractor) {
                            setSubmitting(true);
                            await axios__WEBPACK_IMPORTED_MODULE_14__["default"].put("/api/hr/contractors", {
                                id: id,
                                ...otherValues,
                                associationwithcompetitor: associationwithcompetitor === "Yes" ? true : false,
                                isocertified: isocertified === "Yes" ? true : false,
                                comply_regulatory: comply_regulatory === "Yes" ? true : false,
                                telephonenumber: String(telephonenumber),
                                mobilenumber: String(mobilenumber),
                                uniquenumber: String(uniquenumber),
                                registration_number: String(registration_number),
                                first_registration_number: String(first_registration_number)
                            }).then((res)=>{
                                router.push("/contractors");
                            }).catch((err)=>{
                                console.log(err);
                            });
                        }
                        await axios__WEBPACK_IMPORTED_MODULE_14__["default"].post("/api/hr/contractors", {
                            ...otherValues,
                            associationwithcompetitor: associationwithcompetitor === "Yes" ? true : false,
                            isocertified: isocertified === "Yes" ? true : false,
                            comply_regulatory: comply_regulatory === "Yes" ? true : false,
                            telephonenumber: String(telephonenumber),
                            mobilenumber: String(mobilenumber),
                            uniquenumber: String(uniquenumber),
                            registration_number: String(registration_number),
                            first_registration_number: String(first_registration_number)
                        }).then((res)=>{
                            router.push("/contractors");
                        }).catch((err)=>{
                            if (err?.response?.data?.error === "contractorId") {
                                setErrors({
                                    contractorId: "Contractor Id already exists"
                                });
                            }
                        });
                        setSubmitting(false);
                    },
                    children: ({ handleSubmit , errors , values , isSubmitting  })=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            noValidate: true,
                            onSubmit: handleSubmit,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    spacing: 0,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            variant: "h5",
                                            ml: 1,
                                            mt: 2,
                                            children: "General"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            columnSpacing: 3,
                                            ml: {
                                                xs: 0,
                                                sm: 2,
                                                lg: 0
                                            },
                                            container: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "contractorId",
                                                        label: "Contractor Id*",
                                                        placeHolder: "Enter the Contractor Id",
                                                        type: "number",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "contractorname",
                                                        label: "Contractor Name*",
                                                        placeHolder: "Enter the Contractor Name",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "servicedetail",
                                                        label: "Service Detail*",
                                                        placeHolder: "Enter Service Detail",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "supplierdetail",
                                                        label: "Supplier Detail*",
                                                        placeHolder: "Enter Supplier Detail",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "officeaddress",
                                                        label: "Office Address*",
                                                        placeHolder: "Enter Office Address",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "contactperson",
                                                        label: "Contact Person*",
                                                        placeHolder: "Contact Person",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "designation",
                                                        label: "Designation*",
                                                        placeHolder: "Enter Designation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "telephonenumber",
                                                        label: "Telephone Number",
                                                        placeHolder: "Enter Telephone Number",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "mobilenumber",
                                                        label: "Mobile Number*",
                                                        placeHolder: "Enter Mobile Number",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "emailid",
                                                        label: "Email",
                                                        placeHolder: "Enter Email",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "website",
                                                        label: "Website",
                                                        placeHolder: "Enter Website",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                        name: "expirationDate",
                                                        label: "Expiration Date*",
                                                        placeHolder: "Enter Expiration Date",
                                                        disabled: false,
                                                        minDate: dayjs__WEBPACK_IMPORTED_MODULE_19___default()()
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "servicecharge",
                                                        label: "Service Charge*",
                                                        placeHolder: "Enter the Service Charge",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "pancardno",
                                                        label: "Pan Card Number*",
                                                        placeHolder: "Enter Pan Card Number",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "areaofwork",
                                                        label: "Area of Work*",
                                                        placeHolder: "Enter Area of Work",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "bankaccountnumber",
                                                        label: "Bank Account Number*",
                                                        placeHolder: "Enter Bank Account Number",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "ifscno",
                                                        label: "IFSC Code*",
                                                        placeHolder: "Enter IFSC Code",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "businessdetaildocument",
                                                        label: "Business Details Document"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "uploadutilitybill",
                                                        label: "Upload Utility Bill"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    spacing: 0,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            variant: "h5",
                                            ml: 1,
                                            mt: 2,
                                            children: "Organisation"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            ml: {
                                                xs: 0,
                                                sm: 4
                                            },
                                            mt: 2,
                                            container: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                        name: "organisationtype",
                                                        label: "Organisation Type",
                                                        placeHolder: "Select a Organisation Type",
                                                        options: [
                                                            {
                                                                value: "Public Limited Company",
                                                                label: "Public Limited Company"
                                                            },
                                                            {
                                                                value: "Private Limited Company",
                                                                label: "Private Limited Company"
                                                            },
                                                            {
                                                                value: "Partnership Firm",
                                                                label: "Partnership Firm"
                                                            },
                                                            {
                                                                value: "Sole Proprietorship",
                                                                label: "Sole Proprietorship"
                                                            },
                                                            {
                                                                value: "Others",
                                                                label: "Others"
                                                            }
                                                        ],
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                        name: "dateofincorporation",
                                                        label: "Date of Incorporation",
                                                        placeHolder: "Date of Incorporation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                        name: "associationwithcompetitor",
                                                        label: "Are you an associative member of any organisation?",
                                                        placeHolder: "Association with Competitor",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: "Yes",
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: "No",
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "memorandam_of_associate",
                                                        label: "Memorandum of Associate"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "listofdirector",
                                                        label: "List of Directors"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "profileofkeyperson",
                                                        label: "Profile of Key Person"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "competitorname",
                                                        label: "Competitor Name",
                                                        placeHolder: "Enter Competitor Name",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                        name: "isocertified",
                                                        label: "ISO Certified",
                                                        placeHolder: "ISO Certified",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: "Yes",
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: "No",
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "turnoverlastyear",
                                                        label: "What is Turnover of Last Year",
                                                        placeHolder: "Turnover Last Year",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "turnover2yearback",
                                                        label: "What is Turnover of 2nd Last Year",
                                                        placeHolder: "Turnover 2nd Last Year",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "uploadbranchdetail",
                                                        label: "Branch Detail"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "uploadreturndetail",
                                                        label: "Return Detail"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "uniquenumber",
                                                        label: "Unique Number",
                                                        placeHolder: "Enter Unique Number",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "registration_number",
                                                        label: "Registration Number",
                                                        placeHolder: "Enter your Registration Number",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "first_registration_number",
                                                        label: "Fist Registration Number",
                                                        placeHolder: "Enter your Fist Registration Number",
                                                        disabled: false,
                                                        type: "number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "latest_mnth_gst1_filed",
                                                        label: "Latest Month GST 1 Filed",
                                                        placeHolder: "Latest Month GST 1 Filed",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "latest_mnth_gst2b_filed",
                                                        label: "Latest Month GST 2 Filed",
                                                        placeHolder: "Latest Month GST 2 Filed",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                        name: "comply_regulatory",
                                                        label: "Comply Regulatory",
                                                        placeHolder: "Comply Regulatory",
                                                        disabled: false,
                                                        options: [
                                                            {
                                                                value: "Yes",
                                                                label: "Yes"
                                                            },
                                                            {
                                                                value: "No",
                                                                label: "No"
                                                            }
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "upload_registration_cert",
                                                        label: "Registration Certificate"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "upload_licence1",
                                                        label: "License1"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "upload_licence2",
                                                        label: "License2"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "code_of_proprietor",
                                                        label: "Code No of Proprietor",
                                                        placeHolder: "Code no of Proprietor",
                                                        disabled: false
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    spacing: 0,
                                    mt: 4,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            variant: "h5",
                                            ml: 1,
                                            my: "auto",
                                            children: "Service / Product Details"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            ml: {
                                                xs: 0,
                                                sm: 4
                                            },
                                            mt: 0,
                                            container: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "list_major_product",
                                                        label: "List Major Products",
                                                        placeHolder: "Enter the List of Major Product",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "qualty_control_procedure",
                                                        label: "What are your Quality Control Procedure",
                                                        placeHolder: "Enter your Quality Control Procedure",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "valueadd_product",
                                                        label: "What value add product can you provide?",
                                                        placeHolder: "Enter your value add product",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "five_strength_points",
                                                        label: "What are your five strength points?",
                                                        placeHolder: "Enter your five strength points",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "weakness",
                                                        label: "What are your five weakness points?",
                                                        placeHolder: "Enter your five weakness points",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "selection_training_method",
                                                        label: "What is your selection and training method?",
                                                        placeHolder: "Enter your selection and training method",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "delivery_procedure",
                                                        label: "What is your delivery procedure?",
                                                        placeHolder: "Enter your delivery procedure",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "clientele",
                                                        label: "What is your clientele?",
                                                        placeHolder: "Enter your clientele",
                                                        disabled: false
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    spacing: 0,
                                    mt: 4,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            variant: "h5",
                                            ml: 1,
                                            my: "auto",
                                            children: "Reference Details"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            ml: {
                                                xs: 0,
                                                sm: 4
                                            },
                                            mt: 2,
                                            container: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        children: "Organisation1:"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_organistaion_1",
                                                        label: "Reference Organisation",
                                                        placeHolder: "Enter your Reference Organisation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_contact_person_1",
                                                        label: "Reference Contact Person",
                                                        placeHolder: "Enter your Reference Contact Person",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_designation_1",
                                                        label: "Reference Designation",
                                                        placeHolder: "Enter your Reference Designation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_contact_1",
                                                        label: "Reference Contact",
                                                        placeHolder: "Enter your Reference Contact",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "period_of_service_1",
                                                        label: "Period of Service",
                                                        placeHolder: "Enter your Period of Service",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        sx: {
                                                            my: 2
                                                        }
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        children: "Organisation2"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_organistaion_2",
                                                        label: "Reference Organisation",
                                                        placeHolder: "Enter your Reference Organisation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_contact_person_2",
                                                        label: "Reference Contact Person",
                                                        placeHolder: "Enter your Reference Contact Person",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_designation_2",
                                                        label: "Reference Designation",
                                                        placeHolder: "Enter your Reference Designation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_contact_2",
                                                        label: "Reference Contact",
                                                        placeHolder: "Enter your Reference Contact",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "period_of_service_2",
                                                        label: "Period of Service",
                                                        placeHolder: "Enter your Period of Service",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        sx: {
                                                            my: 2
                                                        }
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        children: "Organisation3"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_organistaion_3",
                                                        label: "Reference Organisation",
                                                        placeHolder: "Enter your Reference Organisation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_contact_person_3",
                                                        label: "Reference Contact Person",
                                                        placeHolder: "Enter your Reference Contact Person",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_designation_3",
                                                        label: "Reference Designation",
                                                        placeHolder: "Enter your Reference Designation",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "reference_contact_3",
                                                        label: "Reference Contact",
                                                        placeHolder: "Enter your Reference Contact",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        name: "period_of_service_3",
                                                        label: "Period of Service",
                                                        placeHolder: "Enter your Period of Service",
                                                        disabled: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "upload_list_ofclientele",
                                                        label: "Upload List of Clientele"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "upload_certificate_services",
                                                        label: "Upload Certificate of Services"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "upload_doc1",
                                                        label: "Upload Document1"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    item: true,
                                                    xs: 12,
                                                    sm: 6,
                                                    lg: 4,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        name: "upload_doc2",
                                                        label: "Upload Document2"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    type: "submit",
                                    variant: "contained",
                                    sx: {
                                        float: "right",
                                        mr: 10
                                    },
                                    disabled: isSubmitting,
                                    children: [
                                        "Submit",
                                        isSubmitting && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_17__.CircularProgress, {
                                            size: 15,
                                            sx: {
                                                ml: 1,
                                                color: "#364152"
                                            }
                                        })
                                    ]
                                })
                            ]
                        });
                    }
                })
            ]
        })
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_15__.getSession)({
        req: context.req
    });
    const { id  } = context.query;
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_16__/* ["default"].user.findUnique */ .Z.user.findUnique({
        where: {
            id: session?.user?.id
        }
    });
    const contractor = await _lib_prisma__WEBPACK_IMPORTED_MODULE_16__/* ["default"].contractor.findUnique */ .Z.contractor.findUnique({
        where: {
            id: id
        }
    });
    if (user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    return {
        props: {
            contractor
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 3274:
/***/ ((module) => {

module.exports = require("@mui/icons-material/InsertDriveFile");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8167:
/***/ ((module) => {

module.exports = require("@mui/material/Card");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 3646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 8891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 6354:
/***/ ((module) => {

module.exports = require("@mui/material/FormHelperText");

/***/ }),

/***/ 6096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 1856:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/DatePicker");

/***/ }),

/***/ 5753:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/LocalizationProvider");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5684,6850,4503], () => (__webpack_exec__(9919)));
module.exports = __webpack_exports__;

})();