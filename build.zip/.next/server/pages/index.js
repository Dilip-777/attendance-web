"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 3933:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ CustomModal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/icons-material/NavigateBefore"
var NavigateBefore_ = __webpack_require__(7460);
var NavigateBefore_default = /*#__PURE__*/__webpack_require__.n(NavigateBefore_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/Timekeeper/Document.tsx



function Documents({ documents  }) {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
        spacing: 2,
        alignItems: "flex-start",
        mt: 2,
        children: documents.map((document)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                width: "100%",
                sx: {
                    border: "2px solid #E3E8EF",
                    borderRadius: "10px"
                },
                alignItems: "flex-start",
                spacing: 1,
                p: 2,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                        spacing: 0.5,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                variant: "body2",
                                sx: {
                                    fontWeight: 600,
                                    fontSize: "1.1rem"
                                },
                                children: document.userName
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                variant: "subtitle2",
                                children: document.role
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        sx: {
                            cursor: "pointer"
                        },
                        onClick: ()=>router.push(`/uploadedFiles/${document.document}`),
                        children: "Click to View to the Document"
                    })
                ]
            }, document.id))
    });
}

;// CONCATENATED MODULE: ./src/components/Timekeeper/Comment.tsx


const Comments = ({ comments  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
        spacing: 2,
        alignItems: "flex-start",
        mt: 2,
        children: comments.map((comment)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                width: "100%",
                sx: {
                    border: "2px solid #E3E8EF",
                    borderRadius: "10px"
                },
                alignItems: "flex-start",
                spacing: 1,
                p: 2,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                        spacing: 0.5,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                variant: "body2",
                                sx: {
                                    fontWeight: 600,
                                    fontSize: "1.1rem"
                                },
                                children: comment.userName
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                variant: "subtitle2",
                                children: comment.role
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        children: comment.comment
                    })
                ]
            }, comment.id))
    });
};
/* harmony default export */ const Comment = (Comments);

;// CONCATENATED MODULE: ./src/components/Timekeeper/ViewCommentsDocuments.tsx





const style = {
    position: "absolute",
    overflowY: "auto",
    borderRadius: "15px",
    bgcolor: "background.paper",
    boxShadow: 24
};
function CustomModal({ open , open1 , handleClose , selected1  }) {
    const matches = (0,material_.useMediaQuery)("(min-width:600px)");
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Modal, {
        "aria-labelledby": "transition-modal-title",
        "aria-describedby": "transition-modal-description",
        open: open || open1,
        onClose: handleClose,
        closeAfterTransition: true,
        BackdropComponent: material_.Backdrop,
        BackdropProps: {
            timeout: 500
        },
        sx: {
            display: "flex",
            justifyContent: " flex-end"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Slide, {
            direction: matches ? "left" : "up",
            timeout: 500,
            in: open || open1,
            mountOnEnter: true,
            unmountOnExit: true,
            children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                p: {
                    xs: 0,
                    sm: 2
                },
                width: {
                    xs: "100%",
                    sm: 400,
                    md: 500
                },
                height: {
                    xs: "70%",
                    sm: "100%"
                },
                top: {
                    xs: "30%",
                    sm: "0"
                },
                sx: style,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                    sx: {
                        overflowY: "auto"
                    },
                    p: 3,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                            sx: {
                                fontSize: "1.2rem",
                                fontWeight: "700"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                    onClick: handleClose,
                                    sx: {
                                        // zIndex: 2,
                                        padding: "5px",
                                        marginRight: "1rem",
                                        background: "white",
                                        ":hover": {
                                            background: "white"
                                        }
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((NavigateBefore_default()), {
                                        fontSize: "large"
                                    })
                                }),
                                open ? "Documents" : "Comments"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {}),
                        selected1 && selected1?.length > 0 ? open ? /*#__PURE__*/ jsx_runtime_.jsx(Documents, {
                            documents: selected1
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(Comment, {
                            comments: selected1
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontSize: "1.2rem",
                                fontWeight: "700"
                            },
                            children: open ? "No Documents" : "No Comments"
                        })
                    ]
                })
            })
        })
    });
}


/***/ }),

/***/ 4058:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3765);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Alert__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9048);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9174);
/* harmony import */ var _mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6302);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_8__]);
axios__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











function ImportData() {
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [key, setKey] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(0);
    // submit
    const [excelData, setExcelData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(null);
    // it will contain array of objects
    // handle File
    const fileType = [
        "application/vnd.xlsx",
        "application/vnd.ms-excel"
    ];
    const handleFile = (e)=>{
        let selectedFile = e.target.files[0];
        console.log(selectedFile);
        console.log(e.target.files);
        if (selectedFile) {
            let reader = new FileReader();
            reader.readAsArrayBuffer(selectedFile);
            reader.onload = (e)=>{
                console.log(e.target?.result);
                const workbook = xlsx__WEBPACK_IMPORTED_MODULE_10__.read(e.target?.result, {
                    type: "buffer"
                });
                const worksheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[worksheetName];
                const data = xlsx__WEBPACK_IMPORTED_MODULE_10__.utils.sheet_to_json(worksheet);
                console.log(data);
                importing(data);
            };
            setKey(key + 1);
        }
    };
    const handleClick = ()=>{
        setOpen(true);
    };
    const handleClose = (event, reason)=>{
        if (reason === "clickaway") {
            return;
        }
        setOpen(false);
    };
    const action = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_9___default().Fragment), {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default()), {
            size: "small",
            "aria-label": "close",
            color: "inherit",
            onClick: handleClose,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default()), {
                fontSize: "small"
            })
        })
    });
    const getDate = (excelDate)=>{
        // const excelDate = 44986;
        const date = new Date((excelDate - (25567 + 2)) * 86400 * 1000);
        const formattedDate = `${date.getDate().toString().padStart(2, "0")}/${(date.getMonth() + 1).toString().padStart(2, "0")}/${date.getFullYear()}`;
        return formattedDate;
    };
    const importing = async (data)=>{
        console.log(data);
        const keys = [];
        const indices = [];
        data.forEach((d, index)=>{
            [
                "contractor_name",
                "contractor_id",
                "employee_name",
                "employee_id",
                "designation",
                "department"
            ].forEach((key)=>{
                if (!d[key]) {
                    if (keys.indexOf(key) === -1) {
                        keys.push(key);
                    }
                    if (!indices.includes(index + 1)) {
                        indices.push(index + 1);
                    }
                }
            });
        });
        if (keys.length > 0) {
            setMessage(`Please check the following keys: ${keys.join(", ")} at rows: ${indices.join(", ")}`);
            setError(true);
            handleClick();
            return;
        }
        const body = data.map((data)=>{
            return {
                contractorid: data.contractor_id?.toString(),
                contractorname: data.contractor_name,
                employeeid: data.employee_id?.toString(),
                employeename: data.employee_name,
                designation: data.designation,
                department: data.department,
                machineInTime: data.machine_intime ? data.machine_intime === 0 ? "00:00" : new Date(data.machine_intime * 24 * 60 * 60 * 1000).toLocaleTimeString("en-US", {
                    hour: "2-digit",
                    minute: "2-digit"
                })?.toString() : "Invalid Entry Time",
                machineOutTime: data.machine_outtime ? data.machine_outtime === 0 ? "00:00" : new Date(data.machine_outtime * 24 * 60 * 60 * 1000).toLocaleTimeString("en-US", {
                    hour: "2-digit",
                    minute: "2-digit"
                })?.toString() : "Invalid Entry Time",
                machineshift: data.shift || "day",
                attendance: data.attendence?.toString() || "0",
                attendancedate: getDate(data.entry_date)?.toString(),
                overtime: data.overtime?.toString() || "0",
                machineduration: data.machine_duration ? data.machine_duration === 0 ? "00:00" : new Date(data.machine_duration * 24 * 60 * 60 * 1000).toLocaleTimeString("en-US", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                    hour12: false,
                    timeZone: "UTC"
                })?.toString() : "-",
                eleave: data.e_leave || "0",
                gender: data.gender || "M"
            };
        });
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_8__["default"].post("/api/importdata?type=timekeeper", body).then((res)=>{
            setError(false);
            handleClick();
        // set
        }).catch((err)=>{
            setMessage("Please Provide Valid Data");
            setError(true);
            handleClick();
        });
        setLoading(false);
    };
    // new Date(timeValue * 24 * 60 * 60 * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default()), {
        direction: "row",
        alignItems: "center",
        spacing: 2,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                disabled: loading,
                variant: "contained",
                component: "label",
                children: [
                    "Upload",
                    loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default()), {
                        size: 15,
                        sx: {
                            ml: 1,
                            color: "#364152"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        hidden: true,
                        type: "file",
                        className: "form-control",
                        onChange: handleFile,
                        required: true
                    }, key)
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6___default()), {
                open: open,
                autoHideDuration: 6000,
                onClose: handleClose,
                action: action,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Alert__WEBPACK_IMPORTED_MODULE_2___default()), {
                    onClose: handleClose,
                    severity: error ? "error" : "success",
                    sx: {
                        width: "100%"
                    },
                    children: error ? message : "Data Uploaded Successfully"
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImportData);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 85:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TimeKeeperTable),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9181);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8823);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8099);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(443);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7308);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4848);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1431);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8330);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7229);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9048);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_material___WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(419);
/* harmony import */ var _mui_material___WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_material___WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9868);
/* harmony import */ var _mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1664);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2494);
/* harmony import */ var _mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(9648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _components_Table_EnhancedTableHead__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(7972);
/* harmony import */ var _mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(3280);
/* harmony import */ var _mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(298);
/* harmony import */ var _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _components_import__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(4058);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(681);
/* harmony import */ var _components_Timekeeper_ViewCommentsDocuments__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(3933);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_25__, _components_import__WEBPACK_IMPORTED_MODULE_31__]);
([axios__WEBPACK_IMPORTED_MODULE_25__, _components_import__WEBPACK_IMPORTED_MODULE_31__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


































function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}
function getComparator(order, orderBy) {
    return order === "desc" ? (a, b)=>descendingComparator(a, b, orderBy) : (a, b)=>-descendingComparator(a, b, orderBy);
}
function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index)=>[
            el,
            index
        ]);
    stabilizedThis.sort((a, b)=>{
        const order = comparator(a[0], b[0]);
        if (order !== 0) {
            return order;
        }
        return a[1] - b[1];
    });
    return stabilizedThis.map((el)=>el[0]);
}
const createHeadCells = (id, label, numeric, included)=>{
    return {
        id: id,
        label: label,
        numeric: numeric,
        included: included
    };
};
const headCells = [
    createHeadCells("employeeid", "Employee ID", false, false),
    createHeadCells("employeename", "Employee Name", false, false),
    createHeadCells("machineintime", "Machine In Time", false, false),
    createHeadCells("machineouttime", "Machine Out Time", false, false),
    createHeadCells("machineduration", "Machine Total Duration", false, false),
    createHeadCells("machineshift", "Machine Shift", false, false),
    createHeadCells("attendance", "Attendance", true, false),
    createHeadCells("attendancedance", "Attendance Date", true, false),
    createHeadCells("machineovertime", "Machine Over Time", true, false),
    createHeadCells("machineleave", "Machine Leave", true, false),
    createHeadCells("manualintime", "Manual In Time", false, false),
    createHeadCells("manualouttime", "Manual Out Time", false, false),
    createHeadCells("manualduration", "Manual Total Duration", false, false),
    createHeadCells("manualshift", "Manual Shift", false, false),
    createHeadCells("manualovertime", "Manual Over Time", true, false),
    createHeadCells("manualleave", "Manual Leave", true, false),
    createHeadCells("deployeeofdepartment", "Deployee Of Department", false, false),
    createHeadCells("designation", "Designation", false, false),
    createHeadCells("gender", "Gender", false, false),
    createHeadCells("status", "Status", false, false),
    createHeadCells("comment", "Comment", false, false),
    createHeadCells("uploaddocument", "Upload Document", false, false)
];
function EnhancedTableToolbar(props) {
    const { numSelected , contractorName , setContractorName , contractors , value , setValue , handleApprove , showApprove  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10___default()), {
        sx: {
            pl: {
                sm: 2
            },
            pr: {
                xs: 1,
                sm: 1
            },
            display: "flex",
            justifyContent: "space-between",
            ...numSelected > 0 && {
                bgcolor: (theme)=>(0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.alpha)(theme.palette.primary.main, theme.palette.action.activatedOpacity)
            }
        },
        children: [
            numSelected > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default()), {
                sx: {
                    flex: "1 1 100%"
                },
                color: "inherit",
                variant: "subtitle1",
                component: "div",
                children: [
                    numSelected,
                    " selected"
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_17___default()), {
                spacing: 2,
                direction: "row",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                        sx: {
                            minWidth: 240
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z, {
                            options: [
                                {
                                    value: "all",
                                    label: "All Contractors"
                                },
                                ...contractors
                            ],
                            value: contractorName,
                            handleChange: (e)=>setContractorName(e)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_28__.LocalizationProvider, {
                        dateAdapter: _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_29__.AdapterDayjs,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_28__.DatePicker, {
                            views: [
                                "month",
                                "year"
                            ],
                            value: value,
                            onChange: (newValue)=>{
                                if (newValue) setValue(newValue);
                            }
                        })
                    })
                ]
            }),
            numSelected > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15___default()), {
                title: "Delete",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_20___default()), {})
                })
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_17___default()), {
                direction: "row",
                spacing: 2,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_import__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .Z, {}),
                    value.month() < dayjs__WEBPACK_IMPORTED_MODULE_30___default()().month() && showApprove && contractorName !== "all" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material___WEBPACK_IMPORTED_MODULE_18__.Button, {
                        sx: {
                            mr: 3
                        },
                        onClick: handleApprove,
                        children: "Approve"
                    })
                ]
            })
        ]
    });
}
function TimeKeeperTable({}) {
    const [order, setOrder] = react__WEBPACK_IMPORTED_MODULE_1__.useState("asc");
    const [orderBy, setOrderBy] = react__WEBPACK_IMPORTED_MODULE_1__.useState("employeeid");
    const [selected, setSelected] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const [page, setPage] = react__WEBPACK_IMPORTED_MODULE_1__.useState(0);
    const [rowsPerPage, setRowsPerPage] = react__WEBPACK_IMPORTED_MODULE_1__.useState(5);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_24__.useRouter)();
    const [timekeeper, setTimeKepeer] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const [loading, setLoading] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [open1, setOpen1] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [selected1, setSelected1] = react__WEBPACK_IMPORTED_MODULE_1__.useState();
    const [contractors, setContractors] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const matches = _mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_19___default()("(min-width:600px)");
    const [contractorName, setContractorName] = react__WEBPACK_IMPORTED_MODULE_1__.useState("all");
    const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_1__.useState(dayjs__WEBPACK_IMPORTED_MODULE_30___default()());
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_26__.useSession)();
    const headcell1 = createHeadCells("status", "Status", false, true);
    const headcell2 = createHeadCells("action", "Action", false, true);
    const extraHeadCells = session?.user?.role === "HR" ? [
        ...headCells,
        headcell1,
        headcell2
    ] : [
        ...headCells
    ];
    const handleClose = ()=>{
        setOpen(false);
        setOpen1(false);
        setSelected1(undefined);
    };
    const handleOpen1 = async (id)=>{
        // setLoading(true);
        const comment = await axios__WEBPACK_IMPORTED_MODULE_25__["default"].get(`/api/comment/${id}`);
        setOpen1(true);
        setSelected1(comment.data);
    // setLoading(false);
    };
    const handleOpen = async (id)=>{
        // setLoading(true);
        const upload = await axios__WEBPACK_IMPORTED_MODULE_25__["default"].get(`/api/document/${id}`);
        setSelected1(upload.data);
        // setLoading(false);
        setOpen(true);
    };
    const handleApprove = async (id)=>{
        setLoading(true);
        await axios__WEBPACK_IMPORTED_MODULE_25__["default"].put(`/api/timekeeper/${id}`).then((res)=>{
            fetchTimeKeeper();
            setLoading(false);
        }).catch((err)=>{
            console.log(err);
            setLoading(false);
        });
    };
    const handleReject = async (id)=>{
        setLoading(true);
        await axios__WEBPACK_IMPORTED_MODULE_25__["default"]["delete"](`/api/timekeeper/${id}`).then((res)=>{
            fetchTimeKeeper();
            setLoading(false);
        }).catch((err)=>{
            console.log(err);
            setLoading(false);
        });
    };
    const fetchContrators = async ()=>{
        await axios__WEBPACK_IMPORTED_MODULE_25__["default"].get("/api/hr/contractors").then((res)=>{
            const contractors = res.data;
            setContractors(contractors);
        }).catch((err)=>{
            console.log(err);
        });
    };
    const fetchTimeKeeper = async ()=>{
        if (timekeeper.length === 0) {
            setLoading(true);
        }
        await axios__WEBPACK_IMPORTED_MODULE_25__["default"].get(`/api/timekeeper/gettimekeepers?month=${value?.format("MM/YYYY")}&role=${session?.user?.role}`).then((res)=>{
            const timekeepers = res.data;
            setTimeKepeer(timekeepers);
            setLoading(false);
        }).catch((err)=>{
            console.log(err);
            setLoading(false);
        });
    };
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        fetchTimeKeeper();
    }, [
        value,
        session
    ]);
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        fetchContrators();
    }, []);
    const handleSelectAllClick = (event)=>{
        if (event.target.checked) {
            const newSelected = timekeeper.filter((t)=>t.contractorname === contractorName || contractorName === "all").map((n)=>n.employeeid.toString());
            setSelected(newSelected);
            return;
        }
        setSelected([]);
    };
    const handleClick = (event, contractorname)=>{
        const selectedIndex = selected.indexOf(contractorname);
        let newSelected = [];
        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, contractorname);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
        }
        setSelected(newSelected);
    };
    const handleChangePage = (event, newPage)=>{
        setPage(newPage);
    };
    const handleChangeRowsPerPage = (event)=>{
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    const isSelected = (contractorname)=>selected.indexOf(contractorname) !== -1;
    const showApprove = ()=>{
        const timekeeper1 = timekeeper.filter((t)=>t.contractorname === contractorName || contractorName === "all");
        if (session?.user?.role === "TimeKeeper") {
            if (timekeeper1.find((t)=>!t.approvedByTimekeeper)) {
                return timekeeper1.find((t)=>t.status === "Pending") ? false : true;
            } else return false;
        } else return false;
    };
    //  const d = new Date("00:00" * 24 * 60 * 60 * 1000)
    //   .toLocaleTimeString("en-US", {
    //     hour: "2-digit",
    //     minute: "2-digit",
    //   })
    //   ?.toString();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
        sx: {
            width: "100%"
        },
        children: [
            loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                width: "100%",
                height: "90vh",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_16___default()), {
                    sx: {
                        color: "#673ab7"
                    }
                })
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_12___default()), {
                sx: {
                    width: "100%",
                    mb: 2
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EnhancedTableToolbar, {
                        numSelected: selected.length,
                        contractorName: contractorName,
                        setContractorName: setContractorName,
                        contractors: contractors?.map((c)=>({
                                value: c.contractorname,
                                label: c.contractorname
                            })) || [],
                        value: value,
                        setValue: setValue,
                        showApprove: showApprove(),
                        handleApprove: async ()=>{
                            await axios__WEBPACK_IMPORTED_MODULE_25__["default"].put(`/api/timekeeper/approve`, {
                                month: value.format("MM/YYYY"),
                                contractorname: contractorName
                            });
                            fetchTimeKeeper();
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7___default()), {
                        sx: {
                            maxHeight: "calc(100vh - 16rem)",
                            overflowY: "auto",
                            scrollBehavior: "smooth",
                            "&::-webkit-scrollbar": {
                                height: 10,
                                width: 10
                            },
                            "&::-webkit-scrollbar-thumb": {
                                backgroundColor: "#bdbdbd",
                                borderRadius: 2
                            }
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_4___default()), {
                            stickyHeader: true,
                            sx: {
                                minWidth: 750
                            },
                            "aria-labelledby": "tableTitle",
                            size: "medium",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_EnhancedTableHead__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                                    numSelected: selected.length,
                                    onSelectAllClick: handleSelectAllClick,
                                    rowCount: timekeeper.filter((t)=>t.contractorname === contractorName || contractorName === "all").length,
                                    headCells: extraHeadCells
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    children: [
                                        stableSort(timekeeper.filter((t)=>t.contractorname === contractorName || contractorName === "all"), getComparator(order, orderBy)).filter((t)=>t.status !== "Pending").slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index)=>{
                                            const isItemSelected = isSelected(row.employeeid);
                                            const labelId = `enhanced-table-checkbox-${index}`;
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                hover: true,
                                                role: "checkbox",
                                                "aria-checked": isItemSelected,
                                                tabIndex: -1,
                                                selected: isItemSelected,
                                                sx: {
                                                    cursor: "pointer"
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        padding: "checkbox",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                            color: "primary",
                                                            onClick: (event)=>handleClick(event, row.employeeid),
                                                            checked: isItemSelected,
                                                            inputProps: {
                                                                "aria-labelledby": labelId
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.employeeid
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.employeename
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.machineInTime
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.machineOutTime
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.machineduration || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.machineshift || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.attendance || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.attendancedate || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.overtime || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.eleave || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.manualintime || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.manualouttime || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.manualduration || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.manualshift || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.manualovertime || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.mleave || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.department || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.designation || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.gender || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        children: row.status || "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        onClick: ()=>handleOpen1(row.id),
                                                        children: "View"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        align: "left",
                                                        onClick: ()=>handleOpen(row.id),
                                                        children: "View"
                                                    }),
                                                    session?.user?.role === "HR" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                align: "left",
                                                                children: row.status || "Pending"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                align: "left",
                                                                children: !row.status ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                    display: "flex",
                                                                    alignItems: "center",
                                                                    sx: {
                                                                        color: "#673AB7"
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material___WEBPACK_IMPORTED_MODULE_18__.Button, {
                                                                            onClick: ()=>handleApprove(row.id),
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                                                sx: {
                                                                                    color: "#673AB7"
                                                                                }
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material___WEBPACK_IMPORTED_MODULE_18__.Button, {
                                                                            onClick: ()=>handleReject(row.id),
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                                sx: {
                                                                                    color: "#673AB7"
                                                                                }
                                                                            })
                                                                        })
                                                                    ]
                                                                }) : "-"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        size: "small",
                                                        align: "left",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            onClick: ()=>router.push(`/details/${row.id}`),
                                                            sx: {
                                                                m: 0
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_21___default()), {
                                                                fontSize: "small"
                                                            })
                                                        })
                                                    })
                                                ]
                                            }, row.id);
                                        }),
                                        stableSort(timekeeper.filter((t)=>t.contractorname === contractorName || contractorName === "all"), getComparator(order, orderBy)).filter((t)=>t.status !== "Pending").length === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default()), {
                                            style: {
                                                height: 50
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                colSpan: 6,
                                                children: "No Data Found"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8___default()), {
                        rowsPerPageOptions: [
                            5,
                            10,
                            25,
                            50,
                            100
                        ],
                        component: "div",
                        count: timekeeper.filter((t)=>(t.contractorname === contractorName || contractorName === "all") && t.status !== "Pending").length,
                        rowsPerPage: rowsPerPage,
                        page: page,
                        onPageChange: handleChangePage,
                        onRowsPerPageChange: handleChangeRowsPerPage
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Timekeeper_ViewCommentsDocuments__WEBPACK_IMPORTED_MODULE_33__/* ["default"] */ .Z, {
                open: open,
                open1: open1,
                handleClose: handleClose,
                selected1: selected1
            })
        ]
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_26__.getSession)({
        req: context.req
    });
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    if (session.user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    if (session.user?.role === "Stores") {
        return {
            redirect: {
                destination: "/store",
                permanent: false
            }
        };
    }
    if (session.user?.role === "Safety") {
        return {
            redirect: {
                destination: "/safety",
                permanent: false
            }
        };
    }
    return {
        props: {}
    };
}; // <Head>
 //   <title>Attendance</title>
 //   <meta name="description" content="Generated by create next app" />
 //   <meta name="viewport" content="width=device-width, initial-scale=1" />
 //   <link rel="icon" href="/favicon.ico" />
 // </Head>

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 2494:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Done");

/***/ }),

/***/ 1664:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 7460:
/***/ ((module) => {

module.exports = require("@mui/icons-material/NavigateBefore");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 419:
/***/ ((module) => {

module.exports = require("@mui/material/");

/***/ }),

/***/ 3765:
/***/ ((module) => {

module.exports = require("@mui/material/Alert");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8330:
/***/ ((module) => {

module.exports = require("@mui/material/Checkbox");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 9174:
/***/ ((module) => {

module.exports = require("@mui/material/Snackbar");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 8099:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 7308:
/***/ ((module) => {

module.exports = require("@mui/material/TablePagination");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 9868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6302:
/***/ ((module) => {

module.exports = require("xlsx");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7972,681], () => (__webpack_exec__(85)));
module.exports = __webpack_exports__;

})();