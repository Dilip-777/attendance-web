"use strict";
(() => {
var exports = {};
exports.id = 7303;
exports.ids = [7303];
exports.modules = {

/***/ 8139:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormSelect": () => (/* binding */ FormSelect),
/* harmony export */   "default": () => (/* binding */ PlantCommercial),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9181);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8823);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8099);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(443);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5953);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7308);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4848);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6395);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _utils_get8hr__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(606);
/* harmony import */ var _ui_component_MonthSelect__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8877);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9648);
/* harmony import */ var _utils_getccm__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4220);
/* harmony import */ var _utils_getlrf__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7074);
/* harmony import */ var _utils_getColony__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4394);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_16__]);
axios__WEBPACK_IMPORTED_MODULE_16__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




















const FormSelect = ({ value , setValue , options  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_12__.FormControl, {
        fullWidth: true,
        variant: "outlined",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_12__.Select, {
            value: value,
            onChange: (e)=>setValue(e.target.value),
            placeholder: "Select",
            children: options.map((option, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_12__.MenuItem, {
                    value: option.value,
                    children: option.label
                }, index))
        })
    });
};
function PlantCommercial({ workorders  }) {
    const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_1__.useState(dayjs__WEBPACK_IMPORTED_MODULE_15___default()().format("MM/YYYY"));
    const [page, setPage] = react__WEBPACK_IMPORTED_MODULE_1__.useState(0);
    const [rowsPerPage, setRowsPerPage] = react__WEBPACK_IMPORTED_MODULE_1__.useState(10);
    const [loading, setLoading] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [timekeepers, setTimekeepers] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const [payouts, setPayouts] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const [rows, setRows] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const fetchTimekeepers = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_16__["default"].get(`/api/gettimekeeper?month=${value}`);
        setTimekeepers(res.data);
        setLoading(false);
    };
    const fetchPayouts = async ()=>{
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_16__["default"].get(`/api/payouttracker?month=${value}`);
        setPayouts(res.data);
        setLoading(false);
    };
    const getAttendance = (contractorname)=>{
        console.log(timekeepers.filter((t)=>t.contractorname === contractorname));
        const { totalnetPayable: total8HR , rows1  } = (0,_utils_get8hr__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(timekeepers.filter((t)=>t.contractorname === contractorname && t.department === "8HR"), dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").month() + 1, dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").year());
        console.log(rows1);
        const { totalnetPayable: total12HR  } = (0,_utils_get8hr__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(timekeepers.filter((t)=>t.contractorname === contractorname && t.department === "12HR"), dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").month() + 1, dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").year());
        const { totalnetPayable: totalccm  } = (0,_utils_getccm__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)(timekeepers.filter((t)=>t.contractorname === contractorname && t.department === "CCM"), dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").month() + 1, dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").year());
        const { totalnetPayable: totallrf  } = (0,_utils_getlrf__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)(timekeepers.filter((t)=>t.contractorname === contractorname && t.department === "LRF"), dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").month() + 1, dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").year());
        const { totalnetPayable: totalcolony  } = (0,_utils_getColony__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)(timekeepers.filter((t)=>t.contractorname === contractorname && t.department === "Colony"), dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").month() + 1, dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY").year());
        const total = total8HR + total12HR + totalccm + totallrf + totalcolony;
        return [
            total8HR,
            total12HR,
            totalccm,
            totallrf,
            totalcolony,
            total
        ];
    };
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        fetchTimekeepers();
        fetchPayouts();
    }, [
        value
    ]);
    const handleChangePage = (event, newPage)=>{
        setPage(newPage);
    };
    const handleChangeRowsPerPage = (event)=>{
        setRowsPerPage(+event.target.value);
        setPage(0);
    };
    const handleAddRecord = async (amount, contractorName, contractorId)=>{
        await axios__WEBPACK_IMPORTED_MODULE_16__["default"].post(`/api/payouttracker`, {
            amount,
            contractorName,
            contractorId,
            month: value,
            gst: 9,
            tds: 9,
            finalpayableamount: Math.floor(amount + amount * 0.18)
        });
        fetchPayouts();
    };
    const onChange = (value)=>setValue(value?.format("MM/YYYY") || "");
    console.log(payouts, "payjhbjhgh");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_2___default()), {
        sx: {
            width: "100%"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_12__.Box, {
                sx: {
                    height: "5rem",
                    display: "flex",
                    p: 3,
                    justifyContent: "flex-start",
                    mb: 2
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_MonthSelect__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    label: "Select Date",
                    value: dayjs__WEBPACK_IMPORTED_MODULE_15___default()(value, "MM/YYYY"),
                    onChange: onChange
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_6___default()), {
                sx: {
                    maxHeight: 500,
                    scrollBehavior: "smooth",
                    "&::-webkit-scrollbar": {
                        width: 9,
                        height: 10
                    },
                    "&::-webkit-scrollbar-thumb": {
                        backgroundColor: "#bdbdbd",
                        borderRadius: 2
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_3___default()), {
                    "aria-label": "sticky table",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_7___default()), {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default()), {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "Work Order Id"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "Contractor Name"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "Month"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "8HR"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "12HR"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "CCM"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "LRF"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "Colony"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        align: "center",
                                        children: "Total"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_4___default()), {
                            children: !loading ? workorders.filter((w)=>w.startDate.includes(value)).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    hover: true,
                                    role: "checkbox",
                                    tabIndex: -1,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            align: "center",
                                            colSpan: 1,
                                            children: row.id
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            align: "center",
                                            colSpan: 1,
                                            children: row.contractorName
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            align: "center",
                                            colSpan: 1,
                                            children: dayjs__WEBPACK_IMPORTED_MODULE_15___default()(row.startDate, "DD/MM/YYYY").format("MM/YYYY")
                                        }),
                                        getAttendance(row.contractorName).map((a)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                align: "center",
                                                colSpan: 1,
                                                children: a
                                            })),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            align: "center",
                                            colSpan: 1,
                                            onClick: ()=>handleAddRecord(getAttendance(row.contractorName)[5], row.contractorName, parseInt(row.contractorId)),
                                            children: payouts.find((p)=>p.contractorName === row.contractorName) ? "Update Record" : "Add Record"
                                        })
                                    ]
                                }, row.id);
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    children: "Loading..."
                                })
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8___default()), {
                rowsPerPageOptions: [
                    10,
                    25,
                    100
                ],
                component: "div",
                count: rows.length,
                rowsPerPage: rowsPerPage,
                page: page,
                onPageChange: handleChangePage,
                onRowsPerPageChange: handleChangeRowsPerPage
            })
        ]
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_10__.getSession)({
        req: context.req
    });
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_11__/* ["default"].user.findUnique */ .Z.user.findUnique({
        where: {
            email: session?.user?.email
        }
    });
    if (user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    const workorders = await _lib_prisma__WEBPACK_IMPORTED_MODULE_11__/* ["default"].workorder.findMany */ .Z.workorder.findMany();
    return {
        props: {
            workorders
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getColony)
/* harmony export */ });
function getColony(timekeeper, month, year) {
    const getCount = (data, gender, extra)=>{
        return data.filter((item)=>item.gender?.toLowerCase() === gender || item.gender === extra).length;
    };
    const getData = (date)=>{
        const filtered = timekeeper.filter((item)=>item.attendancedate === date);
        const m = getCount(filtered, "male", "M");
        const f = getCount(filtered, "female", "F");
        const total = m + f;
        return {
            date,
            m,
            f,
            total
        };
    };
    function getTotalAttendanceRecord(rows) {
        const totalAttendance = {
            date: "Total Attendance",
            m: 0,
            f: 0,
            total: 0
        };
        rows.forEach((row)=>{
            totalAttendance.m += row.m;
            totalAttendance.f += row.f;
            totalAttendance.total += row.total;
        });
        return totalAttendance;
    }
    function getTotalOvertimeRecord(data) {
        const totalOvertime = {
            date: "Total Overtime",
            m: 0,
            f: 0,
            total: 0
        };
        data.forEach((item)=>{
            if (item.gender?.toLowerCase() === "male" || item.gender === "M") {
                totalOvertime.m += Number(item.manualovertime || item.overtime);
            }
            if (item.gender?.toLowerCase() === "female", item.gender === "F") {
                totalOvertime.f += Number(item.manualovertime || item.overtime);
            }
            totalOvertime.total += Number(item.manualovertime || item.overtime);
        });
        return totalOvertime;
    }
    const getAmount = (totalAttendance, rate)=>{
        const totalAmount = {
            date: "Total Amount",
            m: totalAttendance.m * rate.m,
            f: totalAttendance.f * rate.f,
            total: 0
        };
        const total = totalAmount.m + totalAmount.f;
        return {
            ...totalAmount,
            total
        };
    };
    const getTotalOtAmount = (totalOvertime, rate)=>{
        const totalAmount = {
            date: "OT Amount",
            m: totalOvertime.m * rate.m / 8,
            f: totalOvertime.f * rate.f / 8,
            total: 0
        };
        const total = totalAmount.m + totalAmount.f;
        return {
            ...totalAmount,
            total
        };
    };
    const getTotalAmount = (totalAmount, totalOtAmount)=>{
        const netAmount = {
            date: "Total Amount",
            m: totalAmount.m + totalOtAmount.m,
            f: totalAmount.f + totalOtAmount.f,
            total: totalAmount.total + totalOtAmount.total
        };
        return netAmount;
    };
    const getCPAmount = (cp, totalAttendance)=>{
        const cpAmount = {
            date: "CP Amount",
            m: cp.m * totalAttendance.m,
            f: cp.f * totalAttendance.f,
            total: 0
        };
        const total = Object.values(cpAmount).filter((value)=>typeof value === "number").reduce((a, b)=>Number(a) + Number(b), 0);
        return {
            ...cpAmount,
            total
        };
    };
    const getTaxable = (totalAmount, cpAmount)=>{
        const taxable = {
            date: "Taxable",
            m: totalAmount.m - cpAmount.m,
            f: totalAmount.f - cpAmount.f,
            total: totalAmount.total - cpAmount.total
        };
        return taxable;
    };
    const getGst = (taxable)=>{
        const gst = {
            date: "GST",
            m: taxable.m * 0.18,
            f: taxable.f * 0.18,
            total: taxable.total * 0.18
        };
        return gst;
    };
    const getBillAmount = (taxable, gst)=>{
        const billAmount = {
            date: "Bill Amount",
            m: taxable.m + gst.m,
            f: taxable.f + gst.f,
            total: taxable.total + gst.total
        };
        return billAmount;
    };
    const getTds = (taxable)=>{
        const tds = {
            date: "TDS",
            m: taxable.m * 0.1,
            f: taxable.f * 0.1,
            total: taxable.total * 0.1
        };
        return tds;
    };
    const getNetPayable = (billAmount, tds)=>{
        const netPayable = {
            date: "Net Payable",
            m: Math.floor(billAmount.m - tds.m),
            f: Math.floor(billAmount.f - tds.f),
            total: Math.floor(billAmount.total - tds.total)
        };
        return netPayable;
    };
    //   async function getRows(month: number, year: number) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    const rows = [];
    for(let i = startDate.getDate(); i <= endDate.getDate(); i++){
        const date = `${i.toString().padStart(2, "0")}/${month.toString().padStart(2, "0")}/${year}`;
        rows.push(getData(date));
    }
    const rows1 = [];
    const totalAttendance = getTotalAttendanceRecord(rows);
    rows.push(totalAttendance);
    rows1.push({
        ...totalAttendance,
        date: "Total Man days"
    });
    const rates = {
        date: "Rate",
        m: 365,
        f: 305,
        total: 0
    };
    rows.push(rates);
    rows1.push(rates);
    const Amount = getAmount(totalAttendance, rates);
    rows.push(Amount);
    rows1.push(Amount);
    const data = timekeeper.filter((entry)=>{
        const entryMonth = parseInt(entry.attendancedate.split("/")[1]);
        const entryYear = parseInt(entry.attendancedate.split("/")[2]);
        return entryMonth === month && entryYear === year;
    });
    const totalOvertime = getTotalOvertimeRecord(data);
    rows.push(totalOvertime);
    rows1.push(totalOvertime);
    const totalOtAmount = getTotalOtAmount(totalOvertime, rates);
    rows.push(totalOtAmount);
    rows1.push(totalOtAmount);
    const totalAmount = getTotalAmount(Amount, totalOtAmount);
    rows.push(totalAmount);
    rows1.push(totalAmount);
    const cp = {
        date: "CP",
        m: 34.5,
        f: 27.5,
        total: 0
    };
    rows.push(cp);
    rows1.push(cp);
    const cpAmount = getCPAmount(cp, totalAttendance);
    rows.push(cpAmount);
    rows1.push(cpAmount);
    const taxable = getTaxable(totalAmount, cpAmount);
    rows1.push(taxable);
    const gst = getGst(taxable);
    rows1.push(gst);
    const billAmount = getBillAmount(taxable, gst);
    rows1.push(billAmount);
    const tds = getTds(taxable);
    rows1.push(tds);
    const netPayable = getNetPayable(billAmount, tds);
    rows1.push(netPayable);
    return {
        rows,
        totalAmount,
        cpAmount,
        totalOvertime,
        totalOtAmount,
        Amount,
        totalAttendance,
        total1: totalAmount.total + cpAmount.total,
        rows1,
        totalnetPayable: netPayable.total
    };
}


/***/ }),

/***/ 4220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getCCM)
/* harmony export */ });
function getCCM(timekeeper, month, year) {
    const getCount = (data, designation)=>{
        return data.filter((item)=>item.designation === designation).length;
    };
    const getData = (date)=>{
        const filtered = timekeeper.filter((item)=>item.attendancedate === date);
        const ele = getCount(filtered, "ELE");
        const lco = getCount(filtered, "LCO");
        const tman = getCount(filtered, "TMAN");
        const filter = getCount(filtered, "FILTER");
        const po = getCount(filtered, "PO");
        const bco = getCount(filtered, "BCO");
        const srfilter = getCount(filtered, "SRFILTER");
        const incharge = getCount(filtered, "INCHARGE");
        const mo = getCount(filtered, "MO");
        const shiftinch = getCount(filtered, "SHIFTINCH");
        const gc = getCount(filtered, "GC");
        const tmesson = getCount(filtered, "TMESSON");
        const svr = getCount(filtered, "SVR");
        const sbo = getCount(filtered, "SBO");
        const lmes = getCount(filtered, "LMES");
        const lman = getCount(filtered, "LMAN");
        const forman = getCount(filtered, "FORMAN");
        const jrele = getCount(filtered, "JR ELE");
        const helper = getCount(filtered, "HELPER");
        const total = ele + lco + tman + filter + po + bco + srfilter + incharge + mo + shiftinch + gc + tmesson + svr + sbo + lmes + lman + forman + jrele + helper;
        return {
            date,
            ele,
            lco,
            tman,
            filter,
            po,
            bco,
            srfilter,
            incharge,
            mo,
            shiftinch,
            gc,
            tmesson,
            svr,
            sbo,
            lmes,
            lman,
            forman,
            jrele,
            helper,
            total
        };
    };
    function getTotalAttendanceRecord(rows) {
        const totalAttendance = {
            date: "Total Attendance",
            ele: 0,
            lco: 0,
            tman: 0,
            filter: 0,
            po: 0,
            bco: 0,
            srfilter: 0,
            incharge: 0,
            mo: 0,
            shiftinch: 0,
            gc: 0,
            tmesson: 0,
            svr: 0,
            sbo: 0,
            lmes: 0,
            lman: 0,
            forman: 0,
            jrele: 0,
            helper: 0,
            total: 0
        };
        rows.forEach((row)=>{
            totalAttendance.ele += row.ele;
            totalAttendance.lco += row.lco;
            totalAttendance.tman += row.tman;
            totalAttendance.filter += row.filter;
            totalAttendance.po += row.po;
            totalAttendance.bco += row.bco;
            totalAttendance.srfilter += row.srfilter;
            totalAttendance.incharge += row.incharge;
            totalAttendance.mo += row.mo;
            totalAttendance.shiftinch += row.shiftinch;
            totalAttendance.gc += row.gc;
            totalAttendance.tmesson += row.tmesson;
            totalAttendance.svr += row.svr;
            totalAttendance.sbo += row.sbo;
            totalAttendance.lmes += row.lmes;
            totalAttendance.lman += row.lman;
            totalAttendance.forman += row.forman;
            totalAttendance.jrele += row.jrele;
            totalAttendance.helper += row.helper;
            totalAttendance.total += row.total;
        });
        return totalAttendance;
    }
    function getTotalOvertimeRecord(data) {
        const totalOvertime = {
            date: "Total Overtime",
            ele: 0,
            lco: 0,
            tman: 0,
            filter: 0,
            po: 0,
            bco: 0,
            srfilter: 0,
            incharge: 0,
            mo: 0,
            shiftinch: 0,
            gc: 0,
            tmesson: 0,
            svr: 0,
            sbo: 0,
            lmes: 0,
            lman: 0,
            forman: 0,
            jrele: 0,
            helper: 0,
            total: 0
        };
        data.forEach((item)=>{
            if (item.designation === "ELE") {
                totalOvertime.ele += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "LCO") {
                totalOvertime.lco += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "TMAN") {
                totalOvertime.tman += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "PO") {
                totalOvertime.po += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "BCO") {
                totalOvertime.bco += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "SRFILTER") {
                totalOvertime.srfilter += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "INCHARGE") {
                totalOvertime.incharge += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "MO") {
                totalOvertime.mo += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "SHIFTINCH") {
                totalOvertime.shiftinch += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "GC") {
                totalOvertime.gc += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "TMESSON") {
                totalOvertime.tmesson += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "SVR") {
                totalOvertime.svr += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "SBO") {
                totalOvertime.sbo += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "LMES") {
                totalOvertime.lmes += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "LMAN") {
                totalOvertime.lman += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "FORMAN") {
                totalOvertime.forman += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "JRELE") {
                totalOvertime.jrele += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "HELPER") {
                totalOvertime.helper += Number(item.manualovertime || item.overtime);
            }
            totalOvertime.total += Number(item.manualovertime || item.overtime);
        });
        return totalOvertime;
    }
    const getAmount = (totalAttendance, rate)=>{
        const totalAmount = {
            date: "Total Amount",
            ele: totalAttendance.ele * rate.ele,
            lco: totalAttendance.lco * rate.lco,
            tman: totalAttendance.tman * rate.tman,
            filter: totalAttendance.filter * rate.filter,
            po: totalAttendance.po * rate.po,
            bco: totalAttendance.bco * rate.bco,
            srfilter: totalAttendance.srfilter * rate.srfilter,
            incharge: totalAttendance.incharge * rate.incharge,
            mo: totalAttendance.mo * rate.mo,
            shiftinch: totalAttendance.shiftinch * rate.shiftinch,
            gc: totalAttendance.gc * rate.gc,
            tmesson: totalAttendance.tmesson * rate.tmesson,
            svr: totalAttendance.svr * rate.svr,
            sbo: totalAttendance.sbo * rate.sbo,
            lmes: totalAttendance.lmes * rate.lmes,
            lman: totalAttendance.lman * rate.lman,
            forman: totalAttendance.forman * rate.forman,
            jrele: totalAttendance.jrele * rate.jrele,
            helper: totalAttendance.helper * rate.helper,
            total: 0
        };
        const total = Object.values(totalAmount).filter((value)=>typeof value === "number").reduce((a, b)=>Number(a) + Number(b), 0);
        return {
            ...totalAmount,
            total
        };
    };
    const getTotalOtAmount = (totalOvertime, rate)=>{
        const totalAmount = {
            date: "OT Amount",
            ele: totalOvertime.ele * rate.ele / 8,
            lco: totalOvertime.lco * rate.lco / 8,
            tman: totalOvertime.tman * rate.tman / 8,
            filter: totalOvertime.filter * rate.filter / 8,
            po: totalOvertime.po * rate.po / 8,
            bco: totalOvertime.bco * rate.bco / 8,
            srfilter: totalOvertime.srfilter * rate.srfilter / 8,
            incharge: totalOvertime.incharge * rate.incharge / 8,
            mo: totalOvertime.mo * rate.mo / 8,
            shiftinch: totalOvertime.shiftinch * rate.shiftinch / 8,
            gc: totalOvertime.gc * rate.gc / 8,
            tmesson: totalOvertime.tmesson * rate.tmesson / 8,
            svr: totalOvertime.svr * rate.svr / 8,
            sbo: totalOvertime.sbo * rate.sbo / 8,
            lmes: totalOvertime.lmes * rate.lmes / 8,
            lman: totalOvertime.lman * rate.lman / 8,
            forman: totalOvertime.forman * rate.forman / 8,
            jrele: totalOvertime.jrele * rate.jrele / 8,
            helper: totalOvertime.helper * rate.helper / 8,
            total: 0
        };
        const total = Object.values(totalAmount).filter((value)=>typeof value === "number").reduce((a, b)=>Number(a) + Number(b), 0);
        return {
            ...totalAmount,
            total
        };
    };
    const getTotalAmount = (totalAmount, totalOtAmount)=>{
        const netAmount = {
            date: "Total Amount",
            ele: totalAmount.ele + totalOtAmount.ele,
            lco: totalAmount.lco + totalOtAmount.lco,
            tman: totalAmount.tman + totalOtAmount.tman,
            filter: totalAmount.filter + totalOtAmount.filter,
            po: totalAmount.po + totalOtAmount.po,
            bco: totalAmount.bco + totalOtAmount.bco,
            srfilter: totalAmount.srfilter + totalOtAmount.srfilter,
            incharge: totalAmount.incharge + totalOtAmount.incharge,
            mo: totalAmount.mo + totalOtAmount.mo,
            shiftinch: totalAmount.shiftinch + totalOtAmount.shiftinch,
            gc: totalAmount.gc + totalOtAmount.gc,
            tmesson: totalAmount.tmesson + totalOtAmount.tmesson,
            svr: totalAmount.svr + totalOtAmount.svr,
            sbo: totalAmount.sbo + totalOtAmount.sbo,
            lmes: totalAmount.lmes + totalOtAmount.lmes,
            lman: totalAmount.lman + totalOtAmount.lman,
            forman: totalAmount.forman + totalOtAmount.forman,
            jrele: totalAmount.jrele + totalOtAmount.jrele,
            helper: totalAmount.helper + totalOtAmount.helper,
            total: totalAmount.total + totalOtAmount.total
        };
        return netAmount;
    };
    const getGST = (taxable)=>{
        const gst = {
            date: "GST",
            ele: Math.floor(taxable.ele * 0.18),
            lco: Math.floor(taxable.lco * 0.18),
            tman: Math.floor(taxable.tman * 0.18),
            filter: Math.floor(taxable.filter * 0.18),
            po: Math.floor(taxable.po * 0.18),
            bco: Math.floor(taxable.bco * 0.18),
            srfilter: Math.floor(taxable.srfilter * 0.18),
            incharge: Math.floor(taxable.incharge * 0.18),
            mo: Math.floor(taxable.mo * 0.18),
            shiftinch: Math.floor(taxable.shiftinch * 0.18),
            gc: Math.floor(taxable.gc * 0.18),
            tmesson: Math.floor(taxable.tmesson * 0.18),
            svr: Math.floor(taxable.svr * 0.18),
            sbo: Math.floor(taxable.sbo * 0.18),
            lmes: Math.floor(taxable.lmes * 0.18),
            lman: Math.floor(taxable.lman * 0.18),
            forman: Math.floor(taxable.forman * 0.18),
            jrele: Math.floor(taxable.jrele * 0.18),
            helper: Math.floor(taxable.helper * 0.18),
            total: Math.floor(taxable.total * 0.18)
        };
        return gst;
    };
    const getBillAmount = (taxable, gst)=>{
        const billAmount = {
            date: "Bill Amount",
            ele: taxable.ele + gst.ele,
            lco: taxable.lco + gst.lco,
            tman: taxable.tman + gst.tman,
            filter: taxable.filter + gst.filter,
            po: taxable.po + gst.po,
            bco: taxable.bco + gst.bco,
            srfilter: taxable.srfilter + gst.srfilter,
            incharge: taxable.incharge + gst.incharge,
            mo: taxable.mo + gst.mo,
            shiftinch: taxable.shiftinch + gst.shiftinch,
            gc: taxable.gc + gst.gc,
            tmesson: taxable.tmesson + gst.tmesson,
            svr: taxable.svr + gst.svr,
            sbo: taxable.sbo + gst.sbo,
            lmes: taxable.lmes + gst.lmes,
            lman: taxable.lman + gst.lman,
            forman: taxable.forman + gst.forman,
            jrele: taxable.jrele + gst.jrele,
            helper: taxable.helper + gst.helper,
            total: taxable.total + gst.total
        };
        return billAmount;
    };
    const getTds = (taxable)=>{
        const tds = {
            date: "TDS",
            ele: Math.floor(taxable.ele * 0.01),
            lco: Math.floor(taxable.lco * 0.01),
            tman: Math.floor(taxable.tman * 0.01),
            filter: Math.floor(taxable.filter * 0.01),
            po: Math.floor(taxable.po * 0.01),
            bco: Math.floor(taxable.bco * 0.01),
            srfilter: Math.floor(taxable.srfilter * 0.01),
            incharge: Math.floor(taxable.incharge * 0.01),
            mo: Math.floor(taxable.mo * 0.01),
            shiftinch: Math.floor(taxable.shiftinch * 0.01),
            gc: Math.floor(taxable.gc * 0.01),
            tmesson: Math.floor(taxable.tmesson * 0.01),
            svr: Math.floor(taxable.svr * 0.01),
            sbo: Math.floor(taxable.sbo * 0.01),
            lmes: Math.floor(taxable.lmes * 0.01),
            lman: Math.floor(taxable.lman * 0.01),
            forman: Math.floor(taxable.forman * 0.01),
            jrele: Math.floor(taxable.jrele * 0.01),
            helper: Math.floor(taxable.helper * 0.01),
            total: Math.floor(taxable.total * 0.01)
        };
        return tds;
    };
    const getNetPayable = (billAmount, tds)=>{
        const netPayable = {
            date: "Net Payable",
            ele: Math.floor(billAmount.ele + tds.ele),
            lco: Math.floor(billAmount.lco + tds.lco),
            tman: Math.floor(billAmount.tman + tds.tman),
            filter: Math.floor(billAmount.filter + tds.filter),
            po: Math.floor(billAmount.po + tds.po),
            bco: Math.floor(billAmount.bco + tds.bco),
            srfilter: Math.floor(billAmount.srfilter + tds.srfilter),
            incharge: Math.floor(billAmount.incharge + tds.incharge),
            mo: Math.floor(billAmount.mo + tds.mo),
            shiftinch: Math.floor(billAmount.shiftinch + tds.shiftinch),
            gc: Math.floor(billAmount.gc + tds.gc),
            tmesson: Math.floor(billAmount.tmesson + tds.tmesson),
            svr: Math.floor(billAmount.svr + tds.svr),
            sbo: Math.floor(billAmount.sbo + tds.sbo),
            lmes: Math.floor(billAmount.lmes + tds.lmes),
            lman: Math.floor(billAmount.lman + tds.lman),
            forman: Math.floor(billAmount.forman + tds.forman),
            jrele: Math.floor(billAmount.jrele + tds.jrele),
            helper: Math.floor(billAmount.helper + tds.helper),
            total: Math.floor(billAmount.total + tds.total)
        };
        return netPayable;
    };
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    const rows = [];
    for(let i = startDate.getDate(); i <= endDate.getDate(); i++){
        const date = `${i.toString().padStart(2, "0")}/${month.toString().padStart(2, "0")}/${year}`;
        rows.push(getData(date));
    }
    const rows1 = [];
    const totalAttendance = getTotalAttendanceRecord(rows);
    rows.push(totalAttendance);
    rows1.push({
        ...totalAttendance,
        date: "Total Man days"
    });
    const l = rows.length - 1;
    const rates = {
        date: "Rate",
        ele: Math.floor(31500 / l),
        lco: Math.floor(20000 / l),
        tman: Math.floor(19000 / l),
        filter: Math.floor(21500 / l),
        po: Math.floor(16000 / l),
        bco: Math.floor(17000 / l),
        srfilter: Math.floor(26500 / l),
        incharge: Math.floor(26500 / l),
        mo: Math.floor(21400 / l),
        shiftinch: Math.floor(19500 / l),
        gc: Math.floor(17000 / l),
        tmesson: Math.floor(18000 / l),
        svr: Math.floor(18000 / l),
        sbo: Math.floor(18000 / l),
        lmes: Math.floor(18000 / l),
        lman: Math.floor(18000 / l),
        forman: Math.floor(18000 / l),
        jrele: Math.floor(18000 / l),
        helper: Math.floor(18000 / l),
        total: 0
    };
    rows.push(rates);
    rows1.push(rates);
    const Amount = getAmount(totalAttendance, rates);
    rows.push(Amount);
    rows1.push(Amount);
    const data = timekeeper.filter((entry)=>{
        const entryMonth = parseInt(entry.attendancedate.split("/")[1]);
        const entryYear = parseInt(entry.attendancedate.split("/")[2]);
        return entryMonth === month && entryYear === year;
    });
    const totalOvertime = getTotalOvertimeRecord(data);
    rows.push(totalOvertime);
    rows1.push(totalOvertime);
    const totalOtAmount = getTotalOtAmount(totalOvertime, rates);
    rows.push(totalOtAmount);
    rows1.push(totalOtAmount);
    const totalAmount = getTotalAmount(Amount, totalOtAmount);
    rows.push(totalAmount);
    rows1.push({
        ...totalAmount,
        date: "Taxable"
    });
    const gst = getGST(totalAmount);
    rows1.push(gst);
    const billAmount = getBillAmount(totalAmount, gst);
    rows1.push(billAmount);
    const tds = getTds(totalAmount);
    rows1.push(tds);
    const netPayable = getNetPayable(billAmount, tds);
    rows1.push(netPayable);
    return {
        rows,
        totalAmount,
        totalOtAmount,
        Amount,
        rates,
        totalAttendance,
        total1: totalAmount.total,
        rows1,
        totalnetPayable: netPayable.total
    };
}


/***/ }),

/***/ 7074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getLRF)
/* harmony export */ });
function getLRF(timekeeper, month, year) {
    const getCount = (data, designation)=>{
        return data.filter((item)=>item.designation === designation).length;
    };
    const getData = (date)=>{
        const filtered = timekeeper.filter((item)=>item.attendancedate === date);
        const ele = getCount(filtered, "ELE");
        const filter = getCount(filtered, "JRFILTER");
        const srfilter = getCount(filtered, "SRFILTER");
        const lmes = getCount(filtered, "LMES");
        const svr = getCount(filtered, "SVR");
        const helper = getCount(filtered, "HELPER");
        const total = ele + filter + srfilter + lmes + svr + helper;
        return {
            date,
            ele,
            filter,
            srfilter,
            svr,
            lmes,
            helper,
            total
        };
    };
    function getTotalAttendanceRecord(rows) {
        const totalAttendance = {
            date: "Total Attendance",
            ele: 0,
            filter: 0,
            srfilter: 0,
            lmes: 0,
            svr: 0,
            helper: 0,
            total: 0
        };
        rows.forEach((row)=>{
            totalAttendance.ele += row.ele;
            totalAttendance.filter += row.filter;
            totalAttendance.srfilter += row.srfilter;
            totalAttendance.svr += row.svr;
            totalAttendance.lmes += row.lmes;
            totalAttendance.helper += row.helper;
            totalAttendance.total += row.total;
        });
        return totalAttendance;
    }
    function getTotalOvertimeRecord(data) {
        const totalOvertime = {
            date: "Total Overtime",
            ele: 0,
            filter: 0,
            srfilter: 0,
            svr: 0,
            lmes: 0,
            helper: 0,
            total: 0
        };
        data.forEach((item)=>{
            if (item.designation === "ELE") {
                totalOvertime.ele += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "JRFILTER") {
                totalOvertime.filter += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "SRFILTER") {
                totalOvertime.srfilter += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "SVR") {
                totalOvertime.svr += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "LMES") {
                totalOvertime.lmes += Number(item.manualovertime || item.overtime);
            }
            if (item.designation === "HELPER") {
                totalOvertime.helper += Number(item.manualovertime || item.overtime);
            }
            totalOvertime.total += Number(item.manualovertime || item.overtime);
        });
        return totalOvertime;
    }
    const getAmount = (totalAttendance, rate)=>{
        const totalAmount = {
            date: "Total Amount",
            ele: totalAttendance.ele * rate.ele,
            filter: totalAttendance.filter * rate.filter,
            srfilter: totalAttendance.srfilter * rate.srfilter,
            svr: totalAttendance.svr * rate.svr,
            lmes: totalAttendance.lmes * rate.lmes,
            helper: totalAttendance.helper * rate.helper,
            total: 0
        };
        const total = Object.values(totalAmount).filter((value)=>typeof value === "number").reduce((a, b)=>Number(a) + Number(b), 0);
        return {
            ...totalAmount,
            total
        };
    };
    const getTotalOtAmount = (totalOvertime, rate)=>{
        const totalAmount = {
            date: "OT Amount",
            ele: Math.floor(totalOvertime.ele * rate.ele / 8),
            filter: Math.floor(totalOvertime.filter * rate.filter / 8),
            srfilter: Math.floor(totalOvertime.srfilter * rate.srfilter / 8),
            svr: Math.floor(totalOvertime.svr * rate.svr / 8),
            lmes: Math.floor(totalOvertime.lmes * rate.lmes / 8),
            helper: Math.floor(totalOvertime.helper * rate.helper / 8),
            total: 0
        };
        const total = Object.values(totalAmount).filter((value)=>typeof value === "number").reduce((a, b)=>Number(a) + Number(b), 0);
        return {
            ...totalAmount,
            total
        };
    };
    const getTotalAmount = (totalAmount, totalOtAmount)=>{
        const netAmount = {
            date: "Total Amount",
            ele: totalAmount.ele + totalOtAmount.ele,
            filter: totalAmount.filter + totalOtAmount.filter,
            srfilter: totalAmount.srfilter + totalOtAmount.srfilter,
            svr: totalAmount.svr + totalOtAmount.svr,
            lmes: totalAmount.lmes + totalOtAmount.lmes,
            helper: totalAmount.helper + totalOtAmount.helper,
            total: totalAmount.total + totalOtAmount.total
        };
        return netAmount;
    };
    const getGST = (totalAmount)=>{
        const gstAmount = {
            date: "GST",
            ele: Math.floor(totalAmount.ele * 0.18),
            filter: Math.floor(totalAmount.filter * 0.18),
            srfilter: Math.floor(totalAmount.srfilter * 0.18),
            svr: Math.floor(totalAmount.svr * 0.18),
            lmes: Math.floor(totalAmount.lmes * 0.18),
            helper: Math.floor(totalAmount.helper * 0.18),
            total: Math.floor(totalAmount.total * 0.18)
        };
        return gstAmount;
    };
    const getBillAmount = (totalAmount, gstAmount)=>{
        const billAmount = {
            date: "Bill Amount",
            ele: totalAmount.ele + gstAmount.ele,
            filter: totalAmount.filter + gstAmount.filter,
            srfilter: totalAmount.srfilter + gstAmount.srfilter,
            svr: totalAmount.svr + gstAmount.svr,
            lmes: totalAmount.lmes + gstAmount.lmes,
            helper: totalAmount.helper + gstAmount.helper,
            total: totalAmount.total + gstAmount.total
        };
        return billAmount;
    };
    const getTds = (totalAmount)=>{
        const tdsAmount = {
            date: "TDS",
            ele: Math.floor(totalAmount.ele * 0.01),
            filter: Math.floor(totalAmount.filter * 0.01),
            srfilter: Math.floor(totalAmount.srfilter * 0.01),
            svr: Math.floor(totalAmount.svr * 0.01),
            lmes: Math.floor(totalAmount.lmes * 0.01),
            helper: Math.floor(totalAmount.helper * 0.01),
            total: Math.floor(totalAmount.total * 0.01)
        };
        return tdsAmount;
    };
    const getNetPayable = (billAmount, tdsAmount)=>{
        const netPayable = {
            date: "Net Payable",
            ele: Math.floor(billAmount.ele + tdsAmount.ele),
            filter: Math.floor(billAmount.filter + tdsAmount.filter),
            srfilter: Math.floor(billAmount.srfilter + tdsAmount.srfilter),
            svr: Math.floor(billAmount.svr + tdsAmount.svr),
            lmes: Math.floor(billAmount.lmes + tdsAmount.lmes),
            helper: Math.floor(billAmount.helper + tdsAmount.helper),
            total: Math.floor(billAmount.total + tdsAmount.total)
        };
        return netPayable;
    };
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    const rows = [];
    for(let i = startDate.getDate(); i <= endDate.getDate(); i++){
        const date = `${i.toString().padStart(2, "0")}/${month.toString().padStart(2, "0")}/${year}`;
        rows.push(getData(date));
    }
    const rows1 = [];
    const totalAttendance = getTotalAttendanceRecord(rows);
    rows.push(totalAttendance);
    rows1.push({
        ...totalAttendance,
        date: "Total Man Days"
    });
    const l = rows.length - 1;
    const rates = {
        date: "Rate",
        ele: 31500 / l,
        lco: 20000 / l,
        tman: 19000 / l,
        filter: 21500 / l,
        po: 16000 / l,
        bco: 17000 / l,
        srfilter: 26500 / l,
        incharge: 26500 / l,
        mo: 21400 / l,
        shiftinch: 19500 / l,
        gc: 17000 / l,
        tmesson: 18000 / l,
        svr: 18000 / l,
        sbo: 18000 / l,
        lmes: 18000 / l,
        lman: 18000 / l,
        forman: 18000 / l,
        jrele: 18000 / l,
        helper: 18000 / l,
        total: 0
    };
    rows.push(rates);
    rows1.push(rates);
    const Amount = getAmount(totalAttendance, rates);
    rows.push(Amount);
    rows1.push(Amount);
    const data = timekeeper.filter((entry)=>{
        const entryMonth = parseInt(entry.attendancedate.split("/")[1]);
        const entryYear = parseInt(entry.attendancedate.split("/")[2]);
        return entryMonth === month && entryYear === year;
    });
    const totalOvertime = getTotalOvertimeRecord(data);
    rows.push(totalOvertime);
    rows1.push(totalOvertime);
    const totalOtAmount = getTotalOtAmount(totalOvertime, rates);
    rows.push(totalOtAmount);
    rows1.push(totalOtAmount);
    const totalAmount = getTotalAmount(Amount, totalOtAmount);
    rows.push(totalAmount);
    rows1.push(totalAmount);
    const gstAmount = getGST(totalAmount);
    rows1.push(gstAmount);
    const billAmount = getBillAmount(totalAmount, gstAmount);
    rows1.push(billAmount);
    const tds = getTds(billAmount);
    rows1.push(tds);
    const netPayable = getNetPayable(billAmount, tds);
    rows1.push(netPayable);
    return {
        rows,
        totalAttendance,
        rates,
        totalOvertime,
        totalOtAmount,
        totalAmount,
        Amount,
        total1: totalAmount.total,
        rows1,
        totalnetPayable: netPayable.total
    };
}


/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 8099:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 5953:
/***/ ((module) => {

module.exports = require("@mui/material/TableHead");

/***/ }),

/***/ 7308:
/***/ ((module) => {

module.exports = require("@mui/material/TablePagination");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5809], () => (__webpack_exec__(8139)));
module.exports = __webpack_exports__;

})();