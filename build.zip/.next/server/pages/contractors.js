"use strict";
(() => {
var exports = {};
exports.id = 7794;
exports.ids = [7794];
exports.modules = {

/***/ 6526:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3765);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Alert__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9048);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9174);
/* harmony import */ var _mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6302);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_8__]);
axios__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











function ImportData() {
    // on change states
    const [excelFile, setExcelFile] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(null);
    const [excelFileError, setExcelFileError] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [key, setKey] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(0);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    // submit
    const [excelData, setExcelData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(null);
    // it will contain array of objects
    // handle File
    const fileType = [
        "application/vnd.xlsx",
        "application/vnd.ms-excel"
    ];
    const handleFile = (e)=>{
        let selectedFile = e.target.files[0];
        if (selectedFile) {
            let reader = new FileReader();
            reader.readAsArrayBuffer(selectedFile);
            reader.onload = (e)=>{
                console.log(e.target?.result);
                const workbook = xlsx__WEBPACK_IMPORTED_MODULE_10__.read(e.target?.result, {
                    type: "buffer"
                });
                const worksheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[worksheetName];
                const data = xlsx__WEBPACK_IMPORTED_MODULE_10__.utils.sheet_to_json(worksheet);
                console.log(data);
                importing(data);
            };
            setKey(key + 1);
        }
    };
    const handleClick = ()=>{
        setOpen(true);
    };
    const handleClose = (event, reason)=>{
        if (reason === "clickaway") {
            return;
        }
        setOpen(false);
    };
    const action = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_9___default().Fragment), {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default()), {
            size: "small",
            "aria-label": "close",
            color: "inherit",
            onClick: handleClose,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_1___default()), {
                fontSize: "small"
            })
        })
    });
    const getDate = (excelDate)=>{
        // const excelDate = 44986;
        const date = new Date((excelDate - (25567 + 2)) * 86400 * 1000);
        const formattedDate = `${date.getDate().toString().padStart(2, "0")}/${(date.getMonth() + 1).toString().padStart(2, "0")}/${date.getFullYear()}`;
        return formattedDate;
    };
    const importing = async (data)=>{
        console.log(data);
        const keys = [];
        const indices = [];
        data.forEach((d, index)=>{
            [
                "contractorname",
                "contractorId",
                "servicedetail",
                "supplierdetail",
                "contactperson",
                "mobilenumber"
            ].forEach((key)=>{
                if (!d[key]) {
                    if (keys.indexOf(key) === -1) {
                        keys.push(key);
                    }
                    if (!indices.includes(index + 1)) {
                        indices.push(index + 1);
                    }
                }
            });
        });
        if (keys.length > 0) {
            setMessage(`Please check the following keys: ${keys.join(", ")} at rows: ${indices.join(", ")}`);
            setError(true);
            handleClick();
            return;
        }
        const body = data.map((data)=>({
                contractorname: data.contractorname,
                contractorId: data.contractorId,
                servicedetail: data.servicedetail,
                supplierdetail: data.supplierdetail,
                contactperson: data.contactperson,
                mobilenumber: data.mobilenumber?.toString()
            }));
        setLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_8__["default"].post("/api/importdata?type=contractor", body).then((res)=>{
            setError(false);
            handleClick();
        }).catch((err)=>{
            setMessage("Please Provide Valid Data");
            setError(true);
            handleClick();
        });
        setLoading(false);
    };
    // new Date(timeValue * 24 * 60 * 60 * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_7___default()), {
        direction: "row",
        alignItems: "center",
        spacing: 2,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                disabled: loading,
                variant: "contained",
                component: "label",
                children: [
                    "Upload",
                    loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default()), {
                        size: 15,
                        sx: {
                            ml: 1,
                            color: "#364152"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        hidden: true,
                        type: "file",
                        className: "form-control",
                        onChange: handleFile,
                        required: true
                    }, key)
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_6___default()), {
                open: open,
                autoHideDuration: 6000,
                onClose: handleClose,
                action: action,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Alert__WEBPACK_IMPORTED_MODULE_2___default()), {
                    onClose: handleClose,
                    severity: error ? "error" : "success",
                    sx: {
                        width: "100%"
                    },
                    children: error ? message : "Data Uploaded Successfully"
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImportData);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1884:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Contractors),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Backdrop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5074);
/* harmony import */ var _mui_material_Backdrop__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Backdrop__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Fade__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5634);
/* harmony import */ var _mui_material_Fade__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Fade__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6096);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9564);
/* harmony import */ var _mui_material_Modal__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Modal__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_Select__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2651);
/* harmony import */ var _mui_material_Select__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Select__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6395);
/* harmony import */ var _components_Table_Table__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8525);
/* harmony import */ var _components_importContractors__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6526);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_importContractors__WEBPACK_IMPORTED_MODULE_16__, axios__WEBPACK_IMPORTED_MODULE_17__]);
([_components_importContractors__WEBPACK_IMPORTED_MODULE_16__, axios__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 4
};
const options = [
    {
        link: "/pc8hr",
        label: "8HR"
    },
    {
        link: "/pc12hr",
        label: "12HR"
    },
    {
        link: "pcccm",
        label: "CCM"
    },
    {
        link: "pclrf",
        label: "LRF"
    },
    {
        link: "pccolony",
        label: "Colony"
    }
];
const createHeadCells = (id, label, numeric, included)=>{
    return {
        id: id,
        label: label,
        numeric: numeric,
        included: included
    };
};
const headCells = [
    createHeadCells("contractorId", "Contractor ID", false, false),
    createHeadCells("contractorname", "Contractor Name", false, false),
    createHeadCells("servicedetail", "Service Detail", true, false),
    createHeadCells("supplierdetail", "Supplier Detail", true, false),
    createHeadCells("telephonenumber", "telephone Number", true, false),
    createHeadCells("emailid", "Email", false, false),
    createHeadCells("mobilenumber", "Mobile Number", true, false),
    createHeadCells("officeaddress", "Office Address", false, false),
    createHeadCells("website", "Website", false, false),
    createHeadCells("expirationDate", "Expiration Date", false, false),
    createHeadCells("servicecharge", "Service Charge", true, false),
    createHeadCells("organisationtype", "Organisation Type", false, false),
    createHeadCells("isocertified", "Is Certified", false, false),
    createHeadCells("uniquenumber", "Unique Number", false, false),
    createHeadCells("registration_number", "Registration Number", true, false),
    createHeadCells("first_registration_number", "First Registration Number", false, false),
    createHeadCells("delivery_procedure", "Delivery Procedure", false, false)
];
function Contractors({ contractors , departments  }) {
    const [filterName, setFilterName] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_13__.useSession)();
    const [contractorId, setContractorId] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const fetchContractors = async ()=>{
        const res = await axios__WEBPACK_IMPORTED_MODULE_17__["default"].get("/api/hr/contractors");
        console.log(res.data);
    };
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        fetchContractors();
    }, []);
    // React.useEffect(() => {
    //   const user = session?.user;
    //   if(user) {
    //     user.role = "TimeKeeper";
    //     session.user = user;
    //     await session.s
    //   }
    // })
    const options = departments.map((d)=>({
            link: `pc${d.department.toLowerCase()}`,
            label: d.department
        }));
    const handleClose = ()=>{
        setOpen(false);
        setContractorId("");
    };
    const headcell1 = createHeadCells("attendance", "View Attendance", false, true);
    const headcell2 = createHeadCells("hoform", "Ho Commercial Form", false, true);
    const getHeadCells = ()=>{
        if (session?.user?.role === "HR") return [];
        else if (session?.user?.role === "PlantCommercial") return [
            headcell1
        ];
        else if (session?.user?.role === "HoCommercialAuditor") return [
            headcell1,
            headcell2
        ];
        else return [
            headcell1
        ];
    };
    const extraHeadCells = getHeadCells();
    const handleClickReport = ()=>{
        const tableRows = [
            [
                "Contractorid",
                "Contractor Name",
                "Service Detail",
                "Supplier Detail",
                "Mobile Number",
                "Office Address",
                "Email",
                "Organisation Type",
                "Date of Incorporation",
                "Competitor Name",
                "ISO Certified",
                "Turnover Last Year",
                "Turnover 2 Year Back",
                "Unique Number",
                "Registration Number",
                "First Registration Number",
                "Latest Month GST1 Filed",
                "Latest Month GST2B Filed",
                "Comply Regulatory",
                "Code of Proprietor",
                "List Major Product",
                "Quality Control Procedure",
                "Value Add Product",
                "Five Strength Points",
                "Weakness",
                "Training Provided",
                "Clientele",
                "Refrence Organisation1",
                "Reference Contact1",
                "Reference Designation1",
                "Period of Service1",
                "Refrence Organisation2",
                "Reference Contact2",
                "Reference Designation2",
                "Period of Service2",
                "Refrence Organisation3",
                "Reference Contact3",
                "Reference Designation3",
                "Period of Service3"
            ]
        ];
        contractors.forEach((item)=>{
            tableRows.push([
                item.contractorId.toString(),
                item.contractorname,
                item.servicedetail,
                item.supplierdetail,
                item.mobilenumber,
                item.officeaddress || "-",
                (item?.emailid) || "-",
                item.organisationtype || "-",
                item.dateofincorporation?.toString() || "-",
                item.competitorname || "-",
                item.isocertified?.toString() || "-",
                item.turnoverlastyear?.toString() || "-",
                item.turnover2yearback || "-",
                item.uniquenumber || "-",
                item.registration_number || "-",
                item.first_registration_number || "-",
                item.latest_mnth_gst1_filed?.toString() || "-",
                item.latest_mnth_gst2b_filed?.toString() || "-",
                item.comply_regulatory.toString() || "-",
                item.code_of_proprietor || "-",
                item.list_major_product || "-",
                item.qualty_control_procedure || "-",
                item.valueadd_product || "-",
                item.five_strength_points || "-",
                item.weakness || "-",
                item.selection_training_method || "-",
                item.clientele || "-",
                item.reference_organistaion_1 || "-",
                item.reference_contact_1 || "-",
                item.reference_designation_1 || "-",
                item.period_of_service_1 || "-",
                item.reference_organistaion_2 || "-",
                item.reference_contact_2 || "-",
                item.reference_designation_2 || "-",
                item.period_of_service_2 || "-",
                item.reference_organistaion_3 || "-",
                item.reference_contact_3 || "-",
                item.reference_designation_3 || "-",
                item.period_of_service_3 || "-"
            ]);
        });
        const csvContent = `${tableRows.map((row)=>row.join(",")).join("\n")}`;
        // Download CSV file
        const blob = new Blob([
            csvContent
        ], {
            type: "text/csv;charset=utf-8;"
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", "Contractors.csv");
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_11___default()), {
        sx: {
            width: "100%"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_Table__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                rows: contractors.filter((c)=>c.contractorname.toLowerCase().includes(filterName.toLowerCase())),
                editLink: "/contractors",
                filterName: filterName,
                setFilterName: setFilterName,
                headcells: [
                    ...headCells,
                    ...extraHeadCells
                ],
                setContractorId: setContractorId,
                setOpen: setOpen,
                type: "contractor",
                handleClickReport: handleClickReport,
                upload: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_importContractors__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Modal__WEBPACK_IMPORTED_MODULE_8___default()), {
                "aria-labelledby": "transition-modal-title",
                "aria-describedby": "transition-modal-description",
                open: open,
                onClose: handleClose,
                closeAfterTransition: true,
                slots: {
                    backdrop: (_mui_material_Backdrop__WEBPACK_IMPORTED_MODULE_2___default())
                },
                slotProps: {
                    backdrop: {
                        timeout: 500
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Fade__WEBPACK_IMPORTED_MODULE_4___default()), {
                    in: open,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_11___default()), {
                        sx: style,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_10___default()), {
                            spacing: 3,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            children: "Select the Designation"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Select__WEBPACK_IMPORTED_MODULE_9___default()), {
                                            placeholder: "Select the designation",
                                            value: value,
                                            onChange: (e)=>setValue(e.target.value),
                                            children: options?.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    value: option.label,
                                                    children: option.label
                                                }))
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    variant: "contained",
                                    disabled: Boolean(!value),
                                    onClick: ()=>router.push(`plantcommercial?department=${value}&contractorid=${contractorId}`),
                                    children: "View Attendance"
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_13__.getSession)({
        req: context.req
    });
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_14__/* ["default"].user.findUnique */ .Z.user.findUnique({
        where: {
            email: session?.user?.email
        }
    });
    if (user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    const departments = await _lib_prisma__WEBPACK_IMPORTED_MODULE_14__/* ["default"].department.findMany */ .Z.department.findMany();
    const contractors = await _lib_prisma__WEBPACK_IMPORTED_MODULE_14__/* ["default"].contractor.findMany */ .Z.contractor.findMany();
    return {
        props: {
            contractors,
            departments
        }
    };
}; // <Head>
 //   <title>Attendance</title>
 //   <meta name="description" content="Generated by create next app" />
 //   <meta name="viewport" content="width=device-width, initial-scale=1" />
 //   <link rel="icon" href="/favicon.ico" />
 // </Head>

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 1664:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 3866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FilterList");

/***/ }),

/***/ 4752:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Launch");

/***/ }),

/***/ 8911:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocalPrintshop");

/***/ }),

/***/ 8017:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 773:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Visibility");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3765:
/***/ ((module) => {

module.exports = require("@mui/material/Alert");

/***/ }),

/***/ 5074:
/***/ ((module) => {

module.exports = require("@mui/material/Backdrop");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8330:
/***/ ((module) => {

module.exports = require("@mui/material/Checkbox");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 5634:
/***/ ((module) => {

module.exports = require("@mui/material/Fade");

/***/ }),

/***/ 8891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 6096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 3103:
/***/ ((module) => {

module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 9271:
/***/ ((module) => {

module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ 9564:
/***/ ((module) => {

module.exports = require("@mui/material/Modal");

/***/ }),

/***/ 7730:
/***/ ((module) => {

module.exports = require("@mui/material/OutlinedInput");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 2651:
/***/ ((module) => {

module.exports = require("@mui/material/Select");

/***/ }),

/***/ 9174:
/***/ ((module) => {

module.exports = require("@mui/material/Snackbar");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 8099:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 7308:
/***/ ((module) => {

module.exports = require("@mui/material/TablePagination");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6302:
/***/ ((module) => {

module.exports = require("xlsx");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7972,8745,8525], () => (__webpack_exec__(1884)));
module.exports = __webpack_exports__;

})();