(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 8411:
/***/ ((module) => {

// Exports
module.exports = {
	"paper": "#fff",
	"primaryLight": "#eef2f6",
	"primary200": "#90caf9",
	"primaryMain": "#2196f3",
	"primaryDark": "#1e88e5",
	"primary800": "#1565c0",
	"secondaryLight": "#ede7f6",
	"secondary200": "#b39ddb",
	"secondaryMain": "#673ab7",
	"secondaryDark": "#5e35b1",
	"secondary800": "#4527a0",
	"successLight": "#b9f6ca",
	"success200": "#69f0ae",
	"successMain": "#00e676",
	"successDark": "#00c853",
	"errorLight": "#ef9a9a",
	"errorMain": "#f44336",
	"errorDark": "#c62828",
	"orangeLight": "#fbe9e7",
	"orangeMain": "#ffab91",
	"orangeDark": "#d84315",
	"warningLight": "#fff8e1",
	"warningMain": "#ffe57f",
	"warningDark": "#ffc107",
	"grey50": "#f8fafc",
	"grey100": "#eef2f6",
	"grey200": "#e3e8ef",
	"grey300": "#cdd5df",
	"grey500": "#697586",
	"grey600": "#4b5565",
	"grey700": "#364152",
	"grey900": "#121926",
	"darkPaper": "#111936",
	"darkBackground": "#1a223f",
	"darkLevel1": "#29314f",
	"darkLevel2": "#212946",
	"darkTextTitle": "#d7dcec",
	"darkTextPrimary": "#bdc8f0",
	"darkTextSecondary": "#8492c4",
	"darkPrimaryLight": "#eef2f6",
	"darkPrimaryMain": "#2196f3",
	"darkPrimaryDark": "#1e88e5",
	"darkPrimary200": "#90caf9",
	"darkPrimary800": "#1565c0",
	"darkSecondaryLight": "#d1c4e9",
	"darkSecondaryMain": "#7c4dff",
	"darkSecondaryDark": "#651fff",
	"darkSecondary200": "#b39ddb",
	"darkSecondary800": "#6200ea"
};


/***/ }),

/***/ 6138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header_NotificationSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: external "@mui/icons-material/NotificationsActive"
const NotificationsActive_namespaceObject = require("@mui/icons-material/NotificationsActive");
var NotificationsActive_default = /*#__PURE__*/__webpack_require__.n(NotificationsActive_namespaceObject);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/NotificationSection/index.tsx


// material-ui



// ==============================|| NOTIFICATION ||============================== //
const NotificationSection = ()=>{
    const theme = (0,styles_.useTheme)();
    const anchorRef = (0,external_react_.useRef)(null);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
            sx: {
                ml: 2,
                mr: 3,
                [theme.breakpoints.down("md")]: {
                    mr: 2
                }
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ButtonBase, {
                sx: {
                    borderRadius: "12px"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Avatar, {
                    variant: "rounded",
                    sx: {
                        ...theme.typography.commonAvatar,
                        ...theme.typography.mediumAvatar,
                        transition: "all .2s ease-in-out",
                        background: theme.palette.secondary.light,
                        color: theme.palette.secondary.dark,
                        '&[aria-controls="menu-list-grow"],&:hover': {
                            background: theme.palette.secondary.dark,
                            color: theme.palette.secondary.light
                        }
                    },
                    ref: anchorRef,
                    "aria-haspopup": "true",
                    color: "inherit",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((NotificationsActive_default()), {
                        sx: {
                            stroke: 1.5,
                            fontSize: "1.3rem"
                        }
                    })
                })
            })
        })
    });
};
/* harmony default export */ const Header_NotificationSection = (NotificationSection);


/***/ }),

/***/ 244:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2120);
/* harmony import */ var _mui_material_Avatar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Avatar__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Chip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8369);
/* harmony import */ var _mui_material_Chip__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Chip__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5371);
/* harmony import */ var _mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3103);
/* harmony import */ var _mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4192);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1011);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3787);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8315);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7730);
/* harmony import */ var _mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_material_Popover__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5768);
/* harmony import */ var _mui_material_Popover__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Popover__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9801);
/* harmony import */ var _mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(32);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(7608);
/* harmony import */ var _mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _ui_component_cards_MainCard__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(1825);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(681);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_28__]);
axios__WEBPACK_IMPORTED_MODULE_28__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

























// assets




// ==============================|| PROFILE MENU ||============================== //
const ProfileSection = ()=>{
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const customization = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.customization);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_25__.useRouter)();
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_26__.useSession)();
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [selectedIndex, setSelectedIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(-1);
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const anchorRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [role, setRole] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(session?.user?.role || "");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setRole(session?.user?.role || "");
    }, [
        session
    ]);
    const handleClose = (event)=>{
        if (anchorRef.current && anchorRef.current.contains(event.target)) {
            return;
        }
        setOpen(false);
    };
    const handleClose1 = (event)=>{
        if (anchorRef.current && anchorRef.current.contains(event.target)) {
            return;
        }
        setOpen(false);
    };
    const handleListItemClick = (event, index, route = "")=>{
        setSelectedIndex(index);
        handleClose1(event);
        if (route && route !== "") {
            router.push(route);
        }
    };
    const handleToggle = ()=>{
        setOpen((prevOpen)=>!prevOpen);
    };
    const handleChange = async (v)=>{
        setRole(v);
        const res = await axios__WEBPACK_IMPORTED_MODULE_28__["default"].put("/api/shiftrole", {
            id: session?.user?.id,
            role: v
        }).then(async (res)=>{
            await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_26__.signIn)("credentials", {
                email: session?.user?.email,
                specialRole: session?.user?.specialRole
            });
            router.push("/");
        }).catch((err)=>console.log(err));
    };
    const prevOpen = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(open);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (prevOpen.current === true && open === false) {
            if (anchorRef && anchorRef.current) {
                anchorRef.current.focus();
            }
        }
        prevOpen.current = open;
    }, [
        open
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Chip__WEBPACK_IMPORTED_MODULE_6___default()), {
                sx: {
                    height: "48px",
                    alignItems: "center",
                    borderRadius: "27px",
                    transition: "all .2s ease-in-out",
                    borderColor: theme.palette.primary.light,
                    backgroundColor: theme.palette.primary.light,
                    '&[aria-controls="menu-list-grow"], &:hover': {
                        borderColor: theme.palette.primary.main,
                        background: `${theme.palette.primary.main}!important`,
                        color: theme.palette.primary.light,
                        "& svg": {
                            stroke: theme.palette.primary.light
                        }
                    },
                    "& .MuiChip-label": {
                        lineHeight: 0
                    }
                },
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Avatar__WEBPACK_IMPORTED_MODULE_4___default()), {
                    src: "/user-round.svg",
                    sx: {
                        ...theme.typography.mediumAvatar,
                        margin: "8px 0 8px 8px !important",
                        cursor: "pointer"
                    },
                    ref: anchorRef,
                    "aria-controls": open ? "menu-list-grow" : undefined,
                    "aria-haspopup": "true",
                    color: "inherit"
                }),
                label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_22___default()), {
                    sx: {
                        fontSize: "1.3rem",
                        stroke: 1.5
                    }
                }),
                variant: "outlined",
                ref: anchorRef,
                "aria-controls": open ? "menu-list-grow" : undefined,
                "aria-haspopup": "true",
                onClick: handleToggle,
                color: "primary"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Popover__WEBPACK_IMPORTED_MODULE_17___default()), {
                open: open,
                anchorEl: anchorRef.current,
                onClose: handleClose,
                anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "left"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_16___default()), {
                    sx: {
                        maxWidth: "22rem"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7___default()), {
                        onClickAway: handleClose,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ui_component_cards_MainCard__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                            border: false,
                            content: false,
                            boxShadow: true,
                            shadow: theme.shadows[16],
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    sx: {
                                        p: 2,
                                        pb: 0
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_18___default()), {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_18___default()), {
                                                    direction: "row",
                                                    spacing: 0.5,
                                                    alignItems: "center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                            variant: "h4",
                                                            children: "Good Morning,"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                            component: "span",
                                                            variant: "h4",
                                                            sx: {
                                                                fontWeight: 400
                                                            },
                                                            children: session?.user?.name
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                    variant: "subtitle2",
                                                    children: session?.user?.role
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_15___default()), {
                                            sx: {
                                                width: "100%",
                                                pr: 1,
                                                pl: 2,
                                                my: 2,
                                                maxWidth: "20rem"
                                            },
                                            id: "input-search-profile",
                                            value: value,
                                            onChange: (e)=>setValue(e.target.value),
                                            placeholder: "Search profile options",
                                            startAdornment: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                position: "start",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21___default()), {
                                                    sx: {
                                                        fontSize: "1.3rem",
                                                        stroke: 1.5
                                                    }
                                                })
                                            }),
                                            "aria-describedby": "search-helper-text",
                                            inputProps: {
                                                "aria-label": "weight"
                                            }
                                        }),
                                        session?.user?.specialRole && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_component_FormSelect__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                                            value: role,
                                            handleChange: (v)=>{
                                                handleChange(v);
                                            },
                                            options: [
                                                {
                                                    label: "TimeKeeper",
                                                    value: "TimeKeeper"
                                                },
                                                {
                                                    value: "HR",
                                                    label: "HR"
                                                },
                                                {
                                                    value: "PlantCommercial",
                                                    label: "PlantCommercial"
                                                },
                                                {
                                                    value: "HoCommercialAuditor",
                                                    label: "HoCommercialAuditor"
                                                },
                                                {
                                                    value: "Corporate",
                                                    label: "Corporate"
                                                },
                                                {
                                                    value: "Stores",
                                                    label: "Stores"
                                                },
                                                {
                                                    value: "Safety",
                                                    label: "Safety"
                                                }
                                            ],
                                            fullWidth: true,
                                            sx: {
                                                maxWidth: "20rem",
                                                mb: 2
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_8___default()), {})
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    sx: {
                                        p: 2,
                                        pt: 0
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_List__WEBPACK_IMPORTED_MODULE_11___default()), {
                                        component: "nav",
                                        sx: {
                                            width: "100%",
                                            maxWidth: 350,
                                            minWidth: 300,
                                            backgroundColor: theme.palette.background.paper,
                                            borderRadius: "10px",
                                            [theme.breakpoints.down("md")]: {
                                                minWidth: "100%"
                                            },
                                            "& .MuiListItemButton-root": {
                                                mt: 0.5
                                            }
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                sx: {
                                                    borderRadius: `${customization.borderRadius}px`
                                                },
                                                selected: selectedIndex === 0,
                                                onClick: (event)=>handleListItemClick(event, 0, "/profile"),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                            sx: {
                                                                fontSize: "1.3rem",
                                                                stroke: 1.5
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        primary: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                            variant: "body2",
                                                            children: "Account Settings"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                sx: {
                                                    borderRadius: `${customization.borderRadius}px`
                                                },
                                                selected: selectedIndex === 1,
                                                onClick: (event)=>handleListItemClick(event, 1, "/user/social-profile/posts"),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                            sx: {
                                                                fontSize: "1.3rem"
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        primary: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                            container: true,
                                                            spacing: 1,
                                                            justifyContent: "space-between",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                                item: true,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                                    variant: "body2",
                                                                    children: "Social Profile"
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                sx: {
                                                    borderRadius: `${customization.borderRadius}px`
                                                },
                                                selected: selectedIndex === 4,
                                                onClick: ()=>(0,next_auth_react__WEBPACK_IMPORTED_MODULE_26__.signOut)({
                                                        callbackUrl: "/login"
                                                    }),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_20___default()), {
                                                            sx: {
                                                                fontSize: "1.3rem",
                                                                stroke: 1.5
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        primary: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                            variant: "body2",
                                                            children: "Logout"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProfileSection);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6862:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header_SearchSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/Avatar"
var Avatar_ = __webpack_require__(2120);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar_);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
;// CONCATENATED MODULE: external "@mui/material/ButtonBase"
const ButtonBase_namespaceObject = require("@mui/material/ButtonBase");
var ButtonBase_default = /*#__PURE__*/__webpack_require__.n(ButtonBase_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/InputAdornment"
var InputAdornment_ = __webpack_require__(3103);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment_);
// EXTERNAL MODULE: external "@mui/material/OutlinedInput"
var OutlinedInput_ = __webpack_require__(7730);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(8017);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
;// CONCATENATED MODULE: external "@mui/icons-material/Tune"
const Tune_namespaceObject = require("@mui/icons-material/Tune");
var Tune_default = /*#__PURE__*/__webpack_require__.n(Tune_namespaceObject);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/SearchSection/index.tsx


// material-ui









const OutlineInputStyle = (0,material_.styled)((OutlinedInput_default()), {})(({ theme  })=>({
        width: 434,
        marginLeft: 16,
        paddingLeft: 16,
        paddingRight: 16,
        "& input": {
            background: "transparent !important",
            paddingLeft: "4px !important"
        },
        [theme.breakpoints.down("lg")]: {
            width: 250
        },
        [theme.breakpoints.down("md")]: {
            width: "100%",
            marginLeft: 4,
            background: "#fff"
        }
    }));
const HeaderAvatarStyle = (0,material_.styled)((Avatar_default()), {})(({ theme  })=>({
        ...theme.typography.commonAvatar,
        ...theme.typography.mediumAvatar,
        background: theme.palette.secondary.light,
        color: theme.palette.secondary.dark,
        "&:hover": {
            background: theme.palette.secondary.dark,
            color: theme.palette.secondary.light
        }
    }));
// ==============================|| SEARCH INPUT - MOBILE||============================== //
const MobileSearch = ({ value , setValue , popupState  })=>{
    const theme = useTheme();
    return /*#__PURE__*/ _jsx(OutlineInputStyle, {
        id: "input-search-header",
        value: value,
        onChange: (e)=>setValue(e.target.value),
        placeholder: "Search",
        startAdornment: /*#__PURE__*/ _jsx(InputAdornment, {
            position: "start",
            children: /*#__PURE__*/ _jsx(Search, {
                sx: {
                    fontSize: "1rem",
                    color: theme.palette.grey[500],
                    stroke: 1.5
                }
            })
        }),
        endAdornment: /*#__PURE__*/ _jsxs(InputAdornment, {
            position: "end",
            children: [
                /*#__PURE__*/ _jsx(ButtonBase, {
                    sx: {
                        borderRadius: "12px"
                    },
                    children: /*#__PURE__*/ _jsx(HeaderAvatarStyle, {
                        variant: "rounded",
                        children: /*#__PURE__*/ _jsx(Tune, {
                            sx: {
                                fontSize: "1.3rem"
                            }
                        })
                    })
                }),
                /*#__PURE__*/ _jsx(Box, {
                    sx: {
                        ml: 2
                    },
                    children: /*#__PURE__*/ _jsx(ButtonBase, {
                        sx: {
                            borderRadius: "12px"
                        },
                        children: /*#__PURE__*/ _jsx(Avatar, {
                            variant: "rounded",
                            sx: {
                                ...theme.typography.commonAvatar,
                                ...theme.typography.mediumAvatar,
                                background: theme.palette.orange.light,
                                color: theme.palette.orange.dark,
                                "&:hover": {
                                    background: theme.palette.orange.dark,
                                    color: theme.palette.orange.light
                                }
                            },
                            children: /*#__PURE__*/ _jsx(Typography, {
                                fontSize: "1.2rem",
                                fontWeight: "500",
                                children: "X"
                            })
                        })
                    })
                })
            ]
        }),
        "aria-describedby": "search-helper-text",
        inputProps: {
            "aria-label": "weight"
        }
    });
};
// ==============================|| SEARCH INPUT ||============================== //
const SearchSection = ()=>{
    const theme = (0,material_.useTheme)();
    const [value, setValue] = (0,external_react_.useState)("");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                sx: {
                    display: {
                        xs: "block",
                        md: "none"
                    }
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                sx: {
                    display: {
                        xs: "none",
                        md: "block"
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(OutlineInputStyle, {
                    id: "input-search-header",
                    value: value,
                    onChange: (e)=>setValue(e.target.value),
                    placeholder: "Search",
                    startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                        position: "start",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {
                            sx: {
                                fontSize: "1rem",
                                color: theme.palette.grey[500]
                            }
                        })
                    }),
                    endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                        position: "end",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((ButtonBase_default()), {
                            sx: {
                                borderRadius: "12px"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(HeaderAvatarStyle, {
                                variant: "rounded",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Tune_default()), {
                                    sx: {
                                        fontSize: "1.3rem"
                                    }
                                })
                            })
                        })
                    }),
                    "aria-describedby": "search-helper-text",
                    inputProps: {
                        "aria-label": "weight"
                    }
                })
            })
        ]
    });
};
/* harmony default export */ const Header_SearchSection = (SearchSection);


/***/ }),

/***/ 8840:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2120);
/* harmony import */ var _mui_material_Avatar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Avatar__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _LogoSection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6137);
/* harmony import */ var _SearchSection__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6862);
/* harmony import */ var _ProfileSection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(244);
/* harmony import */ var _NotificationSection__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6138);
/* harmony import */ var _mui_icons_material_MenuBook__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4789);
/* harmony import */ var _mui_icons_material_MenuBook__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MenuBook__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ProfileSection__WEBPACK_IMPORTED_MODULE_6__]);
_ProfileSection__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










// ==============================|| MAIN NAVBAR / HEADER ||============================== //
const Header = ({ handleLeftDrawerToggle  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                sx: {
                    width: 228,
                    display: "flex",
                    [theme.breakpoints.down("md")]: {
                        width: "auto"
                    }
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                        component: "span",
                        sx: {
                            display: {
                                xs: "none",
                                md: "block"
                            },
                            flexGrow: 1
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LogoSection__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                        sx: {
                            borderRadius: "12px",
                            p: 0
                        },
                        onClick: handleLeftDrawerToggle,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Avatar__WEBPACK_IMPORTED_MODULE_2___default()), {
                            variant: "rounded",
                            sx: {
                                ...theme.typography.commonAvatar,
                                ...theme.typography.mediumAvatar,
                                transition: "all .2s ease-in-out",
                                background: theme.palette.secondary.light,
                                color: theme.palette.secondary.dark,
                                '&[aria-controls="menu-list-grow"],&:hover': {
                                    background: theme.palette.secondary.dark,
                                    color: theme.palette.secondary.light
                                }
                            },
                            // aria-haspopup="true"
                            onClick: handleLeftDrawerToggle,
                            color: "inherit",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_MenuBook__WEBPACK_IMPORTED_MODULE_8___default()), {
                                sx: {
                                    fontSize: "1.3rem",
                                    stroke: 1.5
                                }
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchSection__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                sx: {
                    flexGrow: 1
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                sx: {
                    flexGrow: 1
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NotificationSection__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProfileSection__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6137:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


// ==============================|| MAIN LOGO ||============================== //
const LogoSection = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            display: "flex",
            alignItems: "center"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                style: {
                    width: "6rem"
                },
                src: "/logo.jpg",
                alt: "logo"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "h6",
                color: "#5e35b1",
                ml: 0,
                children: "Attendance Management"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogoSection);


/***/ }),

/***/ 1450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ MainLayout_Sidebar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "@mui/material/Avatar"
var Avatar_ = __webpack_require__(2120);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar_);
// EXTERNAL MODULE: external "@mui/material/Chip"
var Chip_ = __webpack_require__(8369);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip_);
// EXTERNAL MODULE: external "@mui/material/ListItemButton"
var ListItemButton_ = __webpack_require__(1011);
var ListItemButton_default = /*#__PURE__*/__webpack_require__.n(ListItemButton_);
// EXTERNAL MODULE: external "@mui/material/ListItemIcon"
var ListItemIcon_ = __webpack_require__(3787);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon_);
// EXTERNAL MODULE: external "@mui/material/ListItemText"
var ListItemText_ = __webpack_require__(8315);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "@mui/material/useMediaQuery"
var useMediaQuery_ = __webpack_require__(9868);
var useMediaQuery_default = /*#__PURE__*/__webpack_require__.n(useMediaQuery_);
;// CONCATENATED MODULE: external "@mui/icons-material/FiberManualRecord"
const FiberManualRecord_namespaceObject = require("@mui/icons-material/FiberManualRecord");
var FiberManualRecord_default = /*#__PURE__*/__webpack_require__.n(FiberManualRecord_namespaceObject);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/NavItem/index.tsx


// material-ui








// assets


// ==============================|| SIDEBAR MENU LIST ITEMS ||============================== //
const NavItem = ({ item , level  })=>{
    const theme = (0,styles_.useTheme)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const customization = (0,external_react_redux_.useSelector)((state)=>state.customization);
    const matchesSM = useMediaQuery_default()(theme.breakpoints.down("lg"));
    const router = (0,router_.useRouter)();
    let isSelelected = router.pathname.includes(item.id);
    if (level > 0) {
        isSelelected = router.pathname === item.id;
    }
    if (item.url === "/") {
        isSelelected = router.pathname === item.url;
    }
    const Icon = item.icon;
    const itemIcon = item?.icon ? /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
        stroke: 1.5,
        size: "1.3rem"
    }) : /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
        sx: {
            width: isSelelected ? 8 : 6,
            height: isSelelected ? 8 : 6
        },
        fontSize: level > 0 ? "inherit" : "medium"
    });
    let itemTarget = "_self";
    if (item.target) {
        itemTarget = "_blank";
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItemButton_default()), {
        disabled: item.disabled,
        sx: {
            borderRadius: `${customization.borderRadius}px`,
            mb: 0.5,
            alignItems: "flex-start",
            backgroundColor: level > 1 ? "transparent !important" : "inherit",
            py: level > 1 ? 1 : 1.25,
            pl: `${level * 24}px`
        },
        selected: isSelelected,
        onClick: ()=>router.push(`${item.url}`),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                sx: {
                    my: "auto",
                    minWidth: !item?.icon ? 18 : 36
                },
                children: itemIcon
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: isSelelected ? "h5" : "body1",
                    color: "inherit",
                    children: item.title
                }),
                secondary: item.caption && /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "caption",
                    sx: {
                        ...theme.typography.subMenuCaption
                    },
                    display: "block",
                    gutterBottom: true,
                    children: item.caption
                })
            }),
            item.chip && /*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                color: item.chip.color,
                variant: item.chip.variant,
                size: item.chip.size,
                label: item.chip.label,
                avatar: item.chip.avatar && /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                    children: item.chip.avatar
                })
            })
        ]
    });
};
/* harmony default export */ const MenuList_NavItem = (NavItem);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowUp"
var KeyboardArrowUp_ = __webpack_require__(9881);
var KeyboardArrowUp_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowUp_);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/NavCollapse/index.tsx



// material-ui


// project imports

// assets




// ==============================|| SIDEBAR MENU LIST COLLAPSE ITEMS ||============================== //
const NavCollapse = ({ menu , level  })=>{
    const theme = (0,material_.useTheme)();
    const customization = (0,external_react_redux_.useSelector)((state)=>state.customization);
    const [open, setOpen] = (0,external_react_.useState)(false);
    const [selected, setSelected] = (0,external_react_.useState)(null);
    const handleClick = ()=>{
        setOpen(!open);
        setSelected(!selected ? menu.id : null);
    };
    const { pathname  } = (0,router_.useRouter)();
    const isSelected = pathname.includes(menu.id);
    const checkOpenForParent = (child, id)=>{
        child.forEach((item)=>{
            if (isSelected) {
                setOpen(true);
                setSelected(id);
            }
        });
    };
    (0,external_react_.useEffect)(()=>{
        if (isSelected) {
            setOpen(true);
        }
    }, [
        pathname,
        isSelected
    ]);
    // menu collapse & item
    const menus = menu.children?.map((item)=>{
        switch(item.type){
            case "collapse":
                return /*#__PURE__*/ jsx_runtime_.jsx(NavCollapse, {
                    menu: item,
                    level: level + 1
                }, item.id);
            case "item":
                return /*#__PURE__*/ jsx_runtime_.jsx(MenuList_NavItem, {
                    item: item,
                    level: level + 1
                }, item.id);
            default:
                return /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    variant: "h6",
                    color: "error",
                    align: "center",
                    children: "Menu Items Error"
                }, item.id);
        }
    });
    const Icon = menu.icon;
    const menuIcon = menu.icon ? /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
        strokeWidth: 1.5,
        size: "1.3rem",
        style: {
            marginTop: "auto",
            marginBottom: "auto"
        }
    }) : /*#__PURE__*/ jsx_runtime_.jsx((FiberManualRecord_default()), {
        sx: {
            width: isSelected ? 8 : 6,
            height: isSelected ? 8 : 6
        },
        fontSize: level > 0 ? "inherit" : "medium"
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                sx: {
                    borderRadius: `${customization.borderRadius}px`,
                    mb: 0.5,
                    alignItems: "flex-start",
                    backgroundColor: level > 1 ? "transparent !important" : "inherit",
                    py: level > 1 ? 1 : 1.25,
                    pl: `${level * 24}px`
                },
                selected: isSelected,
                onClick: handleClick,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemIcon, {
                        sx: {
                            my: "auto",
                            minWidth: !menu.icon ? 18 : 36
                        },
                        children: menuIcon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                        primary: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            variant: isSelected ? "h5" : "body1",
                            color: "inherit",
                            sx: {
                                my: "auto"
                            },
                            children: menu.title
                        }),
                        secondary: menu.caption && /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            variant: "caption",
                            sx: {
                                ...theme.typography.subMenuCaption
                            },
                            display: "block",
                            gutterBottom: true,
                            children: menu.caption
                        })
                    }),
                    open ? /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowUp_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((KeyboardArrowDown_default()), {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Collapse, {
                in: open,
                timeout: "auto",
                unmountOnExit: true,
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.List, {
                    component: "div",
                    disablePadding: true,
                    sx: {
                        position: "relative",
                        "&:after": {
                            content: "''",
                            position: "absolute",
                            left: "32px",
                            top: 0,
                            height: "100%",
                            width: "1px",
                            opacity: 1,
                            background: theme.palette.primary.light
                        }
                    },
                    children: menus
                })
            })
        ]
    });
};
/* harmony default export */ const MenuList_NavCollapse = (NavCollapse);

;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/NavGroup/index.tsx



// project imports


// ==============================|| SIDEBAR MENU LIST GROUP ||============================== //
const NavGroup = ({ item  })=>{
    const theme = (0,material_.useTheme)();
    // menu list collapse & items
    const items = item.children?.map((menu)=>{
        switch(menu.type){
            case "collapse":
                return /*#__PURE__*/ jsx_runtime_.jsx(MenuList_NavCollapse, {
                    menu: menu,
                    level: 1
                }, menu.id);
            case "item":
                return /*#__PURE__*/ jsx_runtime_.jsx(MenuList_NavItem, {
                    item: menu,
                    level: 1
                }, menu.id);
            default:
                return /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    variant: "h6",
                    color: "error",
                    align: "center",
                    children: "Menu Items Error"
                }, menu.id);
        }
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.List, {
                subheader: item.title && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                    variant: "caption",
                    sx: {
                        ...theme.typography.menuCaption
                    },
                    display: "block",
                    gutterBottom: true,
                    children: [
                        item.title,
                        item.caption && /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            variant: "caption",
                            sx: {
                                ...theme.typography.subMenuCaption
                            },
                            display: "block",
                            gutterBottom: true,
                            children: item.caption
                        })
                    ]
                }),
                children: items
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {
                sx: {
                    mt: 0.25,
                    mb: 1.25
                }
            })
        ]
    });
};
/* harmony default export */ const MenuList_NavGroup = (NavGroup);

;// CONCATENATED MODULE: external "@mui/icons-material/Dashboard"
const Dashboard_namespaceObject = require("@mui/icons-material/Dashboard");
var Dashboard_default = /*#__PURE__*/__webpack_require__.n(Dashboard_namespaceObject);
;// CONCATENATED MODULE: ./src/components/menu-items/dashboard.ts
// assets

// constant
const icons = {
    Dashboard: (Dashboard_default())
};
// ==============================|| DASHBOARD MENU ITEMS ||============================== //
const dashboard = {
    id: "dashboard",
    title: "Dashboard",
    type: "group",
    children: [
        {
            id: "default",
            title: "Dashboard",
            type: "item",
            url: "/",
            icon: icons.Dashboard,
            breadcrumbs: false
        }
    ]
};
/* harmony default export */ const menu_items_dashboard = (dashboard);

;// CONCATENATED MODULE: external "@mui/icons-material/AssignmentInd"
const AssignmentInd_namespaceObject = require("@mui/icons-material/AssignmentInd");
var AssignmentInd_default = /*#__PURE__*/__webpack_require__.n(AssignmentInd_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Person"
const Person_namespaceObject = require("@mui/icons-material/Person");
var Person_default = /*#__PURE__*/__webpack_require__.n(Person_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/TripOrigin"
const TripOrigin_namespaceObject = require("@mui/icons-material/TripOrigin");
var TripOrigin_default = /*#__PURE__*/__webpack_require__.n(TripOrigin_namespaceObject);
;// CONCATENATED MODULE: ./src/components/menu-items/hr.ts




// constant
const hr_icons = {
    AssignmentInd: (AssignmentInd_default()),
    Person: (Person_default()),
    TripOriginIcon: (TripOrigin_default()),
    Dashboard: (Dashboard_default())
};
// ==============================|| EXTRA PAGES MENU ITEMS ||============================== //
const hr = {
    id: "pages",
    title: "Functional Roles",
    type: "group",
    children: [
        {
            id: "contractors",
            title: "Contractors",
            type: "collapse",
            icon: hr_icons.AssignmentInd,
            children: [
                {
                    id: "/contractors",
                    title: "Contractors List",
                    type: "item",
                    url: "/contractors",
                    target: true
                },
                {
                    id: "/contractors/[id]",
                    title: "Add Contractor",
                    type: "item",
                    url: "/contractors/add",
                    target: true
                }
            ]
        },
        {
            id: "employees",
            title: "Employees",
            type: "collapse",
            icon: hr_icons.Person,
            children: [
                {
                    id: "/employees",
                    title: "Employees List",
                    type: "item",
                    url: "/employees",
                    target: true
                },
                {
                    id: "/employees/[id]",
                    title: "Add Employee",
                    type: "item",
                    url: "/employees/add",
                    target: true
                }
            ]
        },
        {
            id: "/department",
            title: "Departments",
            type: "item",
            url: "/department",
            icon: hr_icons.TripOriginIcon,
            breadcrumbs: false
        },
        {
            id: "/designations",
            title: "Designations",
            type: "item",
            url: "/designations",
            icon: hr_icons.Dashboard,
            breadcrumbs: false
        }
    ]
};
/* harmony default export */ const menu_items_hr = (hr);

;// CONCATENATED MODULE: external "@mui/icons-material/Construction"
const Construction_namespaceObject = require("@mui/icons-material/Construction");
var Construction_default = /*#__PURE__*/__webpack_require__.n(Construction_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Assignment"
const Assignment_namespaceObject = require("@mui/icons-material/Assignment");
var Assignment_default = /*#__PURE__*/__webpack_require__.n(Assignment_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Storefront"
const Storefront_namespaceObject = require("@mui/icons-material/Storefront");
var Storefront_default = /*#__PURE__*/__webpack_require__.n(Storefront_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Description"
const Description_namespaceObject = require("@mui/icons-material/Description");
var Description_default = /*#__PURE__*/__webpack_require__.n(Description_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/MonetizationOn"
const MonetizationOn_namespaceObject = require("@mui/icons-material/MonetizationOn");
var MonetizationOn_default = /*#__PURE__*/__webpack_require__.n(MonetizationOn_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Summarize"
const Summarize_namespaceObject = require("@mui/icons-material/Summarize");
var Summarize_default = /*#__PURE__*/__webpack_require__.n(Summarize_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Inventory"
const Inventory_namespaceObject = require("@mui/icons-material/Inventory");
var Inventory_default = /*#__PURE__*/__webpack_require__.n(Inventory_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Support"
const Support_namespaceObject = require("@mui/icons-material/Support");
var Support_default = /*#__PURE__*/__webpack_require__.n(Support_namespaceObject);
;// CONCATENATED MODULE: ./src/components/menu-items/corporate.ts
// assets
// import {  Construction,  AssignmentInd, Person, Assignment, Storefront, Description, MonetizationOn, Summarize, Inventory, Support } from '@mui/icons-material';










// constant
const corporate_icons = {
    Construction: (Construction_default()),
    AssignmentInd: (AssignmentInd_default()),
    Person: (Person_default()),
    Assignment: (Assignment_default()),
    Storefront: (Storefront_default()),
    Description: (Description_default()),
    MonetizationOn: (MonetizationOn_default()),
    Summarize: (Summarize_default()),
    Support: (Support_default()),
    Inventory: (Inventory_default())
};
// ==============================|| EXTRA PAGES MENU ITEMS ||============================== //
const corporator = {
    id: "pages",
    title: "Functional Roles",
    type: "group",
    children: [
        {
            id: "contractors",
            title: "Contractors",
            type: "collapse",
            icon: corporate_icons.AssignmentInd,
            children: [
                {
                    id: "/contractors",
                    title: "Contractors List",
                    type: "item",
                    url: "/contractors",
                    target: true
                },
                {
                    id: "/contractors/[id]",
                    title: "Add Contractor",
                    type: "item",
                    url: "/contractors/add",
                    target: true
                }
            ]
        },
        {
            id: "employees",
            title: "Employees",
            type: "collapse",
            icon: corporate_icons.Person,
            children: [
                {
                    id: "/employees",
                    title: "Employees List",
                    type: "item",
                    url: "/employees",
                    target: true
                },
                {
                    id: "/employees/[id]",
                    title: "Add Employee",
                    type: "item",
                    url: "/employees/add",
                    target: true
                }
            ]
        },
        {
            id: "workorder",
            title: "Work Order",
            type: "collapse",
            icon: corporate_icons.Assignment,
            children: [
                {
                    id: "/workorder",
                    title: "Work Order List",
                    type: "item",
                    url: "/workorder",
                    target: true
                },
                {
                    id: "/wordorder/[id]",
                    title: "Add Work Order",
                    type: "item",
                    url: "/workorder/add",
                    target: true
                }
            ]
        },
        {
            id: "/store",
            title: "Stores",
            type: "item",
            url: "/store",
            icon: corporate_icons.Inventory,
            breakcrumbs: false
        },
        {
            id: "/safety",
            title: "Safety",
            type: "item",
            url: "/safety",
            icon: corporate_icons.Support,
            breadcrumbs: false
        },
        {
            id: "/hoauditor",
            title: "HO Commercial",
            type: "item",
            url: "/hoauditor",
            icon: corporate_icons.Storefront,
            breadcrumbs: false
        },
        {
            id: "/finalsheet",
            title: "Final Sheet",
            type: "item",
            url: "/finalsheet",
            icon: corporate_icons.Description,
            breadcrumbs: false
        },
        {
            id: "/payouttracker",
            title: "Payout Tracker",
            type: "item",
            url: "/payouttracker",
            icon: corporate_icons.MonetizationOn,
            breadcrumbs: false
        },
        {
            id: "/report",
            title: "Report",
            type: "item",
            url: "/report",
            icon: corporate_icons.Summarize,
            breadcrumbs: false
        }
    ]
};
/* harmony default export */ const corporate = (corporator); // // assets
 // import { TextDecrease } from '@mui/icons-material';
 // // constant
 // const icons = {
 //     TextDecrease
 // };
 // // ==============================|| UTILITIES MENU ITEMS ||============================== //
 // const utilities = {
 //     id: 'utilities',
 //     title: 'Utilities',
 //     type: 'group',
 //     children: [
 //         {
 //             id: 'util-typography',
 //             title: 'Typography',
 //             type: 'item',
 //             url: '/utils/util-typography',
 //             icon: icons.TextDecrease,
 //             breadcrumbs: false
 //         },
 //         {
 //             id: 'util-color',
 //             title: 'Color',
 //             type: 'item',
 //             url: '/utils/util-color',
 //             icon: icons.TextDecrease,
 //             breadcrumbs: false
 //         },
 //         {
 //             id: 'util-shadow',
 //             title: 'Shadow',
 //             type: 'item',
 //             url: '/utils/util-shadow',
 //             icon: icons.TextDecrease,
 //             breadcrumbs: false
 //         },
 //         {
 //             id: 'icons',
 //             title: 'Icons',
 //             type: 'collapse',
 //             icon: icons.TextDecrease,
 //             children: [
 //                 {
 //                     id: 'tabler-icons',
 //                     title: 'Tabler Icons',
 //                     type: 'item',
 //                     url: '/icons/tabler-icons',
 //                     breadcrumbs: false
 //                 },
 //                 {
 //                     id: 'material-icons',
 //                     title: 'Material Icons',
 //                     type: 'item',
 //                     url: '/icons/material-icons',
 //                     breadcrumbs: false
 //                 }
 //             ]
 //         }
 //     ]
 // };
 // export default utilities;

;// CONCATENATED MODULE: ./src/components/menu-items/admin.ts

const admin_icons = {
    Dashboard: (Dashboard_default())
};
const admin = {
    id: "/admin",
    title: "Dashboard",
    type: "group",
    children: [
        {
            id: "/admin",
            title: "Users",
            type: "item",
            url: "/admin",
            icon: admin_icons.Dashboard,
            breadcrumbs: false
        },
        {
            id: "/department",
            title: "Departments",
            type: "item",
            url: "/department",
            icon: admin_icons.Dashboard,
            breadcrumbs: false
        },
        {
            id: "/designations",
            title: "Designations",
            type: "item",
            url: "/designations",
            icon: admin_icons.Dashboard,
            breadcrumbs: false
        }
    ]
};
/* harmony default export */ const menu_items_admin = (admin);

;// CONCATENATED MODULE: ./src/components/menu-items/ho.ts





// constant
const ho_icons = {
    AssignmentInd: (AssignmentInd_default()),
    Person: (Person_default()),
    Storefront: (Storefront_default()),
    Inventory: (Inventory_default()),
    SupportIcon: (Support_default())
};
// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //
const ho = {
    id: "pages",
    title: "Functional Roles",
    type: "group",
    children: [
        {
            id: "contractors",
            title: "Contractors",
            type: "collapse",
            icon: ho_icons.AssignmentInd,
            children: [
                {
                    id: "/contractors",
                    title: "Contractors List",
                    type: "item",
                    url: "/contractors",
                    target: true
                },
                {
                    id: "/contractors/[id]",
                    title: "Add Contractor",
                    type: "item",
                    url: "/contractors/add",
                    target: true
                }
            ]
        },
        {
            id: "employees",
            title: "Employees",
            type: "collapse",
            icon: ho_icons.Person,
            children: [
                {
                    id: "/employees",
                    title: "Employees List",
                    type: "item",
                    url: "/employees",
                    target: true
                },
                {
                    id: "/employees/[id]",
                    title: "Add Employee",
                    type: "item",
                    url: "/employees/add",
                    target: true
                }
            ]
        },
        {
            id: "/store",
            title: "Stores",
            type: "item",
            url: "/store",
            icon: ho_icons.Inventory,
            breakcrumbs: false
        },
        {
            id: "/safety",
            title: "Safety",
            type: "item",
            url: "/safety",
            icon: ho_icons.SupportIcon,
            breadcrumbs: false
        },
        {
            id: "/hoauditor",
            title: "HO Commercial",
            type: "item",
            url: "/hoauditor",
            icon: ho_icons.Storefront,
            breadcrumbs: false
        }
    ]
};
/* harmony default export */ const menu_items_ho = (ho);

;// CONCATENATED MODULE: ./src/components/menu-items/plantcommercial.ts





// constant
const plantcommercial_icons = {
    AssignmentInd: (AssignmentInd_default()),
    Person: (Person_default()),
    Storefront: (Storefront_default()),
    Inventory: (Inventory_default()),
    Support: (Support_default())
};
// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //
const plantCommercial = {
    id: "pages",
    title: "Functional Roles",
    type: "group",
    children: [
        {
            id: "contractors",
            title: "Contractors",
            type: "collapse",
            icon: plantcommercial_icons.AssignmentInd,
            children: [
                {
                    id: "/contractors",
                    title: "Contractors List",
                    type: "item",
                    url: "/contractors",
                    target: true
                },
                {
                    id: "/contractors/[id]",
                    title: "Add Contractor",
                    type: "item",
                    url: "/contractors/add",
                    target: true
                }
            ]
        },
        {
            id: "employees",
            title: "Employees",
            type: "collapse",
            icon: plantcommercial_icons.Person,
            children: [
                {
                    id: "/employees",
                    title: "Employees List",
                    type: "item",
                    url: "/employees",
                    target: true
                },
                {
                    id: "/employees/[id]",
                    title: "Add Employee",
                    type: "item",
                    url: "/employees/add",
                    target: true
                }
            ]
        },
        {
            id: "/store",
            title: "Stores",
            type: "item",
            url: "/store",
            icon: plantcommercial_icons.Inventory,
            breakcrumbs: false
        },
        {
            id: "/safety",
            title: "Safety",
            type: "item",
            url: "/safety",
            icon: plantcommercial_icons.Support,
            breadcrumbs: false
        }
    ]
};
/* harmony default export */ const plantcommercial = (plantCommercial);

;// CONCATENATED MODULE: ./src/components/menu-items/store.ts

// constant
const store_icons = {
    Inventory: (Inventory_default())
};
// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //
const store = {
    id: "pages",
    title: "Dashboard",
    type: "group",
    children: [
        {
            id: "store",
            title: "Stores",
            type: "collapse",
            icon: store_icons.Inventory,
            children: [
                {
                    id: "/store",
                    title: "Stores",
                    type: "item",
                    url: "/store",
                    target: true
                },
                {
                    id: "/store/[id]",
                    title: "Add Store",
                    type: "item",
                    url: "/store/add",
                    target: true
                }
            ]
        }
    ]
};
/* harmony default export */ const menu_items_store = (store);

;// CONCATENATED MODULE: ./src/components/menu-items/safety.ts

// constant
const safety_icons = {
    SupportIcon: (Support_default())
};
// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //
const safety = {
    id: "pages",
    title: "Dashboard",
    type: "group",
    children: [
        {
            id: "safety",
            title: "Safety",
            type: "collapse",
            icon: safety_icons.SupportIcon,
            children: [
                {
                    id: "/safety",
                    title: "Safety",
                    type: "item",
                    url: "/safety",
                    target: true
                },
                {
                    id: "/safety/[id]",
                    title: "Add Safety",
                    type: "item",
                    url: "/safety/add",
                    target: true
                }
            ]
        }
    ]
};
/* harmony default export */ const menu_items_safety = (safety);

;// CONCATENATED MODULE: ./src/components/menu-items/index.ts









// ==============================|| MENU ITEMS ||============================== //
const menuItems = {
    items: [
        menu_items_dashboard,
        menu_items_hr,
        corporate
    ]
};
const adminItems = {
    items: [
        menu_items_admin
    ]
};
const timekeeperItems = {
    items: [
        menu_items_dashboard
    ]
};
const plantCommercialItems = {
    items: [
        menu_items_dashboard,
        plantcommercial
    ]
};
const hritems = {
    items: [
        menu_items_dashboard,
        menu_items_hr
    ]
};
const hoitems = {
    items: [
        menu_items_dashboard,
        menu_items_ho
    ]
};
const corporatorItems = {
    items: [
        menu_items_dashboard,
        corporate
    ]
};
const storeitems = {
    items: [
        menu_items_store
    ]
};
const safetyitems = {
    items: [
        menu_items_safety
    ]
};


// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/index.tsx
// material-ui


// project imports




// ==============================|| SIDEBAR MENU LIST ||============================== //
const MenuList = ()=>{
    const [navItems, setNavItems] = (0,external_react_.useState)();
    const { data: session  } = (0,react_.useSession)();
    console.log(session);
    const getNavItems = ()=>{
        let items = [];
        if (session?.user?.role === "Admin") items = adminItems.items;
        else if (session?.user?.role === "TimeKeeper") items = timekeeperItems.items;
        else if (session?.user?.role === "HR") items = hritems.items;
        else if (session?.user?.role === "PlantCommercial") items = plantCommercialItems.items;
        else if (session?.user?.role === "Stores") items = storeitems.items;
        else if (session?.user?.role === "Safety") items = safetyitems.items;
        else if (session?.user?.role === "HoCommercialAuditor") items = hoitems.items;
        else if (session?.user?.role === "Corporate") items = corporatorItems.items;
        else items = timekeeperItems.items;
        const navItems1 = items?.map((item)=>{
            switch(item.type){
                case "group":
                    return /*#__PURE__*/ jsx_runtime_.jsx(MenuList_NavGroup, {
                        item: item
                    }, item.id);
                default:
                    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "h6",
                        color: "error",
                        align: "center",
                        children: "Menu Items Error"
                    }, item.id);
            }
        });
        setNavItems(navItems1);
    };
    (0,external_react_.useEffect)(()=>{
        getNavItems();
    }, [
        session
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: navItems
    });
};
/* harmony default export */ const Sidebar_MenuList = (MenuList);

// EXTERNAL MODULE: ./src/layout/MainLayout/LogoSection/index.tsx
var LogoSection = __webpack_require__(6137);
// EXTERNAL MODULE: ./src/store/constant.ts
var constant = __webpack_require__(196);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/index.tsx



// project imports



// ==============================|| SIDEBAR DRAWER ||============================== //
const Sidebar = ({ drawerOpen , drawerToggle , window  })=>{
    const theme = (0,material_.useTheme)();
    const matchUpMd = (0,material_.useMediaQuery)(theme.breakpoints.up("md"));
    const drawer = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    display: {
                        xs: "block",
                        md: "none"
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        display: "flex",
                        p: 2,
                        mx: "auto"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(LogoSection/* default */.Z, {})
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    display: {
                        xs: "none",
                        sm: "block"
                    },
                    overflow: "auto",
                    scrollBehavior: "smooth",
                    "&::-webkit-scrollbar": {
                        width: 9
                    },
                    "&::-webkit-scrollbar-thumb": {
                        backgroundColor: "#bdbdbd",
                        borderRadius: 2
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        px: 2,
                        mb: 10
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_MenuList, {})
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    display: {
                        xs: "block",
                        sm: "none"
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        px: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_MenuList, {})
                })
            })
        ]
    });
    const container = window !== undefined ? ()=>window.document.body : undefined;
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        component: "nav",
        sx: {
            flexShrink: {
                md: 0
            },
            width: matchUpMd ? constant/* drawerWidth */.RK : "auto"
        },
        "aria-label": "mailbox folders",
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Drawer, {
            container: container,
            variant: matchUpMd ? "persistent" : "temporary",
            anchor: "left",
            open: drawerOpen,
            onClose: drawerToggle,
            sx: {
                "& .MuiDrawer-paper": {
                    width: constant/* drawerWidth */.RK,
                    background: theme.palette.background.default,
                    color: theme.palette.text.primary,
                    borderRight: "none",
                    [theme.breakpoints.up("md")]: {
                        top: "88px"
                    }
                }
            },
            ModalProps: {
                keepMounted: true
            },
            color: "inherit",
            children: drawer
        })
    });
};
/* harmony default export */ const MainLayout_Sidebar = (Sidebar);


/***/ }),

/***/ 7376:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8840);
/* harmony import */ var _Sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1450);
/* harmony import */ var _store_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(196);
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2702);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Header__WEBPACK_IMPORTED_MODULE_3__]);
_Header__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// material-ui


// project imports




// assets

// styles
const Main = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)("main", {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        ...theme.typography.mainContent,
        marginTop: "70px",
        ...!open && {
            borderBottomLeftRadius: 0,
            borderBottomRightRadius: 0,
            overflow: "hidden",
            transition: theme.transitions.create("margin", {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen
            }),
            [theme.breakpoints.up("md")]: {
                marginLeft: -(_store_constant__WEBPACK_IMPORTED_MODULE_6__/* .drawerWidth */ .RK - 20),
                width: `calc(100% - ${_store_constant__WEBPACK_IMPORTED_MODULE_6__/* .drawerWidth */ .RK}px)`
            },
            [theme.breakpoints.down("md")]: {
                marginLeft: "20px",
                width: `calc(100% - ${_store_constant__WEBPACK_IMPORTED_MODULE_6__/* .drawerWidth */ .RK}px)`,
                padding: "16px"
            },
            [theme.breakpoints.down("sm")]: {
                marginLeft: "10px",
                width: `calc(100% - ${_store_constant__WEBPACK_IMPORTED_MODULE_6__/* .drawerWidth */ .RK}px)`,
                padding: "16px",
                marginRight: "10px"
            }
        },
        ...open && {
            transition: theme.transitions.create("margin", {
                easing: theme.transitions.easing.easeOut,
                duration: theme.transitions.duration.enteringScreen
            }),
            marginLeft: 0,
            borderBottomLeftRadius: 0,
            borderBottomRightRadius: 0,
            width: `calc(100% - ${_store_constant__WEBPACK_IMPORTED_MODULE_6__/* .drawerWidth */ .RK}px)`,
            [theme.breakpoints.down("md")]: {
                marginLeft: "20px"
            },
            [theme.breakpoints.down("sm")]: {
                marginLeft: "0px",
                width: "100%",
                marginRight: "0px"
            }
        }
    }));
// ==============================|| MAIN LAYOUT ||============================== //
const MainLayout = ({ children  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const matchDownMd = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)(theme.breakpoints.down("md"));
    // Handle left drawer
    const leftDrawerOpened = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.customization.opened);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const handleLeftDrawerToggle = ()=>{
        dispatch({
            type: _store_actions__WEBPACK_IMPORTED_MODULE_7__/* .SET_MENU */ .O5,
            opened: !leftDrawerOpened
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
            display: "flex",
            overflow: "hidden"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CssBaseline, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.AppBar, {
                enableColorOnDark: true,
                position: "fixed",
                color: "inherit",
                elevation: 0,
                sx: {
                    bgcolor: theme.palette.background.default,
                    transition: leftDrawerOpened ? theme.transitions.create("width") : "none"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Toolbar, {
                    sx: {
                        py: "10px"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        handleLeftDrawerToggle: handleLeftDrawerToggle
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Sidebar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                drawerOpen: !matchDownMd ? leftDrawerOpened : !leftDrawerOpened,
                drawerToggle: handleLeftDrawerToggle
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Main, {
                theme: theme,
                open: leftDrawerOpened,
                children: children
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9212:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _layout_MainLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7376);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9584);
/* harmony import */ var _themes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8312);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _style_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(306);
/* harmony import */ var _style_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_style_css__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_MainLayout__WEBPACK_IMPORTED_MODULE_1__]);
_layout_MainLayout__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












function App({ Component , pageProps: { session , ...pageProps }  }) {
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const l = {
        borderRadius: 12,
        defaultId: "default",
        fontFamily: "'Roboto', sans-serif",
        isOpen: [],
        opened: true
    };
    next_router__WEBPACK_IMPORTED_MODULE_5__.Router.events.on("routeChangeStart", ()=>{
        setLoading(true);
        nprogress__WEBPACK_IMPORTED_MODULE_9___default().start();
    });
    next_router__WEBPACK_IMPORTED_MODULE_5__.Router.events.on("routeChangeComplete", ()=>{
        setLoading(false);
        nprogress__WEBPACK_IMPORTED_MODULE_9___default().done();
    });
    nprogress__WEBPACK_IMPORTED_MODULE_9___default().configure({
        showSpinner: false
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_7__.Provider, {
        store: _store__WEBPACK_IMPORTED_MODULE_2__/* .store */ .h,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_auth_react__WEBPACK_IMPORTED_MODULE_8__.SessionProvider, {
            session: session,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.StyledEngineProvider, {
                injectFirst: true,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ThemeProvider, {
                    theme: (0,_themes__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(l),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.CssBaseline, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_10___default()), {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                                rel: "stylesheet",
                                href: "https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.css",
                                integrity: "sha512-42kB9yDlYiCEfx2xVwq0q7hT4uf26FUgSIZBK8uiaEnTdShXjwr8Ip1V4xGJMg3mHkUt9nNuTDxunHF0/EgxLQ==",
                                crossOrigin: "anonymous",
                                referrerPolicy: "no-referrer"
                            })
                        }),
                        loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                            sx: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                width: "100%",
                                height: "100vh"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.CircularProgress, {
                                sx: {
                                    color: "#673ab7"
                                }
                            })
                        }) : router.pathname === "/login" || router.pathname === "/register" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                            ...pageProps
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_MainLayout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                ...pageProps
                            })
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EB": () => (/* binding */ SET_BORDER_RADIUS),
/* harmony export */   "O5": () => (/* binding */ SET_MENU),
/* harmony export */   "YY": () => (/* binding */ MENU_OPEN),
/* harmony export */   "rG": () => (/* binding */ SET_FONT_FAMILY)
/* harmony export */ });
/* unused harmony export MENU_TOGGLE */
// action - customization reducer
const SET_MENU = "@customization/SET_MENU";
const MENU_TOGGLE = "@customization/MENU_TOGGLE";
const MENU_OPEN = "@customization/MENU_OPEN";
const SET_FONT_FAMILY = "@customization/SET_FONT_FAMILY";
const SET_BORDER_RADIUS = "@customization/SET_BORDER_RADIUS";


/***/ }),

/***/ 196:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RK": () => (/* binding */ drawerWidth)
/* harmony export */ });
/* unused harmony exports gridSpacing, appDrawerWidth */
// theme constant
const gridSpacing = 3;
const drawerWidth = 260;
const appDrawerWidth = 320;


/***/ }),

/***/ 9584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "h": () => (/* binding */ store)
});

// UNUSED EXPORTS: persister

;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
// EXTERNAL MODULE: ./src/store/actions.ts
var actions = __webpack_require__(2702);
;// CONCATENATED MODULE: ./src/store/customizationReducer.ts
const config = {
    basename: "/free",
    defaultPath: "/dashboard/default",
    fontFamily: `'Roboto', sans-serif`,
    borderRadius: 12
};
// action - state management

const initialState = {
    isOpen: [],
    defaultId: "default",
    fontFamily: config.fontFamily,
    borderRadius: config.borderRadius,
    opened: true
};
// ==============================|| CUSTOMIZATION REDUCER ||============================== //
const customizationReducer = (state = initialState, action)=>{
    let id;
    switch(action.type){
        case actions/* MENU_OPEN */.YY:
            id = action.id;
            return {
                ...state,
                isOpen: [
                    id
                ]
            };
        case actions/* SET_MENU */.O5:
            return {
                ...state,
                opened: action.opened
            };
        case actions/* SET_FONT_FAMILY */.rG:
            return {
                ...state,
                fontFamily: action.fontFamily
            };
        case actions/* SET_BORDER_RADIUS */.EB:
            return {
                ...state,
                borderRadius: action.borderRadius
            };
        default:
            return state;
    }
};
/* harmony default export */ const store_customizationReducer = (customizationReducer);

;// CONCATENATED MODULE: ./src/store/reducer.ts

// reducer import

// ==============================|| COMBINE REDUCER ||============================== //
const reducer = (0,external_redux_namespaceObject.combineReducers)({
    customization: store_customizationReducer
});
/* harmony default export */ const store_reducer = (reducer);

;// CONCATENATED MODULE: ./src/store/index.ts


// ==============================|| REDUX - MAIN STORE ||============================== //
const store = (0,external_redux_namespaceObject.createStore)(store_reducer);
const persister = "Free";



/***/ }),

/***/ 8312:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ themes)
});

// UNUSED EXPORTS: theme

// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: ./src/assets/scss/_themes-vars.module.scss
var _themes_vars_module = __webpack_require__(8411);
var _themes_vars_module_default = /*#__PURE__*/__webpack_require__.n(_themes_vars_module);
;// CONCATENATED MODULE: ./src/themes/compStyleOverride.ts
function componentStyleOverrides(theme) {
    const bgColor = theme.colors?.grey50;
    return {
        MuiButton: {
            styleOverrides: {
                root: {
                    fontWeight: 500,
                    borderRadius: "4px"
                }
            }
        },
        MuiPaper: {
            defaultProps: {
                elevation: 0
            },
            styleOverrides: {
                root: {
                    backgroundImage: "none"
                },
                rounded: {
                    borderRadius: `${theme?.customization?.borderRadius}px`
                }
            }
        },
        MuiCardHeader: {
            styleOverrides: {
                root: {
                    color: theme.colors?.textDark,
                    padding: "24px"
                },
                title: {
                    fontSize: "1.125rem"
                }
            }
        },
        MuiCardContent: {
            styleOverrides: {
                root: {
                    padding: "24px"
                }
            }
        },
        MuiCardActions: {
            styleOverrides: {
                root: {
                    padding: "24px"
                }
            }
        },
        MuiListItemButton: {
            styleOverrides: {
                root: {
                    color: theme.darkTextPrimary,
                    paddingTop: "10px",
                    paddingBottom: "10px",
                    "&.Mui-selected": {
                        color: theme.menuSelected,
                        backgroundColor: theme.menuSelectedBack,
                        "&:hover": {
                            backgroundColor: theme.menuSelectedBack
                        },
                        "& .MuiListItemIcon-root": {
                            color: theme.menuSelected
                        }
                    },
                    "&:hover": {
                        backgroundColor: theme.menuSelectedBack,
                        color: theme.menuSelected,
                        "& .MuiListItemIcon-root": {
                            color: theme.menuSelected
                        }
                    }
                }
            }
        },
        MuiListItemIcon: {
            styleOverrides: {
                root: {
                    color: theme.darkTextPrimary,
                    minWidth: "36px"
                }
            }
        },
        MuiListItemText: {
            styleOverrides: {
                primary: {
                    color: theme.textDark
                }
            }
        },
        MuiInputBase: {
            styleOverrides: {
                input: {
                    color: theme.textDark,
                    "&::placeholder": {
                        color: theme.darkTextSecondary,
                        fontSize: "0.875rem"
                    }
                }
            }
        },
        MuiOutlinedInput: {
            styleOverrides: {
                root: {
                    background: bgColor,
                    borderRadius: `${theme?.customization?.borderRadius}px`,
                    "& .MuiOutlinedInput-notchedOutline": {
                        borderColor: theme.colors?.grey400
                    },
                    "&:hover $notchedOutline": {
                        borderColor: theme.colors?.primaryLight
                    },
                    "&.MuiInputBase-multiline": {
                        padding: 1
                    }
                },
                input: {
                    fontWeight: 500,
                    background: bgColor,
                    padding: "15.5px 14px",
                    borderRadius: `${theme?.customization?.borderRadius}px`,
                    "&.MuiInputBase-inputSizeSmall": {
                        padding: "10px 14px",
                        "&.MuiInputBase-inputAdornedStart": {
                            paddingLeft: 0
                        }
                    }
                },
                inputAdornedStart: {
                    paddingLeft: 4
                },
                notchedOutline: {
                    borderRadius: `${theme?.customization?.borderRadius}px`
                }
            }
        },
        MuiSlider: {
            styleOverrides: {
                root: {
                    "&.Mui-disabled": {
                        color: theme.colors?.grey300
                    }
                },
                mark: {
                    backgroundColor: theme.paper,
                    width: "4px"
                },
                valueLabel: {
                    color: theme?.colors?.primaryLight
                }
            }
        },
        MuiDivider: {
            styleOverrides: {
                root: {
                    borderColor: theme.divider,
                    opacity: 1
                }
            }
        },
        MuiAvatar: {
            styleOverrides: {
                root: {
                    color: theme.colors?.primaryDark,
                    background: theme.colors?.primary200
                }
            }
        },
        MuiChip: {
            styleOverrides: {
                root: {
                    "&.MuiChip-deletable .MuiChip-deleteIcon": {
                        color: "inherit"
                    }
                }
            }
        },
        MuiTooltip: {
            styleOverrides: {
                tooltip: {
                    color: theme.paper,
                    background: theme.colors?.grey700
                }
            }
        }
    };
}

;// CONCATENATED MODULE: ./src/themes/palette.ts
/**
 * Color intention that you want to used in your theme
 * @param {JsonObject} theme Theme customization object
 */ function themePalette(theme) {
    return {
        mode: theme?.customization?.navType,
        common: {
            black: theme.colors?.darkPaper
        },
        primary: {
            light: theme.colors?.primaryLight,
            main: theme.colors?.primaryMain,
            dark: theme.colors?.primaryDark,
            200: theme.colors?.primary200,
            800: theme.colors?.primary800
        },
        secondary: {
            light: theme.colors?.secondaryLight,
            main: theme.colors?.secondaryMain,
            dark: theme.colors?.secondaryDark,
            200: theme.colors?.secondary200,
            800: theme.colors?.secondary800
        },
        error: {
            light: theme.colors?.errorLight,
            main: theme.colors?.errorMain,
            dark: theme.colors?.errorDark
        },
        orange: {
            light: theme.colors?.orangeLight,
            main: theme.colors?.orangeMain,
            dark: theme.colors?.orangeDark
        },
        warning: {
            light: theme.colors?.warningLight,
            main: theme.colors?.warningMain,
            dark: theme.colors?.warningDark
        },
        success: {
            light: theme.colors?.successLight,
            200: theme.colors?.success200,
            main: theme.colors?.successMain,
            dark: theme.colors?.successDark
        },
        grey: {
            50: theme.colors?.grey50,
            100: theme.colors?.grey100,
            500: theme.darkTextSecondary,
            600: theme.heading,
            700: theme.darkTextPrimary,
            900: theme.textDark
        },
        dark: {
            light: theme.colors?.darkTextPrimary,
            main: theme.colors?.darkLevel1,
            dark: theme.colors?.darkLevel2,
            800: theme.colors?.darkBackground,
            900: theme.colors?.darkPaper
        },
        text: {
            primary: theme.darkTextPrimary,
            secondary: theme.darkTextSecondary,
            dark: theme.textDark,
            hint: theme.colors?.grey100
        },
        background: {
            paper: theme.paper,
            default: theme.backgroundDefault
        }
    };
}

;// CONCATENATED MODULE: ./src/themes/typography.ts
/**
 * Typography used in theme
 * @param {JsonObject} theme theme customization object
 */ function themeTypography(theme) {
    return {
        fontFamily: "Poppins, sans-serif",
        h6: {
            fontWeight: 500,
            color: theme.heading,
            fontSize: "0.75rem"
        },
        h5: {
            fontSize: "0.875rem",
            color: theme.heading,
            fontWeight: 500
        },
        h4: {
            fontSize: "1rem",
            color: theme.heading,
            fontWeight: 600
        },
        h3: {
            fontSize: "1.25rem",
            color: theme.heading,
            fontWeight: 600
        },
        h2: {
            fontSize: "1.5rem",
            color: theme.heading,
            fontWeight: 700
        },
        h1: {
            fontSize: "2.125rem",
            color: theme.heading,
            fontWeight: 700
        },
        subtitle1: {
            fontSize: "0.875rem",
            fontWeight: 500,
            color: theme.textDark
        },
        subtitle2: {
            fontSize: "0.75rem",
            fontWeight: 400,
            color: theme.darkTextSecondary
        },
        caption: {
            fontSize: "0.75rem",
            color: theme.darkTextSecondary,
            fontWeight: 400
        },
        body1: {
            fontSize: "0.875rem",
            fontWeight: 400,
            lineHeight: "1.334em"
        },
        body2: {
            letterSpacing: "0em",
            fontWeight: 400,
            lineHeight: "1.5em",
            color: theme.darkTextPrimary
        },
        button: {
        },
        customInput: {
            marginTop: 1,
            marginBottom: 1,
            "& > label": {
                top: 23,
                left: 0,
                color: theme.grey500,
                '&[data-shrink="false"]': {
                    top: 5
                }
            },
            "& > div > input": {
                padding: "30.5px 14px 11.5px !important"
            },
            "& legend": {
                display: "none"
            },
            "& fieldset": {
                top: 0
            }
        },
        mainContent: {
            backgroundColor: theme.background,
            width: "100%",
            minHeight: "calc(100vh - 88px)",
            flexGrow: 1,
            padding: "20px",
            marginTop: "88px",
            marginRight: "20px",
            borderRadius: `${theme?.customization?.borderRadius}px`
        },
        menuCaption: {
            fontSize: "0.875rem",
            fontWeight: 500,
            color: theme.heading,
            padding: "6px",
            // textTransform: 'capitalize',
            marginTop: "10px"
        },
        subMenuCaption: {
            fontSize: "0.6875rem",
            fontWeight: 500,
            color: theme.darkTextSecondary
        },
        commonAvatar: {
            cursor: "pointer",
            borderRadius: "8px"
        },
        smallAvatar: {
            width: "22px",
            height: "22px",
            fontSize: "1rem"
        },
        mediumAvatar: {
            width: "34px",
            height: "34px",
            fontSize: "1.2rem"
        },
        largeAvatar: {
            width: "44px",
            height: "44px",
            fontSize: "1.5rem"
        }
    };
}

;// CONCATENATED MODULE: ./src/themes/index.ts

// assets
// import colors from '@/assets/scss/_themes-vars.module.scss';

// project imports



/**
 * Represent theme style and structure as per Material-UI
 * @param {JsonObject} customization customization parameter object
 */ const theme = (customization)=>{
    const color = (_themes_vars_module_default());
    const themeOption = {
        colors: color,
        heading: color.grey900,
        paper: color.paper,
        backgroundDefault: color.paper,
        background: color.primaryLight,
        darkTextPrimary: color.grey700,
        darkTextSecondary: color.grey500,
        textDark: color.grey900,
        menuSelected: color.secondaryDark,
        menuSelectedBack: color.secondaryLight,
        divider: color.grey200,
        customization
    };
    const themeOptions = {
        direction: "ltr",
        palette: themePalette(themeOption),
        mixins: {
            toolbar: {
                minHeight: "48px",
                padding: "16px",
                "@media (min-width: 600px)": {
                    minHeight: "48px"
                }
            }
        },
        typography: themeTypography(themeOption)
    };
    const themes = (0,styles_.createTheme)(themeOptions);
    themes.components = componentStyleOverrides(themeOption);
    return themes;
};
/* harmony default export */ const themes = (theme);


/***/ }),

/***/ 306:
/***/ (() => {



/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 9881:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 9801:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 4789:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/MenuBook");

/***/ }),

/***/ 8017:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 32:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 7608:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/VerifiedUser");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 2120:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Avatar");

/***/ }),

/***/ 19:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ 8369:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Chip");

/***/ }),

/***/ 5371:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ClickAwayListener");

/***/ }),

/***/ 3646:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 5612:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 3103:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 4192:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/List");

/***/ }),

/***/ 1011:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemButton");

/***/ }),

/***/ 3787:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 7730:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/OutlinedInput");

/***/ }),

/***/ 1598:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 5768:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Popover");

/***/ }),

/***/ 8742:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 9868:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 808:
/***/ ((module) => {

"use strict";
module.exports = require("nprogress");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [681,1825], () => (__webpack_exec__(9212)));
module.exports = __webpack_exports__;

})();