"use strict";
(() => {
var exports = {};
exports.id = 6585;
exports.ids = [6585];
exports.modules = {

/***/ 3571:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ EditTimkeeper),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9876);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9648);
/* harmony import */ var _components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6850);
/* harmony import */ var _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3522);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6395);
/* harmony import */ var _components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9711);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_7__, _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_9__]);
([axios__WEBPACK_IMPORTED_MODULE_7__, _components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const validationSchema = yup__WEBPACK_IMPORTED_MODULE_5__.object().shape({
    contractorId: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    contractorName: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    employeeid: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    designation: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    attendance: yup__WEBPACK_IMPORTED_MODULE_5__.number().min(0).max(1),
    attendancedate: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    machineInTime: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    machineOutTime: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    machineduration: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    machineshift: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    overtime: yup__WEBPACK_IMPORTED_MODULE_5__.number().optional(),
    eleave: yup__WEBPACK_IMPORTED_MODULE_5__.number().optional(),
    manualintime: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    manualouttime: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    manualshift: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    manualovertime: yup__WEBPACK_IMPORTED_MODULE_5__.number().optional(),
    manualduration: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    mleave: yup__WEBPACK_IMPORTED_MODULE_5__.number().required("Required"),
    department: yup__WEBPACK_IMPORTED_MODULE_5__.string().optional(),
    gender: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    comment: yup__WEBPACK_IMPORTED_MODULE_5__.string().required("Required"),
    uploadDocument: yup__WEBPACK_IMPORTED_MODULE_5__.object().optional()
});
function EditTimkeeper({ role , departments  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { id  } = router.query;
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [timekeeper, setTimeKepeer] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_10__.useSession)();
    const fetchTimeKeeper = async ()=>{
        setLoading(true);
        await axios__WEBPACK_IMPORTED_MODULE_7__["default"].get(`/api/timekeeper/${id}`).then((res)=>{
            setTimeKepeer(res.data);
            setLoading(false);
        }).catch((err)=>{
            console.log(err);
            setLoading(false);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        fetchTimeKeeper();
    }, [
        id
    ]);
    const initialValues = {
        contractorId: timekeeper?.contractorid || "",
        contractorName: timekeeper?.contractorname || "John Doe",
        employeeid: timekeeper?.employeeid || "",
        designation: timekeeper?.designation || "",
        machineInTime: timekeeper?.machineInTime || "",
        machineOutTime: timekeeper?.machineOutTime || "",
        machineduration: timekeeper?.machineduration || "",
        machineshift: timekeeper?.machineshift || "Day",
        attendance: timekeeper?.attendance || 0,
        attendancedate: timekeeper?.attendancedate || "",
        overtime: timekeeper?.overtime || 2,
        eleave: timekeeper?.eleave || 0,
        manualintime: timekeeper?.manualintime || "",
        manualouttime: timekeeper?.manualouttime || "",
        manualshift: timekeeper?.manualshift || "",
        manualovertime: timekeeper?.manualovertime || "",
        manualduration: timekeeper?.manualduration || "",
        mleave: timekeeper?.mleave || timekeeper?.eleave || 0,
        department: timekeeper?.department || "",
        gender: timekeeper?.gender || "",
        comment: "",
        uploadDocument: undefined
    };
    return loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: "90vh",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {
            sx: {
                color: "#673ab7"
            }
        })
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper, {
            sx: {
                height: "83.7vh",
                pt: "1rem",
                pb: "8rem",
                overflow: "hidden auto",
                scrollBehavior: "smooth",
                "&::-webkit-scrollbar": {
                    width: 9
                },
                "&::-webkit-scrollbar-thumb": {
                    backgroundColor: "#bdbdbd",
                    borderRadius: 2
                }
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    sx: {
                        height: "3rem",
                        display: "flex",
                        alignItems: "center"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        variant: "h4",
                        ml: 5,
                        my: "auto",
                        children: [
                            "Edit ",
                            id
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_6__.Formik, {
                    initialValues: initialValues,
                    validationSchema: validationSchema,
                    onSubmit: async (values, { setSubmitting , setErrors  })=>{
                        const { comment , uploadDocument , contractorId , contractorName , attendance , mleave , ...others } = values;
                        setSubmitting(true);
                        if (values.attendance === "1" && values.mleave !== "0") {
                            setErrors({
                                mleave: "Manual Leave should be 0 nmmber"
                            });
                            return;
                        }
                        await axios__WEBPACK_IMPORTED_MODULE_7__["default"].put("/api/timekeeper", {
                            id: id,
                            uploadDocument: uploadDocument,
                            comment,
                            userId: session?.user?.id,
                            userName: session?.user?.name,
                            attendance: values.attendance.toString(),
                            mleave: values.mleave.toString(),
                            role: role,
                            ...others
                        }).then((res)=>{
                            router.push("/");
                        }).catch((err)=>{
                            console.log(err);
                        });
                        setSubmitting(false);
                    },
                    children: ({ handleSubmit , values , initialValues , isSubmitting  })=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            noValidate: true,
                            onSubmit: handleSubmit,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                    ml: 6,
                                    mt: 2,
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "contractorId",
                                                label: "Contractor ID",
                                                placeHolder: "Contractor ID",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "contractorName",
                                                label: "Contractor Name",
                                                placeHolder: "Contractor Name",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "employeeid",
                                                label: "Employee ID",
                                                placeHolder: "Employee ID",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "machineInTime",
                                                label: "Machine In Time",
                                                placeHolder: "Machine In Time",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "machineOutTime",
                                                label: "Machine Out Time",
                                                placeHolder: "Machine Out Time",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "machineduration",
                                                label: "Machine Total Duration ",
                                                placeHolder: "Machine Total Duration",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "machineshift",
                                                label: "Machine Shift",
                                                placeHolder: "Machine Shift",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "overtime",
                                                label: "Overtime",
                                                placeHolder: "Overtime",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "eleave",
                                                label: "Leave",
                                                placeHolder: "Leave",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormDate__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                name: "attendancedate",
                                                label: "Attendance Date",
                                                placeHolder: "Attendance Date",
                                                disabled: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "attendance",
                                                label: "Attendance",
                                                placeHolder: "Attendance",
                                                disabled: false,
                                                type: "number"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "designation",
                                                label: "Designation",
                                                placeHolder: "Designation",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "manualintime",
                                                label: "Manual In Time",
                                                placeHolder: "Manual In Time",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "manualouttime",
                                                label: "Manual Out Time",
                                                placeHolder: "Manual Out Time",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "manualduration",
                                                label: "Manual Total Duration",
                                                placeHolder: "Manual Total Duration",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "manualshift",
                                                label: "Manual Shift",
                                                placeHolder: "Manual Shift",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "manualovertime",
                                                label: "Manual Overtime",
                                                placeHolder: "Manual Overtime",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "mleave",
                                                label: "Manual Leave",
                                                placeHolder: "Manual Leave",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                name: "department",
                                                label: "Department",
                                                placeHolder: "Department",
                                                disabled: false,
                                                options: departments.map((d)=>({
                                                        value: d.department,
                                                        label: d.department
                                                    }))
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormSelect__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                name: "gender",
                                                label: "Gender",
                                                placeHolder: "Gender",
                                                disabled: false,
                                                options: [
                                                    {
                                                        value: "Male",
                                                        label: "Male"
                                                    },
                                                    {
                                                        value: "Female",
                                                        label: "Female"
                                                    },
                                                    {
                                                        value: "Other",
                                                        label: "Other"
                                                    }
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FormInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                name: "comment",
                                                label: "Comment",
                                                placeHolder: "Enter the Comment",
                                                disabled: false
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 6,
                                            md: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FormikComponents_FileUpload__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                name: "uploadDocument",
                                                label: "Upload Document",
                                                placeholder: "Upload Document"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    type: "submit",
                                    variant: "contained",
                                    sx: {
                                        float: "right",
                                        mr: 10
                                    },
                                    disabled: isSubmitting,
                                    children: [
                                        "Submit",
                                        isSubmitting && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {
                                            size: 15,
                                            sx: {
                                                ml: 1,
                                                color: "#364152"
                                            }
                                        })
                                    ]
                                })
                            ]
                        });
                    }
                })
            ]
        })
    });
}
const getServerSideProps = async ({ req  })=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_10__.getSession)({
        req
    });
    const departments = await _lib_prisma__WEBPACK_IMPORTED_MODULE_11__/* ["default"].department.findMany */ .Z.department.findMany();
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_11__/* ["default"].user.findUnique */ .Z.user.findUnique({
        where: {
            id: session?.user?.id
        }
    });
    return {
        props: {
            role: user?.role,
            departments
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 3274:
/***/ ((module) => {

module.exports = require("@mui/icons-material/InsertDriveFile");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 8167:
/***/ ((module) => {

module.exports = require("@mui/material/Card");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 8891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 6354:
/***/ ((module) => {

module.exports = require("@mui/material/FormHelperText");

/***/ }),

/***/ 6096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 8742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 298:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/AdapterDayjs");

/***/ }),

/***/ 1856:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/DatePicker");

/***/ }),

/***/ 5753:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/LocalizationProvider");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5684,6850,4503], () => (__webpack_exec__(3571)));
module.exports = __webpack_exports__;

})();