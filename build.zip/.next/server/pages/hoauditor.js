"use strict";
(() => {
var exports = {};
exports.id = 3678;
exports.ids = [3678];
exports.modules = {

/***/ 6395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export prisma */
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();
if (false) {}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (prisma);


/***/ }),

/***/ 6381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Employees),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9181);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8823);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8099);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(443);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7308);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4848);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1431);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8330);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7229);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3103);
/* harmony import */ var _mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7730);
/* harmony import */ var _mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_material___WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(419);
/* harmony import */ var _mui_material___WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_material___WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _mui_icons_material_FilterList__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3866);
/* harmony import */ var _mui_icons_material_FilterList__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FilterList__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6395);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _components_Table_EnhancedTableHead__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(7972);



























const StyledSearch = (0,_mui_material___WEBPACK_IMPORTED_MODULE_18__.styled)((_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_17___default()))(({ theme  })=>({
        width: 300,
        height: 40,
        marginRight: 30,
        "& fieldset": {
            borderWidth: `1px !important`,
            borderColor: `${(0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.alpha)(theme.palette.grey[500], 0.32)} !important`
        }
    }));
function createData(name, calories, fat, carbs, protein) {
    return {
        name,
        calories,
        fat,
        carbs,
        protein
    };
}
function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}
function getComparator(order, orderBy) {
    return order === "desc" ? (a, b)=>descendingComparator(a, b, orderBy) : (a, b)=>-descendingComparator(a, b, orderBy);
}
function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index)=>[
            el,
            index
        ]);
    stabilizedThis.sort((a, b)=>{
        const order = comparator(a[0], b[0]);
        if (order !== 0) {
            return order;
        }
        return a[1] - b[1];
    });
    return stabilizedThis.map((el)=>el[0]);
}
const createHeadCells = (id, label, numeric, included)=>{
    return {
        id: id,
        label: label,
        numeric: numeric,
        included: included
    };
};
const headCells = [
    createHeadCells("contractorname", "Contractor Name", false, false),
    createHeadCells("workdescription", "Work Description", false, true),
    createHeadCells("startdate", "Start Date", false, false),
    createHeadCells("enddate", "End Date", false, false),
    createHeadCells("monthofInvoice", "Month of Invoice", false, false),
    createHeadCells("basicbillamount", "Basic Bill Amount", false, false),
    createHeadCells("serviceCharges", "Services Charge", false, false),
    createHeadCells("netbillAmount", "Net Bill Amount", true, false),
    createHeadCells("bankDetails", "Bank Details", false, false),
    createHeadCells("onetimeInvoice", "One Time Invoice", false, false),
    createHeadCells("verifiedComplainces", "Verified the Complainces", false, false),
    createHeadCells("workOrderAvailable", "Work Order Available", false, false),
    createHeadCells("licensesInPlace", "Licenses In Place", false, false),
    createHeadCells("previousPayVerified", "Previous Month Pay verified", false, false),
    createHeadCells("detailssSentToAuditAndHo", "Details sent to Audit and HO", false, false),
    createHeadCells("gstChallanAttached", "GST Challan Attached", false, false),
    createHeadCells("deductions", "Deductions", false, false),
    createHeadCells("variationsInManPower", "Variations In Manpower", false, false),
    createHeadCells("machineOrRegisterMode", "Machine Or Register Mode", false, false)
];
function EnhancedTableToolbar(props) {
    const { numSelected , filtername , setFilterName  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_10___default()), {
        sx: {
            pl: {
                sm: 2
            },
            pr: {
                xs: 1,
                sm: 1
            },
            display: "flex",
            justifyContent: "space-between",
            ...numSelected > 0 && {
                bgcolor: (theme)=>(0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.alpha)(theme.palette.primary.main, theme.palette.action.activatedOpacity)
            }
        },
        children: [
            numSelected > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default()), {
                sx: {
                    flex: "1 1 100%"
                },
                color: "inherit",
                variant: "subtitle1",
                component: "div",
                children: [
                    numSelected,
                    " selected"
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledSearch, {
                value: filtername,
                onChange: (e)=>setFilterName(e.target.value),
                placeholder: "Search Contactor...",
                startAdornment: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_16___default()), {
                    position: "start",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_21___default()), {})
                })
            }),
            numSelected > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15___default()), {
                title: "Delete",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_19___default()), {})
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15___default()), {
                title: "Filter list",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_14___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FilterList__WEBPACK_IMPORTED_MODULE_20___default()), {})
                })
            })
        ]
    });
}
function Employees({ hocommercial  }) {
    const [order, setOrder] = react__WEBPACK_IMPORTED_MODULE_1__.useState("asc");
    const [orderBy, setOrderBy] = react__WEBPACK_IMPORTED_MODULE_1__.useState("contractorname");
    const [selected, setSelected] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const [page, setPage] = react__WEBPACK_IMPORTED_MODULE_1__.useState(0);
    const [dense, setDense] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [rowsPerPage, setRowsPerPage] = react__WEBPACK_IMPORTED_MODULE_1__.useState(5);
    const [filterName, setFilterName] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_22__.useRouter)();
    const handleRequestSort = (event, property)=>{
        const isAsc = orderBy === property && order === "asc";
        setOrder(isAsc ? "desc" : "asc");
        setOrderBy(property);
    };
    const handleSelectAllClick = (event)=>{
        if (event.target.checked) {
            const newSelected = hocommercial.map((n)=>n.contractorname);
            setSelected(newSelected);
            return;
        }
        setSelected([]);
    };
    const handleClick = (event, contractorname)=>{
        const selectedIndex = selected.indexOf(contractorname);
        let newSelected = [];
        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, contractorname);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
        }
        setSelected(newSelected);
    };
    const handleChangePage = (event, newPage)=>{
        setPage(newPage);
    };
    const handleChangeRowsPerPage = (event)=>{
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    const handleChangeDense = (event)=>{
        setDense(event.target.checked);
    };
    const isSelected = (contractorname)=>selected.indexOf(contractorname) !== -1;
    // Avoid a layout jump when reaching the last page with empty rows.
    const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - hocommercial.length) : 0;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
        sx: {
            width: "100%"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_12___default()), {
            sx: {
                width: "100%",
                mb: 2
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EnhancedTableToolbar, {
                    numSelected: selected.length,
                    filtername: filterName,
                    setFilterName: setFilterName
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_7___default()), {
                    sx: {
                        scrollBehavior: "smooth",
                        "&::-webkit-scrollbar": {
                            height: 10
                        },
                        "&::-webkit-scrollbar-thumb": {
                            backgroundColor: "#bdbdbd",
                            borderRadius: 2
                        }
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_4___default()), {
                        sx: {
                            minWidth: 750
                        },
                        "aria-labelledby": "tableTitle",
                        size: "medium",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table_EnhancedTableHead__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                numSelected: selected.length,
                                onSelectAllClick: handleSelectAllClick,
                                rowCount: hocommercial.length,
                                headCells: headCells
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_5___default()), {
                                children: [
                                    hocommercial.filter((employee)=>employee.contractorname.toLowerCase().includes(filterName.toLowerCase())).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index)=>{
                                        const isItemSelected = isSelected(row.contractorname);
                                        const labelId = `enhanced-table-checkbox-${index}`;
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default()), {
                                            hover: true,
                                            onClick: (event)=>handleClick(event, row.contractorname),
                                            role: "checkbox",
                                            "aria-checked": isItemSelected,
                                            tabIndex: -1,
                                            selected: isItemSelected,
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    padding: "checkbox",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                        color: "primary",
                                                        checked: isItemSelected,
                                                        inputProps: {
                                                            "aria-labelledby": labelId
                                                        }
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    id: labelId,
                                                    scope: "row",
                                                    padding: "none",
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.contractorname
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.workDescription
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.fromDate
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.toDate
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: dayjs__WEBPACK_IMPORTED_MODULE_25___default()(row.monthOfInvoice, "MM-DD-YYYY").format("MMMM").toString() || "-"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.basicbillamount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.serviceCharges
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.netbillAmount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.bankDetails
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.onetimeInvoice ? "Yes" : "No"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.verifiedComplainces ? "Yes" : "No"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.workOrderAvailable ? "Yes" : "No"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.licensesInPlace ? "Yes" : "No"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.previousPayVerified ? "Yes" : "No"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.detailsSentToAuditAndHo ? "Yes" : "No"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.gstChallanAttached ? "Yes" : "No"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.deductions
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.variationsInManpower
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    align: "center",
                                                    sx: {
                                                        minWidth: 150
                                                    },
                                                    children: row.manchineOrRegisterMode
                                                })
                                            ]
                                        }, row.id);
                                    }),
                                    emptyRows > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        style: {
                                            height: (dense ? 33 : 53) * emptyRows
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            colSpan: 6
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_8___default()), {
                    rowsPerPageOptions: [
                        5,
                        10,
                        25
                    ],
                    component: "div",
                    count: hocommercial.length,
                    rowsPerPage: rowsPerPage,
                    page: page,
                    onPageChange: handleChangePage,
                    onRowsPerPageChange: handleChangeRowsPerPage
                })
            ]
        })
    });
}
const getServerSideProps = async (context)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_23__.getSession)({
        req: context.req
    });
    if (!session) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    if (session.user?.role === "Admin") {
        return {
            redirect: {
                destination: "/admin",
                permanent: false
            }
        };
    }
    const hocommercial = await _lib_prisma__WEBPACK_IMPORTED_MODULE_24__/* ["default"].hOAuditor.findMany */ .Z.hOAuditor.findMany();
    return {
        props: {
            hocommercial
        }
    };
};


/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 3866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FilterList");

/***/ }),

/***/ 8017:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 419:
/***/ ((module) => {

module.exports = require("@mui/material/");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 8330:
/***/ ((module) => {

module.exports = require("@mui/material/Checkbox");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 3103:
/***/ ((module) => {

module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 7730:
/***/ ((module) => {

module.exports = require("@mui/material/OutlinedInput");

/***/ }),

/***/ 1598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 8099:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 7308:
/***/ ((module) => {

module.exports = require("@mui/material/TablePagination");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7972], () => (__webpack_exec__(6381)));
module.exports = __webpack_exports__;

})();