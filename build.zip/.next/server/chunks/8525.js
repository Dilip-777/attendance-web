"use strict";
exports.id = 8525;
exports.ids = [8525];
exports.modules = {

/***/ 8525:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Launch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4752);
/* harmony import */ var _mui_icons_material_Launch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Launch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(773);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8330);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9181);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8823);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8099);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(443);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7308);
/* harmony import */ var _mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4848);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _EnhancedTableHead__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7972);
/* harmony import */ var _EnhancedTableToolbar__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3795);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_19__);




















const CustomTable = (props)=>{
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_16__.useState)([]);
    const [page, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_16__.useState)(0);
    const [rowsPerPage, setRowsPerPage] = (0,react__WEBPACK_IMPORTED_MODULE_16__.useState)(5);
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_19__.useSession)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    const handleSelectAllClick = (event)=>{
        if (event.target.checked) {
            const newSelected = props.rows.map((n)=>n.contractorname);
            setSelected(newSelected);
            return;
        }
        setSelected([]);
    };
    const handleClick = (event, contractorname)=>{
        const selectedIndex = selected.indexOf(contractorname);
        let newSelected = [];
        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, contractorname);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
        }
        setSelected(newSelected);
    };
    const isSelected = (contractorname)=>selected.indexOf(contractorname) !== -1;
    const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - props.rows.length) : 0;
    const handleChangePage = (event, newPage)=>{
        setPage(newPage);
    };
    const handleChangeRowsPerPage = (event)=>{
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
        sx: {
            width: "100%"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_7___default()), {
            sx: {
                width: "100%",
                mb: 2
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EnhancedTableToolbar__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                    numSelected: selected.length,
                    filtername: props.filterName,
                    setFilterName: props.setFilterName,
                    handleClickReport: props.handleClickReport,
                    type: props.type,
                    upload: props.upload
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_11___default()), {
                    sx: {
                        maxHeight: "calc(100vh - 16rem)",
                        overflowY: "auto",
                        scrollBehavior: "smooth",
                        "&::-webkit-scrollbar": {
                            height: 10,
                            width: 10
                        },
                        "&::-webkit-scrollbar-thumb": {
                            backgroundColor: "#bdbdbd",
                            borderRadius: 2
                        }
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_8___default()), {
                        stickyHeader: true,
                        sx: {
                            minWidth: 750
                        },
                        "aria-labelledby": "tableTitle",
                        size: "medium",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EnhancedTableHead__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                numSelected: selected.length,
                                onSelectAllClick: handleSelectAllClick,
                                rowCount: props.rows.length,
                                headCells: props.headcells
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_9___default()), {
                                children: [
                                    props.rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index)=>{
                                        const isItemSelected = isSelected(row.contractorname);
                                        const labelId = `enhanced-table-checkbox-${index}`;
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_13___default()), {
                                            hover: true,
                                            role: "checkbox",
                                            "aria-checked": isItemSelected,
                                            tabIndex: -1,
                                            selected: isItemSelected,
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                    padding: "checkbox",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                        color: "primary",
                                                        checked: isItemSelected,
                                                        onClick: (event)=>handleClick(event, row.employeename),
                                                        inputProps: {
                                                            "aria-labelledby": labelId
                                                        }
                                                    })
                                                }),
                                                props.headcells.filter((h)=>!h.included).map((headCell)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                        align: headCell.numeric ? "left" : "center",
                                                        sx: {
                                                            minWidth: "10rem"
                                                        },
                                                        children: [
                                                            lodash__WEBPACK_IMPORTED_MODULE_14___default().get(row, headCell.id) === true && "Yes",
                                                            lodash__WEBPACK_IMPORTED_MODULE_14___default().get(row, headCell.id) === false && "No",
                                                            typeof lodash__WEBPACK_IMPORTED_MODULE_14___default().get(row, headCell.id) !== "boolean" && lodash__WEBPACK_IMPORTED_MODULE_14___default().get(row, headCell.id, "-") || "-"
                                                        ]
                                                    })),
                                                props.setContractorId && props.setOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        session?.user?.role !== "HR" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                            onClick: ()=>{
                                                                if (props.setContractorId && props.setOpen) {
                                                                    props.setContractorId(row.id);
                                                                    props.setOpen(true);
                                                                }
                                                            },
                                                            align: "center",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                sx: {
                                                                    m: 0
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                    fontSize: "small"
                                                                })
                                                            })
                                                        }),
                                                        session?.user?.role === "HoCommercialAuditor" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                            align: "center",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                onClick: ()=>{
                                                                    router.push(`/hoauditor/${row.id}`);
                                                                },
                                                                sx: {
                                                                    m: 0
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Launch__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                    fontSize: "small"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                    size: "small",
                                                    align: "center",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        onClick: ()=>router.push(`${props.editLink}/${row.id}`),
                                                        sx: {
                                                            m: 0
                                                        },
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                            fontSize: "small"
                                                        })
                                                    })
                                                })
                                            ]
                                        }, row.id);
                                    }),
                                    emptyRows > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        style: {
                                            height: 53 * emptyRows
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_10___default()), {
                                            colSpan: 6
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TablePagination__WEBPACK_IMPORTED_MODULE_12___default()), {
                    rowsPerPageOptions: [
                        5,
                        10,
                        25
                    ],
                    component: "div",
                    count: props.rows.length,
                    rowsPerPage: rowsPerPage,
                    page: page,
                    onPageChange: handleChangePage,
                    onRowsPerPageChange: handleChangeRowsPerPage
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomTable);


/***/ })

};
;