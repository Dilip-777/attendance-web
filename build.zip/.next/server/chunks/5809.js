"use strict";
exports.id = 5809;
exports.ids = [5809];
exports.modules = {

/***/ 6395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export prisma */
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();
if (false) {}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (prisma);


/***/ }),

/***/ 8877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MonthSelect)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3280);
/* harmony import */ var _mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(298);
/* harmony import */ var _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_3__);




function MonthSelect({ value , onChange , label  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        display: "flex",
        flexDirection: "column",
        children: [
            label && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                sx: {
                    fontWeight: "700"
                },
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_2__.LocalizationProvider, {
                dateAdapter: _mui_x_date_pickers_AdapterDayjs__WEBPACK_IMPORTED_MODULE_3__.AdapterDayjs,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_date_pickers__WEBPACK_IMPORTED_MODULE_2__.DatePicker, {
                    sx: {
                        minWidth: "15rem"
                    },
                    views: [
                        "month",
                        "year"
                    ],
                    value: value,
                    onChange: (newValue)=>onChange(newValue)
                })
            })
        ]
    });
}


/***/ }),

/***/ 606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);

const getTotalAmountAndRows = (timekeeper, month, year, designations, department)=>{
    const rate = {
        date: "Rate"
    };
    const totalovertime1 = {
        date: "Total Overtime",
        total: 0
    };
    const attendancecount = {
        date: "Attendance Count"
    };
    const totalamount1 = {
        date: "Total Amount",
        total: 0
    };
    const otamount = {
        date: "OT Amount",
        total: 0
    };
    const totalnetamount = {
        date: "Total Net Amount"
    };
    const cprate = {
        date: "CP"
    };
    const cpamount = {
        date: "CP Amount",
        total: 0
    };
    const total = {
        date: "Total"
    };
    const gst1 = {
        date: "GST"
    };
    const billAmount1 = {
        date: "Bill Amount"
    };
    const tds1 = {
        date: "TDS"
    };
    const netPayable1 = {
        date: "Net Payable"
    };
    const getData = (date)=>{
        const filtered = timekeeper.filter((item)=>item.attendancedate === date);
        const obj = {
            date: date,
            total: 0
        };
        designations?.forEach((designation)=>{
            const id = designation.designationid;
            const count = filtered.filter((item)=>item.designation === designation.designation && item.gender && (designation.gender === "Both" || designation.gender[0] === item.gender[0])).length;
            obj[id] = count;
            obj["total"] = obj.total + count;
        });
        return obj;
    };
    const rows2 = [];
    const rows = [];
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    for(let i = startDate.getDate(); i <= endDate.getDate(); i++){
        const date = `${i.toString().padStart(2, "0")}/${month.toString().padStart(2, "0")}/${year}`;
        rows.push(getData(date));
    }
    if (designations) {
        designations.forEach((designation)=>{
            const filtered = timekeeper.filter((item)=>{
                if (designation.gender === "Male" || designation.gender === "M") {
                    return item.designation === designation.designation && item.gender && item.gender[0] === designation.gender[0];
                } else if (designation.gender === "Female" || designation.gender === "F") {
                    return item.designation === designation.designation && item.gender && item.gender[0] === designation.gender[0];
                } else {
                    console.log("called", item.designation, designation.designation);
                    return item.designation === designation.designation;
                }
            });
            console.log(filtered, designation.designation);
            const id = designation.designationid;
            attendancecount[id] = filtered.length;
            rate[id] = designation.basicsalary;
            totalamount1[id] = lodash__WEBPACK_IMPORTED_MODULE_0___default().get(attendancecount, id, 0) * Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(rate, id, 0));
            totalamount1["total"] = totalamount1.total + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(totalamount1, id, 0));
            totalovertime1[id] = filtered.reduce((acc, curr)=>acc + parseInt(curr.manualovertime || curr.overtime), 0);
            totalovertime1["total"] = totalovertime1.total + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(totalovertime1, id, 0));
            const otRate = Math.floor(designation.basicsalary / designation.allowed_wrking_hr_per_day);
            otamount[id] = Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(totalovertime1, id, 0)) * otRate;
            otamount["total"] = otamount.total + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(otamount, id, 0));
            totalnetamount[id] = Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(totalamount1, id, 0)) + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(otamount, id, 0));
            cprate[id] = designation.servicecharge;
            cpamount[id] = Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(attendancecount, id, 0)) * Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(cprate, id, 0));
            cpamount["total"] = cpamount.total + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(cpamount, id, 0));
            total[id] = Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(totalnetamount, id, 0)) + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(cpamount, id, 0));
            gst1[id] = Math.floor(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(total, id, 0) * 0.18);
            billAmount1[id] = Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(total, id, 0)) + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(gst1, id, 0));
            tds1[id] = Math.floor(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(total, id, 0) * 0.01);
            netPayable1[id] = Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(billAmount1, id, 0)) + Number(lodash__WEBPACK_IMPORTED_MODULE_0___default().get(tds1, id, 0));
        });
    }
    attendancecount["total"] = timekeeper.length;
    rate["total"] = 0;
    totalnetamount["total"] = parseInt(totalamount1.total) + parseInt(otamount.total);
    total["total"] = totalnetamount.total + parseInt(cpamount.total);
    gst1["total"] = Math.floor(total.total * 0.18);
    billAmount1["total"] = total.total + gst1.total;
    tds1["total"] = Math.floor(total.total * 0.01);
    netPayable1["total"] = billAmount1.total + tds1.total;
    rows2.push(attendancecount);
    rows.push(attendancecount);
    rows2.push(rate);
    rows.push(rate);
    rows2.push(totalamount1);
    rows.push(totalamount1);
    rows2.push(totalovertime1);
    rows.push(totalovertime1);
    rows2.push(otamount);
    rows.push(otamount);
    rows2.push(totalnetamount);
    rows.push(totalnetamount);
    if (department === "8HR" || department === "12HR" || department === "Colony") {
        rows2.push(cprate);
        rows.push(cprate);
        rows2.push(cpamount);
        rows.push(cpamount);
        rows2.push(total);
        rows.push(total);
    }
    rows2.push(gst1);
    rows2.push(billAmount1);
    rows2.push(tds1);
    rows2.push(netPayable1);
    return {
        rows,
        total1: total.total,
        rows1: rows2,
        totalnetPayable: totalnetamount.total
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getTotalAmountAndRows);


/***/ })

};
;