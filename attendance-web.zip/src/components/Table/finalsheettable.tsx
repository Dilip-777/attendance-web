import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import _ from "lodash";
import { Department, Designations } from "@prisma/client";

interface Data {
  date: string;
  m8: number;
  f8: number;
  m20: number;
  f20: number;
  dm: number;
  qc: number;
  store: number;
  k7m: number;
  k7f: number;
  rmhs: number;
  ps: number;
  hk: number;
  svr: number;
  total: number;
}

interface side {
  main: string;
  sub?: string;
  id: string;
}

export default function FinalSheetTable({
  rows,
  total,
  department,
  storededuction,
  safetydeduction,
  designations,
}: {
  rows: Data[];
  total: number;
  department: Department | undefined;
  storededuction: number;
  safetydeduction: number;
  designations: Designations[];
}) {
  const sidebar = designations
    .filter((d) => d.departmentname === department?.department)
    .map((d) => {
      if (d.basicsalary_in_duration === "Monthly")
        return { main: d.designation, id: d.designationid };
      if (d.gender === "Male")
        return { main: d.designation, sub: "M", id: d.designationid };
      else if (d.gender === "Female")
        return { main: d.designation, sub: "F", id: d.designationid };
      else return { main: d.designation, id: d.designationid };
    });

  const getRoundOff = (value: number) => {
    return Math.ceil(value);
  };

  if (department?.basicsalary_in_duration?.toLowerCase() === "hourly") {
    sidebar.push({ main: "Total", sub: " ", id: "total" });
  } else {
    sidebar.push({ main: "Total", id: "total" });
  }
  const headers = [
    "Total Man days",
    "Rate",
    "Man Days Amount",
    "Overtime Hrs.",
    "OT Amount",
    "Total Amount",
    "Service Charge Rate",
    "Service Charge Amount",
    "Taxable",
    "GST",
    "Bill Amount",
    "TDS",
    "Net Payable",
  ];

  const ccmheader = [
    "Total Man days",
    "Rate",
    "Man Days Amount",
    "Overtime Hrs.",
    "OT Amount",
    "Taxable",
    "GST",
    "Bill Amount",
    "TDS",
    "Net Payable",
  ];

  const colspan =
    department?.basicsalary_in_duration?.toLowerCase() === "hourly" ? 8 : 8;

  return (
    <Paper
      sx={{
        width: "100%",
        scrollBehavior: "smooth",
        "&::-webkit-scrollbar": {
          width: 9,
          height: 10,
        },
        "&::-webkit-scrollbar-thumb": {
          backgroundColor: "#bdbdbd",
          borderRadius: 2,
        },
      }}
    >
      <TableContainer
        sx={{
          maxWidth: "100%",
          scrollBehavior: "smooth",
          "&::-webkit-scrollbar": {
            width: 9,
            height: 10,
          },
          "&::-webkit-scrollbar-thumb": {
            backgroundColor: "#bdbdbd",
            borderRadius: 2,
          },
        }}
      >
        <Table aria-label="sticky table">
          <TableHead>
            <TableRow sx={{ bgcolor: "#eeeeee" }}>
              <TableCell align="center" sx={{ fontWeight: "700" }} colSpan={1}>
                Designation
              </TableCell>
              {department?.basicsalary_in_duration?.toLowerCase() ===
                "hourly" && (
                <TableCell
                  align="center"
                  sx={{ fontWeight: "700" }}
                  colSpan={1}
                >
                  Type
                </TableCell>
              )}
              {headers.map((header, index) => (
                <TableCell
                  align="center"
                  sx={{ fontWeight: "700" }}
                  colSpan={1}
                  key={index}
                >
                  {header}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {sidebar.map((item) => (
              <TableRow hover role="checkbox" tabIndex={-1} key={item.id}>
                <TableCell align="center" sx={{ fontWeight: "600" }}>
                  {item.main}
                </TableCell>
                {item.sub && <TableCell align="center">{item.sub}</TableCell>}
                {rows.map((row, index) => (
                  <TableCell key={index} align="center">
                    {getRoundOff(_.get(row, item.id) || 0)}
                  </TableCell>
                ))}
              </TableRow>
            ))}

            {/* <TableRow>
              <TableCell colSpan={colspan + 1}></TableCell>
              <TableCell colSpan={5} sx={{ fontWeight: "600" }}>
                Net Amount Payable
              </TableCell>
              <TableCell align="center">
                {total.toLocaleString("en-IN", {
                  maximumFractionDigits: 2,
                })}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={colspan}></TableCell>
              <TableCell colSpan={5} sx={{ fontWeight: "600" }}>
                GST Hold
              </TableCell>
              <TableCell align="center">{0}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={colspan}></TableCell>
              <TableCell colSpan={5} sx={{ fontWeight: "600" }}>
                Safety Voilation's Penalty
              </TableCell>
              <TableCell align="center">{safetydeduction}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={colspan}></TableCell>
              <TableCell colSpan={5} sx={{ fontWeight: "600" }}>
                Consumables / Rechargeable Items
              </TableCell>
              <TableCell align="center">{storededuction}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={colspan}></TableCell>
              <TableCell colSpan={5} sx={{ fontWeight: "600" }}>
                Adjustment Of Advance Amount
              </TableCell>
              <TableCell align="center">0</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={colspan}></TableCell>
              <TableCell colSpan={5} sx={{ fontWeight: "600" }}>
                Any Other Deductions
              </TableCell>
              <TableCell align="center">{0}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={colspan}></TableCell>
              <TableCell colSpan={5} sx={{ fontWeight: "600" }}>
                Final Payable
              </TableCell>
              <TableCell align="center">
                {(total > 0
                  ? total - storededuction - safetydeduction
                  : 0
                ).toLocaleString("en-IN", {
                  maximumFractionDigits: 2,
                })}
              </TableCell>
            </TableRow> */}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}
