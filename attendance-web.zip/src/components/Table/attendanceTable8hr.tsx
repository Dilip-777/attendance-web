import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import { Button } from "@mui/material";
interface Column {
  id:
    | "date"
    | "m8"
    | "f8"
    | "m20"
    | "f20"
    | "dm"
    | "qc"
    | "store"
    | "k7m"
    | "k7f"
    | "rmhs"
    | "ps"
    | "hk"
    | "svr"
    | "total";
  label: string;
  border?: boolean;
  minWidth?: number;
  align?: "right" | "center" | "left";
  format?: (value: number) => string;
}

interface Data {
  date: string;
  m8: number;
  f8: number;
  m20: number;
  f20: number;
  dm: number;
  qc: number;
  store: number;
  k7m: number;
  k7f: number;
  rmhs: number;
  ps: number;
  hk: number;
  svr: number;
  total: number;
}

export default function Table8hr({
  columns,
  rows,
  total,
}: {
  columns: Column[];
  rows: Data[];
  total: number;
}) {
  const downloadTxtFile = () => {
    // Convert JSON data to formatted string
    const jsonRows = JSON.stringify(rows, null, 2);
    const tableRows = [
      ["Name".padEnd(30), "Age".padEnd(30), "Email".padEnd(10)],
    ];
    rows.forEach((item) => {
      tableRows.push([
        item.date.padEnd(30),
        String(item.m8).toString().padEnd(3),
        item.f8.toString().padEnd(25),
      ]);
    });
    const tableRowsString = tableRows.map((row) => row.join("\t")).join("\n");
    const txtContent = `JSON data:\n${jsonRows}\n\nTable data:\n${tableRowsString}`;

    // Download text file
    const blob = new Blob([txtContent], {
      type: "text/plain;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "data.txt");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Paper
      sx={{
        width: "100%",
        scrollBehavior: "smooth",
        "&::-webkit-scrollbar": {
          width: 7,
          height: 7,
        },
        "&::-webkit-scrollbar-thumb": {
          backgroundColor: "#bdbdbd",
          borderRadius: 2,
        },
      }}
    >
      <TableContainer
        sx={{
          maxWidth: "100%",
          scrollBehavior: "smooth",
          "&::-webkit-scrollbar": {
            width: 7,
            height: 7,
          },
          "&::-webkit-scrollbar-thumb": {
            backgroundColor: "#bdbdbd",
            borderRadius: 2,
          },
        }}
      >
        <Table aria-label="sticky table">
          <TableHead>
            <TableRow>
              <TableCell align="center" colSpan={1}>
                Date
              </TableCell>
              <TableCell align="center" colSpan={2}>
                8 MW
              </TableCell>
              <TableCell align="center" colSpan={2}>
                12 MW
              </TableCell>
              <TableCell align="center" colSpan={1}>
                DM Plant
              </TableCell>
              <TableCell align="center" colSpan={1}>
                QC
              </TableCell>
              <TableCell align="center" colSpan={1}>
                Store
              </TableCell>
              <TableCell align="center" colSpan={2}>
                K-7 & 1-6PROC
              </TableCell>
              <TableCell align="center" colSpan={1}>
                RMHS
              </TableCell>
              <TableCell align="center" colSpan={1}>
                PS
              </TableCell>
              <TableCell align="center" colSpan={1}>
                HK & Garden
              </TableCell>
              <TableCell align="center" colSpan={1}>
                SVR
              </TableCell>
              <TableCell align="center" colSpan={1}>
                TOTAL
              </TableCell>
            </TableRow>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  style={{ top: 57, minWidth: column.minWidth }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, index) => {
              return (
                <TableRow hover role="checkbox" tabIndex={-1} key={row.f8}>
                  {columns.map((column) => {
                    const value = row[column.id];
                    return (
                      <TableCell key={column.id} align={column.align}>
                        {column.format && typeof value === "number"
                          ? column.format(value)
                          : value}
                      </TableCell>
                    );
                  })}
                </TableRow>
              );
            })}
            <TableRow>
              <TableCell rowSpan={10} />
              <TableCell colSpan={10}></TableCell>
              <TableCell colSpan={3}>Net Amount Payable</TableCell>
              <TableCell align="center">{total}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={9}></TableCell>
              <TableCell colSpan={3}>GST Hold</TableCell>
              <TableCell align="center">{total > 0 ? "300" : "0"}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={9}></TableCell>
              <TableCell colSpan={3}>Safety Voilation's Penality</TableCell>
              <TableCell align="center">{total > 0 ? "40" : "0"}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={9}></TableCell>
              <TableCell colSpan={3}>
                Consumables / Rechargeable Items
              </TableCell>
              <TableCell align="center">0</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={9}></TableCell>
              <TableCell colSpan={3}>Adjustment Of Advance Amount</TableCell>
              <TableCell align="center">0</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={9}></TableCell>
              <TableCell colSpan={3}>Any Other Deductions</TableCell>
              <TableCell align="center">{total > 0 ? "80" : "0"}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              <TableCell colSpan={9}></TableCell>
              <TableCell colSpan={3}>Final Payable</TableCell>
              <TableCell align="center">
                {total > 0 ? total - 150 - 40 - 80 : 0}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}
