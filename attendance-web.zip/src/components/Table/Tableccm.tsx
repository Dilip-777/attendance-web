import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";

interface Column {
  id:
    | "date"
    | "ele"
    | "lco"
    | "tman"
    | "filter"
    | "po"
    | "bco"
    | "srfilter"
    | "incharge"
    | "mo"
    | "shiftinch"
    | "gc"
    | "svr"
    | "sbo"
    | "lman"
    | "forman"
    | "tmesson"
    | "lmes"
    | "jrele"
    | "helper"
    | "total";
  label: string;
  border?: boolean;
  minWidth?: number;
  align?: "right" | "center" | "left";
  format?: (value: number) => string;
}

interface Data {
  date: string;
  ele: number;
  lco: number;
  tman: number;
  filter: number;
  po: number;
  bco: number;
  srfilter: number;
  incharge: number;
  mo: number;
  shiftinch: number;
  gc: number;
  tmesson: number;
  svr: number;
  sbo: number;
  lmes: number;
  lman: number;
  forman: number;
  jrele: number;
  helper: number;
  total: number;
}

export default function TableCCM({
  rows,
  total,
  columns,
  department,
}: {
  rows: Data[];
  total: number;
  columns: Column[];
  department: string;
}) {
  const colspan1 = department === "CCM" ? 14 : department === "LRF" ? 3 : -2;
  const colspan2 = department === "CCM" ? 5 : department === "LRF" ? 3 : -5;
  return (
    <Paper sx={{ width: "100%" }}>
      <TableContainer
        sx={{
          maxWidth: "100%",
          scrollBehavior: "smooth",
          "&::-webkit-scrollbar": {
            width: 7,
            height: 7,
          },
          "&::-webkit-scrollbar-thumb": {
            backgroundColor: "#bdbdbd",
            borderRadius: 2,
          },
        }}
      >
        <Table aria-label="sticky table">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  style={{ top: 57, minWidth: column.minWidth }}
                >
                  {column.label}{" "}
                  {/* {!(column.id === "date" || column.id === "total") && (
                    <span>{`(${count[column.id]})`}</span>
                  )} */}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, index) => {
              return (
                <TableRow hover role="checkbox" tabIndex={-1} key={row.lco}>
                  {columns.map((column) => {
                    const value = row[column.id];
                    return (
                      <TableCell key={column.id} align={column.align}>
                        {column.format && typeof value === "number"
                          ? column.format(value).slice(0, 7)
                          : value}
                      </TableCell>
                    );
                  })}
                </TableRow>
              );
            })}
            <TableRow>
              <TableCell rowSpan={department === "Colony" ? 0 : 10} />
              <TableCell colSpan={colspan1}></TableCell>
              <TableCell colSpan={colspan2}>Net Amount Payable</TableCell>
              <TableCell align="center">{total}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              {department !== "Colony" && (
                <TableCell colSpan={colspan1 - 1}></TableCell>
              )}
              <TableCell colSpan={colspan2}>GST Hold</TableCell>
              <TableCell align="center">{total > 0 ? "300" : "0"}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              {department !== "Colony" && (
                <TableCell colSpan={colspan1 - 1}></TableCell>
              )}
              <TableCell colSpan={colspan2}>
                Safety Voilation's Penality
              </TableCell>
              <TableCell align="center">{total > 0 ? "40" : "0"}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              {department !== "Colony" && (
                <TableCell colSpan={colspan1 - 1}></TableCell>
              )}
              <TableCell colSpan={colspan2}>
                Consumables / Rechargeable Items
              </TableCell>
              <TableCell align="center">0</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              {department !== "Colony" && (
                <TableCell colSpan={colspan1 - 1}></TableCell>
              )}
              <TableCell colSpan={colspan2}>
                Adjustment Of Advance Amount
              </TableCell>
              <TableCell align="center">0</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              {department !== "Colony" && (
                <TableCell colSpan={colspan1 - 1}></TableCell>
              )}
              <TableCell colSpan={colspan2}>Any Other Deductions</TableCell>
              <TableCell align="center">{total > 0 ? "80" : "0"}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell />
              {department !== "Colony" && (
                <TableCell colSpan={colspan1 - 1}></TableCell>
              )}
              <TableCell colSpan={colspan2}>Final Payable</TableCell>
              <TableCell align="center">
                {total > 0 ? total - 150 - 40 - 80 : 0}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}
