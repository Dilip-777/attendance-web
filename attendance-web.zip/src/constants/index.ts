export const CLOUDINARY_URL = 'https://api.cloudinary.com/v1_1/dddvmk9xs/upload';
export const uploadprsetname = "attendance-web"

export const plantname = "Plant One"


