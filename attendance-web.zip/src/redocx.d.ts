declare module 'redocx';
